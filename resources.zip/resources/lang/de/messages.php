<?php

return [
    'session_title'       => 'Diese Sitzung läuft in 4 Stunden ab',


];