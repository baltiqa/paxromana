<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Locale;

class ConfigServiceProvider extends ServiceProvider {

    public function register()
    {
      

    }

    /**
    * Register the service provider.
    *
    * @return void
    */
    public function boot()
    {
    //


    }

}