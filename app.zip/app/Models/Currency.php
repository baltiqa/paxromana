<?php


namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{

    protected $table = "currencies";
    use \Spiritix\LadaCache\Database\LadaCacheTrait;



    public static function GetCurrency($id){
        $result = Currency::find($id);
        return $result->currency_code;
    }

}