<?php
/**
 * Created by PhpStorm.
 * User: faree
 * Date: 1/19/2020
 * Time: 7:10 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class MultisigTransactions extends Model
{

    protected $table = 'multisig_transactions';


    public function seller() {
        return $this->belongsTo('App\Models\User', 'seller_id');
      }
  
      public function buyer() {
        return $this->belongsTo('App\Models\User','buyer_id');
      }

}