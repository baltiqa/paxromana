<?php

/**
 * Created by PhpStorm.
 * User: fareed.nema94@gmail.com
 * Date: 2/26/2020
 * Time: 3:00 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class TempMultisig extends Model{

    protected $table= "temp_multisig";

}