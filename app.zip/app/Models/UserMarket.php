<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserMarket extends Model
{


    
    protected $table = 'user_markets';

}
