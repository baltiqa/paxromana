<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Nicolaslopezj\Searchable\SearchableTrait;


class News extends Model
{
  use SearchableTrait;
  use \Spiritix\LadaCache\Database\LadaCacheTrait;


  protected $searchable = [
    'columns' => [
        'news.title' => 20,
        'news.body' => 20,
    ],
];

protected $fillable = [
  'title', 'body', 'featured'
];


public function newsc() {
  return $this->belongsTo('App\Models\News', 'id', 'parent_id')->get();
}


public function scopeWhereLike($query, $column, $value) {
 return $query->where($column, 'like', '%'.$value.'%');
}

public function scopeOrWhereLike($query, $column, $value ){
 return $query->orWhere($column, 'like', '%'.$value.'%');
}
}
