<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Nestable\NestableTrait;
use Spatie\SchemalessAttributes\SchemalessAttributes;


class Category extends Model
{
    use NestableTrait;

    protected $parent = 'parent_id';
    protected $table = 'categories';
    protected $withCount = ['listings'];
    public $children = [];

    public $timestamps = false;



    protected $fillable = [
        'name', 'hash', 'order', 'parent_id', 'description'
    ];
	
	public $casts = [
        'request' => 'json',
        'extra_attributes' => 'array',
    ];
	
	public function getDescriptionAttribute()
	{
        return $this->extra_attributes['description'];
	}

	public function child()
	{
		return $this->hasOne('App\Models\Category', 'id', 'parent_id');
	}

    public function listings() {
        return $this->hasMany('App\Models\Listing');
    }

    public function categories() {
        return $this->belongsTo('App\Models\Category', 'id', 'parent_id');
    }

    public function parent() {
        return $this->belongsTo('App\Models\Category', 'parent_id');
    }

    public static function children($category)
    {
        $result = [];

        if(isset($category->children) && count($category->children) > 0){
            foreach ($category->children as $child){
                $result[] = $child->id;
                    if(isset($child->children) && count($child->children) > 0){
                        foreach ($child->children as $g_child){
                            $result[] = $g_child->id;
                        }
                    }
            }
        }

        return $result;

    }


    public static function GetCategoriesWithTotalListings(){
	    $result = (array) DB::table("categories")->select("categories.*",DB::raw("count(`listings`.`id`) as 'total_listings'"))
                                               ->leftJoin("listings","categories.id","=","listings.category_id")
                                               ->groupBy("categories.name")->orderBy("categories.id","ASC")
                                               ->get();
        $result = array_shift($result);

	    foreach ($result as $key => $category){
	        if($category->parent_id == 0){
	            array_filter($result,function ($v) use($category){
                    if($v->parent_id == $category->id){
                        $category->total_listings = $category->total_listings + $v->total_listings;
                        $category->children[$v->id] = $v;
                    }
                },ARRAY_FILTER_USE_BOTH);
                if(isset($category->children)){
                    array_filter($result,function ($v) use($category){
                        if(in_array($v->parent_id,array_keys($category->children))){
                            $category->children[$v->parent_id]->total_listings = $category->children[$v->parent_id]->total_listings + $v->total_listings;
                            $category->total_listings = $category->total_listings + $v->total_listings;
                            $category->children[$v->parent_id]->children[] = $v;
                        }
                    },ARRAY_FILTER_USE_BOTH);
                }
            }

        }
	    return $result;

    }


}
