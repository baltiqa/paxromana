<?php
/**
 * Created by PhpStorm.
 * User: faree
 * Date: 1/19/2020
 * Time: 7:10 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class MultisigAddresses extends Model
{

    public $timestamps = false;
    protected $table = 'multisig_addresses';

}