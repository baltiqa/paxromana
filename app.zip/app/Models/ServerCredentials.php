<?php
/**
 * Created by PhpStorm.
 * User: faree
 * Date: 1/19/2020
 * Time: 4:24 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class ServerCredentials extends Model
{

    protected $table = 'server_credentials';

}