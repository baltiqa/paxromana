<?php


namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Referral extends Model
{

    protected $table = "user_referrals";
    public $timestamps = false;


    public static function ReferrerCommission(Order $order){

        $ref_user = Referral::where("user_id",$order->user_id)->first();
        if(!$ref_user){
            return false;
        }

        $ref_user = User::where("id",$ref_user->referrer_id)->first();
        $commission = $order->service_fee/setting("referral_commission")/100;
        switch ($order->currency){
            case 1:
                $commission = number_format($commission,8);
                $ref_user->btc_balance = $ref_user->btc_balance + $commission;
                break;
            case 2:
                $commission = number_format($commission,2);
                $ref_user->ltc_balance = $ref_user->ltc_balance + $commission;
                break;
            case 3:
                $commission = number_format($commission,2);
                $ref_user->xmr_balance = $ref_user->xmr_balance + $commission;
                break;
        }
        if($ref_user->save()){
            Referral::SaveCommission($order,$ref_user->id);
            return [$ref_user->id,$commission,$order->currency];
        }else{
            return false;
        }
    }

    protected static function SaveCommission(Order $order,$ref_id){

        $rates = new CurrencyRates();
        $rates = $rates->where("currency_id",$order->currency)->first();

        $listing = Listing::where("id",$order->listing_id)->first();
        $currency = $listing->currency;
        $amount = $order->service_fee/setting("referral_commission")/100;
        $amount = $amount / $rates->$currency;

        $code = Currency::where("id",$order->currency)->first();

        $commission = new Commission();
        $commission->user_id = $order->user_id;
        $commission->referrer_id = $ref_id;
        $commission->amount = number_format($amount,8);
        $commission->currency = $code->currency_code;
        $commission->order_id = $order->id;
        $commission->save();
    }

    public static function UserReferrals($user_id){

        $referrals = Referral::where("referrer_id",$user_id)->get();

        $referrals_commissions = array();

        $btc_comission = 0;
        $ltc_commission = 0;
        $xmr_commission = 0;


        foreach ($referrals as $referee){

            $btc_comission += Commission::GetCommissions($user_id,$referee->user_id,"BTC");
            $ltc_commission+= Commission::GetCommissions($user_id,$referee->user_id,"LTC");
            $xmr_commission+= Commission::GetCommissions($user_id,$referee->user_id,"XMR");

      
        }


        $referrals_commissions[] = number_format($btc_comission,9);
        $referrals_commissions[] = number_format($ltc_commission,9);
        $referrals_commissions[] = number_format($xmr_commission,9);
        
        return $referrals_commissions;
    }

}