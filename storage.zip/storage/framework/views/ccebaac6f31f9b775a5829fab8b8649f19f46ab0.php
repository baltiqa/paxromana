<div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        Copyright &copy; <?php echo e(date('Y')); ?> - <?php echo e(date('Y') + 1); ?> <a href="<?php echo e(config('app.url')); ?>"></a>Pax Romana</strong> All rights reserved.
                        </div>
                    </div>
                </div>
            </div>