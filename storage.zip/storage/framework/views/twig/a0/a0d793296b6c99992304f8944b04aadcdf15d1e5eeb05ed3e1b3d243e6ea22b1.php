<?php

/* /var/www/html/html/resources/themes/default/account/orders/disputed.twig */
class __TwigTemplate_497e942eaead330dc53aee0b70569ae58edda0411322ea0d9f03ee5226f50f2d extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/orders/disputed.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "
\t<div id=\"content\">
\t\t<div id=\"seller-panel\">
\t\t\t<div style=\"background-color:white;\" class=\"canvas\">
\t\t\t\t";
        // line 11
        if (($this->getAttribute(($context["orders"] ?? null), "count", array()) == null)) {
            // line 12
            echo "\t\t\t\t\t";
            $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/orders/disputed.twig", 12)->display($context);
            // line 13
            echo "\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t";
            // line 17
            $this->loadTemplate("account.orders.sales.navbar.twig", "/var/www/html/html/resources/themes/default/account/orders/disputed.twig", 17)->display($context);
            // line 18
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t</div>
\t\t\t\t\t<div style=\"margin:0\" class=\"mp-Alert mp-Alert--info-light\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t";
            // line 27
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_no_sales")), "html", null, true);
            echo "
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        } else {
            // line 32
            echo "\t\t\t\t\t\t<form method=\"get\" action=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/orders/state/";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "state"), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t<input class=\"mp-Input style-scope listing-search\" placeholder=\"";
            // line 33
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_search")), "html", null, true);
            echo "\" name=\"q\" type=\"text\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "q"), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t<button class=\"mp-Button mp-Button--secondary mp-Button--xs mp-SearchForm-search style-scope mp-Header\" type=\"submit\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-search style-scope mp-Header\"></span>
\t\t\t\t\t\t\t<span class=\"mp-show-md style-scope mp-Header\"></span>
\t\t\t\t\t\t</button>
\t\t\t\t\t</form>
\t\t\t\t\t";
            // line 39
            $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/orders/disputed.twig", 39)->display($context);
            // line 40
            echo "\t\t\t\t\t<div id=\"ad-listing-table\" class=\"table ad-listing-container seller\">
\t\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t<div class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t\t";
            // line 45
            $this->loadTemplate("account.orders.sales.navbar.twig", "/var/www/html/html/resources/themes/default/account/orders/disputed.twig", 45)->display($context);
            // line 46
            echo "\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            // line 51
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? null));
            foreach ($context['_seq'] as $context["i"] => $context["item"]) {
                // line 52
                echo "\t\t\t\t\t\t\t<div id=\"ad-listing-table-body\" class=\"table-body\">
\t\t\t\t\t\t\t\t<div class=\"row ad-listing compact\">
\t\t\t\t\t\t\t\t\t<div class=\"cells\">
\t\t\t\t\t\t\t\t\t\t<div class=\"cell icon-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"check\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t\t\t<b>";
                // line 58
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order")), "html", null, true);
                echo " ID:
\t\t\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell thumbnail-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumbnail-wrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "url", array()), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                // line 66
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method") == null)) ? ("/web/images/noimage.png") : ($this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method"))), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"10\" cols=\"30\" style=\"resize: vertical;\" readonly=\"\" value=\"\">";
                // line 71
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_address", array()), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"title\" href=\"";
                // line 74
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.orders.show", $context["item"]));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 75
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "product_title", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 78
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t#";
                // line 79
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "hash", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 82
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t<b>";
                // line 83
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["item"], "is_digital", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1")))), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 86
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")), "html", null, true);
                echo "</label><br><a href=\"/profile/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 89
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_shipping_method")), "html", null, true);
                echo "</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "shipping", array()), "name", array()), "html", null, true);
                echo "/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "shipping", array()), "days", array()), "html", null, true);
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                echo "/
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 90
                if (($this->getAttribute($context["item"], "currency", array()) == "BTC")) {
                    // line 91
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "BTC
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 92
$context["item"], "currency", array()) == "LTC")) {
                    // line 93
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "LTC
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 94
$context["item"], "currency", array()) == "XMR")) {
                    // line 95
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "XMR
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 97
                echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 99
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_purschased")), "html", null, true);
                echo ":</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "created_at", array()), "toFormattedDateString", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 102
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
                echo ":</label><br><b>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "amount", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 103
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell position-column features-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs\" disabled>";
                // line 108
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status4")), "html", null, true);
                echo " </button><br>
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 109
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item2")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"";
                // line 110
                echo ((($this->getAttribute($context["item"], "currency", array()) == "BTC")) ? ("btc20") : (((($this->getAttribute($context["item"], "currency", array()) == "XMR")) ? ("xmr20") : ("ltc20"))));
                echo "\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 111
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "payment_type", array()), "payment_name", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 114
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item3")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 115
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "price", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 116
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "currency", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 119
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
                echo "</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"";
                // line 120
                echo ((($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) ? ("color:black") : (((($this->getAttribute($context["item"], "status", array()) == "shipped")) ? ("color:blue") : (((($this->getAttribute($context["item"], "status", array()) == "cancelled")) ? ("color:red;") : (((($this->getAttribute($context["item"], "status", array()) == "disputed")) ? ("color:red;") : ("color:green;"))))))));
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "status", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t<div class=\"cta\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 124
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.dispute.show", $this->getAttribute($this->getAttribute($context["item"], "dispute", array()), "id", array())));
                echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 125
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_see_dispute")), "html", null, true);
                echo " 
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 133
            echo "\t\t\t\t\t\t";
            echo $this->getAttribute(($context["orders"] ?? null), "links", array(), "method");
            echo "
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 136
        echo "\t\t\t</div>
\t\t</div>
\t</div>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/orders/disputed.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  326 => 136,  319 => 133,  305 => 125,  301 => 124,  292 => 120,  288 => 119,  282 => 116,  278 => 115,  274 => 114,  268 => 111,  264 => 110,  260 => 109,  256 => 108,  248 => 103,  242 => 102,  234 => 99,  230 => 97,  224 => 95,  222 => 94,  217 => 93,  215 => 92,  210 => 91,  208 => 90,  199 => 89,  189 => 86,  183 => 83,  179 => 82,  173 => 79,  169 => 78,  163 => 75,  159 => 74,  153 => 71,  145 => 66,  141 => 65,  133 => 60,  128 => 58,  120 => 52,  116 => 51,  109 => 46,  107 => 45,  100 => 40,  98 => 39,  87 => 33,  80 => 32,  72 => 27,  61 => 18,  59 => 17,  53 => 13,  50 => 12,  48 => 11,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/orders/disputed.twig", "");
    }
}
