<?php

/* /var/www/html/html/resources/themes/default/account/vendor.twig */
class __TwigTemplate_3bf444e7add04a30aeb29a70f613e393cedbdb768c69d31f0fd97ca385fc4db6 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/account/vendor.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_wallet.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t\t<h1 class=\"page-header\">";
        // line 10
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_title")), "html", null, true);
        echo "</h1>
\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t";
        // line 13
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 14
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 17
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method");
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 21
        echo "\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t<strong>";
        // line 23
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_agree")), "html", null, true);
        echo "</strong>
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li>";
        // line 26
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rule_1")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 27
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rule_2")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 28
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rule_3")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 29
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rule_4")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 30
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rule_5")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 31
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rule_6")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 32
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rule_7"));
        echo "</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<p style=\"color:red;\">";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_terminations")), "html", null, true);
        echo "</p>
\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t<strong>";
        // line 36
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_other_req")), "html", null, true);
        echo "</strong>
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li>";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rules8")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 40
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rules9")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rules10")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 42
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rules11")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 43
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rules12")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 44
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rules13")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 45
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_rules14")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t<strong>";
        // line 48
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_other_requirements")), "html", null, true);
        echo "</strong>
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li>";
        // line 51
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_other_req1"));
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 52
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_other_req2")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t<li>";
        // line 53
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_other_req3")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<p>*) ";
        // line 55
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_refund")), "html", null, true);
        echo "</p>
\t\t\t\t\t\t<hr>
\t\t\t\t\t\t<form action=\"";
        // line 57
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.pay.vendor"));
        echo "\" method=\"post\">
\t\t\t\t\t\t";
        // line 58
        echo csrf_field();
        echo "

\t\t\t\t\t\t<input type=\"checkbox\" name=\"terms\">";
        // line 60
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_confirm")), "html", null, true);
        echo "
 \t\t\t\t\t\t\t\t ";
        // line 61
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "terms"), "method")) {
            // line 62
            echo "                                            <div
                                                class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
                                                ";
            // line 64
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_apply_vendor_accept")), "html", null, true);
            echo "
                                            </div>
                                            ";
        }
        // line 67
        echo "\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<input class=\"mp-Button mp-Button--secondary mp-Button--lg\" value=\"Pay with BTC ";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice(150, "USD", "yes"), "html", null, true);
        echo "\" type=\"submit\" name=\"paybtc\">
\t\t\t\t\t\t\t<input class=\"mp-Button mp-Button--secondary mp-Button--lg\" value=\"Pay with LTC ";
        // line 69
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice(150, "USD", "yes"), "html", null, true);
        echo "\" type=\"submit\" name=\"payltc\">
\t\t\t\t\t\t\t<input class=\"mp-Button mp-Button--secondary mp-Button--lg\" value=\"Pay with XMR ";
        // line 70
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice(150, "USD", "yes"), "html", null, true);
        echo "\" type=\"submit\" name=\"payxmr\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<form>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/vendor.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  206 => 70,  202 => 69,  198 => 68,  195 => 67,  189 => 64,  185 => 62,  183 => 61,  179 => 60,  174 => 58,  170 => 57,  165 => 55,  160 => 53,  156 => 52,  152 => 51,  146 => 48,  140 => 45,  136 => 44,  132 => 43,  128 => 42,  124 => 41,  120 => 40,  116 => 39,  110 => 36,  105 => 34,  100 => 32,  96 => 31,  92 => 30,  88 => 29,  84 => 28,  80 => 27,  76 => 26,  70 => 23,  66 => 21,  59 => 17,  54 => 14,  52 => 13,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/vendor.twig", "");
    }
}
