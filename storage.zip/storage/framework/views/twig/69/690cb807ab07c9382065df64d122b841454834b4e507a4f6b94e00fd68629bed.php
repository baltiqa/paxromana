<?php

/* /var/www/html/html/resources/themes/default/account/tickets/show.twig */
class __TwigTemplate_d6554290fb30d2985d5914ae44fba19dcff1d115790cefa1307db2ef19738ee4 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/tickets/show.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_support.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "\t<div id=\"content\">
\t\t";
        // line 8
        $this->loadTemplate("account.head_support.twig", "/var/www/html/html/resources/themes/default/account/tickets/show.twig", 8)->display($context);
        // line 9
        echo "\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t";
        // line 11
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 12
            echo "\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 19
        echo "\t\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 20
            echo "\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon   mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 27
        echo "
\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t<p style=\"text-align:right;\"><b>";
        // line 30
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_categories")), "html", null, true);
        echo ":</b>
\t\t\t\t\t\t\t";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute(($context["ticket"] ?? null), "category", array()), "html", null, true);
        echo "
\t\t\t\t\t\t\t<b>";
        // line 32
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_date")), "html", null, true);
        echo ":</b>
\t\t\t\t\t\t\t";
        // line 33
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["ticket"] ?? null), "created_at", array()), "d-m-Y H:i:s"), "html", null, true);
        echo "
\t\t\t\t\t\t\t<b>";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
        echo ":</b>
\t\t\t\t\t\t\t<span class=\"";
        // line 35
        echo ((($this->getAttribute(($context["ticket"] ?? null), "status", array()) == "Answered")) ? ("answered") : (((($this->getAttribute(($context["ticket"] ?? null), "status", array()) == "Unanswered")) ? ("unanswered") : ("closed"))));
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["ticket"] ?? null), "status", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t<b>";
        // line 38
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_fge")), "html", null, true);
        echo " #";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["ticket"] ?? null), "id", array()), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t-
\t\t\t\t\t\t\t\t";
        // line 40
        echo twig_escape_filter($this->env, $this->getAttribute(($context["ticket"] ?? null), "title", array()), "html", null, true);
        echo "</b>
\t\t\t\t\t\t</h3>
\t\t\t\t\t";
        // line 42
        if (($this->getAttribute(($context["ticket"] ?? null), "status", array()) != "Closed")) {
            // line 43
            echo "\t\t\t\t\t\t<a href=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.ticket.close", $this->getAttribute(($context["ticket"] ?? null), "id", array())));
            echo "\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t";
            // line 44
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_close_ticket")), "html", null, true);
            echo "
\t\t\t\t\t\t</a>
\t\t\t\t\t";
        }
        // line 47
        echo "\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t<b>";
        // line 51
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_question")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t</h3>
\t\t\t\t\t\t<textarea style=\"background-color:#EEEEEE;height:150px;\" class=\"mp-Textarea\" id=\"text\" name=\"text\" disabled>";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute(($context["ticket"] ?? null), "text", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t</div>


\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t\t<div style=\"margin-top:20px;\" class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t<b>";
        // line 65
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_conversation")), "html", null, true);
        echo "</b>
\t\t\t\t\t</h3>
\t\t\t\t</div>
\t\t\t\t";
        // line 68
        if (($this->getAttribute($this->getAttribute(($context["ticket"] ?? null), "replies", array()), "count", array()) != null)) {
            // line 69
            echo "\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["ticket"] ?? null), "replies", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["reply"]) {
                // line 70
                echo "\t\t\t\t\t\t";
                if (($this->getAttribute($context["reply"], "adminreply", array()) != 0)) {
                    // line 71
                    echo "\t\t\t\t\t\t\t<div class=\"panel-danger\">
\t\t\t\t\t\t\t\t<div class=\"panel panel-heading\">
\t\t\t\t\t\t\t\t\t ";
                    // line 73
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reply"], "moderator", array()), "username", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel panel-body\">
\t\t\t\t\t\t\t\t\t<pre>";
                    // line 76
                    echo twig_escape_filter($this->env, $this->getAttribute($context["reply"], "text", array()), "html", null, true);
                    echo "</pre>
\t\t\t\t\t\t\t\t\t<span style=\"font-size: 15px;\">
\t\t\t\t\t\t\t\t\t\t<b>";
                    // line 78
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["reply"], "created_at", array()), "d-m-Y H:i:s"), "html", null, true);
                    echo "</b>
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<hr>
\t\t\t\t\t\t";
                }
                // line 84
                echo "\t\t\t\t\t\t";
                if (($this->getAttribute($context["reply"], "adminreply", array()) == 0)) {
                    // line 85
                    echo "\t\t\t\t\t\t\t<div class=\"panel-primary\">
\t\t\t\t\t\t\t\t<div class=\"panel panel-heading\">
\t\t\t\t\t\t\t\t\t";
                    // line 87
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reply"], "user", array()), "username", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"panel panel-body\">
\t\t\t\t\t\t\t\t\t<pre>";
                    // line 90
                    echo twig_escape_filter($this->env, $this->getAttribute($context["reply"], "text", array()), "html", null, true);
                    echo "</pre>
\t\t\t\t\t\t\t\t\t<span style=\"font-size: 15px;\">
\t\t\t\t\t\t\t\t\t\t<b>";
                    // line 92
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["reply"], "created_at", array()), "d-m-Y H:i:s"), "html", null, true);
                    echo "</b>
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
                }
                // line 97
                echo "\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reply'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 98
            echo "
\t\t\t\t";
        } else {
            // line 100
            echo "\t\t\t\t\t<p>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_no_answer")), "html", null, true);
            echo "</p>
\t\t\t\t";
        }
        // line 102
        echo "\t\t\t</div>
\t\t</div>

\t\t<div style=\"margin-top:20px;\" class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t<b>";
        // line 108
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_question")), "html", null, true);
        echo "</b>
\t\t\t\t</h3>
\t\t\t\t";
        // line 110
        if (($this->getAttribute(($context["ticket"] ?? null), "status", array()) != "Closed")) {
            // line 111
            echo "\t\t\t\t\t<form method=\"post\" action=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.post.reply", $this->getAttribute(($context["ticket"] ?? null), "id", array())));
            echo "\">
\t\t\t\t\t\t";
            // line 112
            echo csrf_field();
            echo "
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
            // line 115
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_message")), "html", null, true);
            echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
            // line 117
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_message_s")), "html", null, true);
            echo "
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t<textarea style=\"height:150px;\" class=\"mp-Textarea ";
            // line 119
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "text"), "method")) ? (" invalid") : (""));
            echo " \" id=\"text\" name=\"text\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("text")), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>Captcha</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<img style=\"margin:5px;\" src=\"/captcha.html\">
\t\t\t\t\t\t\t<input type=\"text\" name=\"captcha\" id=\"captcha\" class=\"mp-Input ";
            // line 127
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
            echo " \" value=\"\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div style=\"margin-top:5px;\" class=\"form-field\">
\t\t\t\t\t\t\t<button type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t<span>";
            // line 132
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_submit")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<a id=\"cancel-profile\" href=\"/account/tickets\" class=\"secondary medium mp-Button mp-Button--secondary\">
\t\t\t\t\t\t\t\t<span>";
            // line 135
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_cancel")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</form>
\t\t\t\t";
        } else {
            // line 140
            echo "\t\t\t\t\t<p>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_close_ticket_text")), "html", null, true);
            echo "</p>
\t\t\t\t";
        }
        // line 142
        echo "
\t\t\t</div>
\t\t</div>

\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/tickets/show.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  323 => 142,  317 => 140,  309 => 135,  303 => 132,  295 => 127,  282 => 119,  277 => 117,  272 => 115,  266 => 112,  261 => 111,  259 => 110,  254 => 108,  246 => 102,  240 => 100,  236 => 98,  230 => 97,  222 => 92,  217 => 90,  211 => 87,  207 => 85,  204 => 84,  195 => 78,  190 => 76,  184 => 73,  180 => 71,  177 => 70,  172 => 69,  170 => 68,  164 => 65,  149 => 53,  144 => 51,  138 => 47,  132 => 44,  127 => 43,  125 => 42,  120 => 40,  113 => 38,  105 => 35,  101 => 34,  97 => 33,  93 => 32,  89 => 31,  85 => 30,  80 => 27,  73 => 23,  68 => 20,  65 => 19,  58 => 15,  53 => 12,  51 => 11,  47 => 9,  45 => 8,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/tickets/show.twig", "");
    }
}
