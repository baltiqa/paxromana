<?php

/* category.rate.twig */
class __TwigTemplate_c4d188217830a7fc2b765e2e4a116dfcce2ffde5e2ac5f57c2a853d33d176d87 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"rate\">
\t<h3 class=\"ratehead\">Bitcoin (BTC)</h3>
\t<p class=\"rate1 ";
        // line 3
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "usd")) ? ("choosingrate") : (""));
        echo "\">
\t\tUnited States Dollar(USD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 6
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "usd_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 7
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "usd", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 11
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "eur")) ? ("choosingrate") : (""));
        echo "\">
\t\tEuro (EUR)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 14
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "eur_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 15
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "eur", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 19
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "gbp")) ? ("choosingrate") : (""));
        echo "\">
\t\tBritish Pound(GBP)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 22
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "gbp_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 23
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "gbp", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 27
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "cad")) ? ("choosingrate") : (""));
        echo "\">
\t\tCanadian Dollar(CAD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 30
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "cad_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 31
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "cad", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 35
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "aud")) ? ("choosingrate") : (""));
        echo "\">
\t\tAustralian Dollar(AUD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 38
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "aud_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 39
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "aud", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 43
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "inr")) ? ("choosingrate") : (""));
        echo "\">
\t\tIndian Rupee(INR)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 46
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "inr_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 47
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "inr", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 51
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "rub")) ? ("choosingrate") : (""));
        echo "\">
\t\tRussian Roebel(RUB)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 54
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "rub_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 55
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "rub", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 59
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "brl")) ? ("choosingrate") : (""));
        echo "\">
\t\tBrazilian Real(BRL)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 62
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "brl_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 63
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "brl", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 67
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "jpy")) ? ("choosingrate") : (""));
        echo "\">
\t\tJapanese Yen(JPY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 70
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "jpy_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 71
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "jpy", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 75
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "dkk")) ? ("choosingrate") : (""));
        echo "\">
\t\tDanish Krone(DKK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 78
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "dkk_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 79
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "dkk", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 83
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "sek")) ? ("choosingrate") : (""));
        echo "\">
\t\tSwedish Krona(SEK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 86
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "sek_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 87
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "sek", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 91
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "nok")) ? ("choosingrate") : (""));
        echo "\">
\t\tNorwegian Krone(NOK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 94
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "nok_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 95
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "nok", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 99
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "try")) ? ("choosingrate") : (""));
        echo "\">
\t\tTurkish Lira(TRY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 102
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "try_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 103
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "try", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 107
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "cny")) ? ("choosingrate") : (""));
        echo "\">
\t\tChinese Yuan(CNY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 110
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "cny_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 111
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "cny", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 115
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "hkd")) ? ("choosingrate") : (""));
        echo "\">
\t\tHong Kong Dollar(HKD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 118
        echo ((($this->getAttribute(($context["btc_rates"] ?? null), "hkd_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 119
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["btc_rates"] ?? null), "hkd", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1\">
\t\t<a href=\"";
        // line 124
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/account/wallet/btc\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.money_wod")), "html", null, true);
        echo "</a>
\t</p>
</div>

<div class=\"rate\">
\t<h3 class=\"ratehead\">Monero (XMR)</h3>
\t<p class=\"rate1 ";
        // line 130
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "usd")) ? ("choosingrate") : (""));
        echo "\">
\t\tUnited States Dollar(USD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 133
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "usd_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 134
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "usd", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 138
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "eur")) ? ("choosingrate") : (""));
        echo "\">
\t\tEuro (EUR)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 141
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "eur_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 142
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "eur", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 146
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "gbp")) ? ("choosingrate") : (""));
        echo "\">
\t\tBritish Pound(GBP)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 149
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "gbp_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 150
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "gbp", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 154
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "cad")) ? ("choosingrate") : (""));
        echo "\">
\t\tCanadian Dollar(CAD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 157
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "cad_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 158
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "cad", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 162
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "aud")) ? ("choosingrate") : (""));
        echo "\">
\t\tAustralian Dollar(AUD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 165
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "aud_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 166
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "aud", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 170
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "inr")) ? ("choosingrate") : (""));
        echo "\">
\t\tIndian Rupee(INR)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 173
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "inr_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 174
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "inr", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 178
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "rub")) ? ("choosingrate") : (""));
        echo "\">
\t\tRussian Roebel(RUB)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 181
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "rub_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 182
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "rub", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 186
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "brl")) ? ("choosingrate") : (""));
        echo "\">
\t\tBrazilian Real(BRL)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 189
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "brl_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 190
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "brl", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 194
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "jpy")) ? ("choosingrate") : (""));
        echo "\">
\t\tJapanese Yen(JPY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 197
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "jpy_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 198
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "jpy", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 202
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "dkk")) ? ("choosingrate") : (""));
        echo "\">
\t\tDanish Krone(DKK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 205
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "dkk_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 206
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "dkk", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 210
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "sek")) ? ("choosingrate") : (""));
        echo "\">
\t\tSwedish Krona(SEK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 213
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "sek_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 214
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "sek", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 218
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "nok")) ? ("choosingrate") : (""));
        echo "\">
\t\tNorwegian Krone(NOK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 221
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "nok_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 222
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "nok", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 226
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "try")) ? ("choosingrate") : (""));
        echo "\">
\t\tTurkish Lira(TRY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 229
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "try_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 230
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "try", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 234
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "cny")) ? ("choosingrate") : (""));
        echo "\">
\t\tChinese Yuan(CNY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 237
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "cny_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 238
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "cny", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 242
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "hkd")) ? ("choosingrate") : (""));
        echo "\">
\t\tHong Kong Dollar(HKD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 245
        echo ((($this->getAttribute(($context["xmr_rates"] ?? null), "hkd_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 246
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["xmr_rates"] ?? null), "hkd", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1\">
\t\t<a href=\"";
        // line 251
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/account/wallet/xmr\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.money_wod")), "html", null, true);
        echo "</a>
\t</p>
</div>

<div class=\"rate\">
\t<h3 class=\"ratehead\">Litecoin (LTC)</h3>
\t<p class=\"rate1 ";
        // line 257
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "usd")) ? ("choosingrate") : (""));
        echo "\">
\t\tUnited States Dollar(USD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 260
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "usd_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 261
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "usd", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 265
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "eur")) ? ("choosingrate") : (""));
        echo "\">
\t\tEuro (EUR)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 268
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "eur_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 269
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "eur", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 273
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "gbp")) ? ("choosingrate") : (""));
        echo "\">
\t\tBritish Pound(GBP)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 276
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "gbp_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 277
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "gbp", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 281
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "cad")) ? ("choosingrate") : (""));
        echo "\">
\t\tCanadian Dollar(CAD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 284
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "cad_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 285
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "cad", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 289
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "aud")) ? ("choosingrate") : (""));
        echo "\">
\t\tAustralian Dollar(AUD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 292
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "aud_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 293
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "aud", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 297
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "inr")) ? ("choosingrate") : (""));
        echo "\">
\t\tIndian Rupee(INR)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 300
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "inr_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 301
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "inr", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 305
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "rub")) ? ("choosingrate") : (""));
        echo "\">
\t\tRussian Roebel(RUB)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 308
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "rub_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 309
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "rub", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 313
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "brl")) ? ("choosingrate") : (""));
        echo "\">
\t\tBrazilian Real(BRL)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 316
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "brl_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 317
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "brl", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 321
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "jpy")) ? ("choosingrate") : (""));
        echo "\">
\t\tJapanese Yen(JPY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 324
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "jpy_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 325
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "jpy", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 329
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "dkk")) ? ("choosingrate") : (""));
        echo "\">
\t\tDanish Krone(DKK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 332
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "dkk_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 333
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "dkk", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 337
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "sek")) ? ("choosingrate") : (""));
        echo "\">
\t\tSwedish Krona(SEK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 340
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "sek_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 341
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "sek", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 345
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "nok")) ? ("choosingrate") : (""));
        echo "\">
\t\tNorwegian Krone(NOK)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 348
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "nok_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 349
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "nok", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 353
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "try")) ? ("choosingrate") : (""));
        echo "\">
\t\tTurkish Lira(TRY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 356
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "try_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 357
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "try", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 361
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "cny")) ? ("choosingrate") : (""));
        echo "\">
\t\tChinese Yuan(CNY)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 364
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "cny_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 365
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "cny", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1 ";
        // line 369
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "hkd")) ? ("choosingrate") : (""));
        echo "\">
\t\tHong Kong Dollar(HKD)
\t\t<span class=\"float-right boldstats\">
\t\t\t<font color=\"";
        // line 372
        echo ((($this->getAttribute(($context["ltc_rates"] ?? null), "hkd_atl", array()) >= 0)) ? ("green") : ("red"));
        echo "\">
\t\t\t\t";
        // line 373
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["ltc_rates"] ?? null), "hkd", array()), 2), "html", null, true);
        echo "
\t\t\t</font>
\t\t</span>
\t</p>
\t<p class=\"rate1\">
\t\t<a href=\"";
        // line 378
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/account/wallet/ltc\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.money_wod")), "html", null, true);
        echo "</a>
\t</p>
\t</br>
\t<p class=\"rate1 inforate\">";
        // line 381
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.money_update")), "html", null, true);
        echo "</p>
</div>";
    }

    public function getTemplateName()
    {
        return "category.rate.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  821 => 381,  813 => 378,  805 => 373,  801 => 372,  795 => 369,  788 => 365,  784 => 364,  778 => 361,  771 => 357,  767 => 356,  761 => 353,  754 => 349,  750 => 348,  744 => 345,  737 => 341,  733 => 340,  727 => 337,  720 => 333,  716 => 332,  710 => 329,  703 => 325,  699 => 324,  693 => 321,  686 => 317,  682 => 316,  676 => 313,  669 => 309,  665 => 308,  659 => 305,  652 => 301,  648 => 300,  642 => 297,  635 => 293,  631 => 292,  625 => 289,  618 => 285,  614 => 284,  608 => 281,  601 => 277,  597 => 276,  591 => 273,  584 => 269,  580 => 268,  574 => 265,  567 => 261,  563 => 260,  557 => 257,  546 => 251,  538 => 246,  534 => 245,  528 => 242,  521 => 238,  517 => 237,  511 => 234,  504 => 230,  500 => 229,  494 => 226,  487 => 222,  483 => 221,  477 => 218,  470 => 214,  466 => 213,  460 => 210,  453 => 206,  449 => 205,  443 => 202,  436 => 198,  432 => 197,  426 => 194,  419 => 190,  415 => 189,  409 => 186,  402 => 182,  398 => 181,  392 => 178,  385 => 174,  381 => 173,  375 => 170,  368 => 166,  364 => 165,  358 => 162,  351 => 158,  347 => 157,  341 => 154,  334 => 150,  330 => 149,  324 => 146,  317 => 142,  313 => 141,  307 => 138,  300 => 134,  296 => 133,  290 => 130,  279 => 124,  271 => 119,  267 => 118,  261 => 115,  254 => 111,  250 => 110,  244 => 107,  237 => 103,  233 => 102,  227 => 99,  220 => 95,  216 => 94,  210 => 91,  203 => 87,  199 => 86,  193 => 83,  186 => 79,  182 => 78,  176 => 75,  169 => 71,  165 => 70,  159 => 67,  152 => 63,  148 => 62,  142 => 59,  135 => 55,  131 => 54,  125 => 51,  118 => 47,  114 => 46,  108 => 43,  101 => 39,  97 => 38,  91 => 35,  84 => 31,  80 => 30,  74 => 27,  67 => 23,  63 => 22,  57 => 19,  50 => 15,  46 => 14,  40 => 11,  33 => 7,  29 => 6,  23 => 3,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "category.rate.twig", "");
    }
}
