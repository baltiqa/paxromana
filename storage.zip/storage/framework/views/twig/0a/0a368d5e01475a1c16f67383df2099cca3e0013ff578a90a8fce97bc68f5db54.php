<?php

/* /var/www/html/html/resources/themes/default/account/trashedlistings.twig */
class __TwigTemplate_ea65c7b66602a6ca6ea4b3a5ccd5404005fd6c6ee6e1b8f24ecbd388839c45b6 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/trashedlistings.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 8
    public function block_user_area($context, array $blocks = array())
    {
        // line 9
        echo "\t<section id=\"content\">
\t\t<div id=\"seller-panel\">
\t\t\t";
        // line 11
        $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/trashedlistings.twig", 11)->display($context);
        // line 12
        echo "\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 13
            echo "\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t";
            // line 16
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method");
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t";
        }
        // line 20
        echo "\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 21
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 24
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method");
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t";
        }
        // line 28
        echo "\t\t\t<div class=\"canvas\">
\t\t\t\t<div id=\"ad-listing-table\" class=\"table ad-listing-container seller\">
\t\t\t\t\t<div id=\"table-head-stickies\">
\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div style=\"width:21%;margin:5px;\" class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t<div id=\"tableActionPanel\">
\t\t\t\t\t\t\t\t\t\t<form action=\"";
        // line 35
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.permanent.listings"));
        echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 36
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"mp-Button mp-Button--primary mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-delete-white\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_permanent_delete")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 44
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_prod")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 47
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 50
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 53
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_supp")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 56
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_views")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell position-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 59
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_action")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t<a style=\"float:right;\" href=\"/account/listings\" class=\"mp-Button mp-Button--primary mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 61
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_go_back")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["listings"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 69
            echo "\t\t\t\t\t\t\t<div id=\"ad-listing-table-body\" class=\"table-body\">
\t\t\t\t\t\t\t\t<div class=\"row ad-listing compact\">
\t\t\t\t\t\t\t\t\t<div class=\"cells\">
\t\t\t\t\t\t\t\t\t\t<div class=\"cell icon-column middle\">
\t\t\t\t\t\t\t\t\t\t\t<input name=\"ids[]\" value=\"";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\" type=\"checkbox\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell thumbnail-column\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 76
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["item"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["item"], "title", array()))))));
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getPhoto", array(), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"flex-row\">
\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"font-size:12px;\" class=\"type\">";
            // line 80
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["item"], "price", array()), $this->getAttribute($context["item"], "currency", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\" style=\"width: 16%;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"description-title\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 85
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["item"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["item"], "title", array()))))));
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 86
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
            echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity disabled\">";
            // line 92
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_deleted")), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity\">";
            // line 97
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "orders", array()), "count", array(), "method"), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity\">";
            // line 102
            echo twig_escape_filter($this->env, ((($this->getAttribute($context["item"], "quantity", array()) ==  -1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_unlimited"))) : ($this->getAttribute($context["item"], "quantity", array()))), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"amount\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--sm mp-svg-eye-open-grey mp-hide-sm\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 108
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "views_count", array()), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell position-column features-column\" style=\"width: 26%;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"cta\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 112
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.restore.listings", $this->getAttribute($context["item"], "id", array())));
            echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 113
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_restore")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 121
        echo "\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t</div>
</section>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/trashedlistings.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  249 => 121,  235 => 113,  231 => 112,  224 => 108,  215 => 102,  207 => 97,  199 => 92,  190 => 86,  186 => 85,  176 => 80,  170 => 77,  166 => 76,  160 => 73,  154 => 69,  150 => 68,  140 => 61,  135 => 59,  129 => 56,  123 => 53,  117 => 50,  111 => 47,  105 => 44,  97 => 39,  91 => 36,  87 => 35,  78 => 28,  71 => 24,  66 => 21,  63 => 20,  56 => 16,  51 => 13,  48 => 12,  46 => 11,  42 => 9,  39 => 8,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/trashedlistings.twig", "");
    }
}
