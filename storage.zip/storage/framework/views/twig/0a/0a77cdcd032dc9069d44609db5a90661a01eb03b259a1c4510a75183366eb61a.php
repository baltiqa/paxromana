<?php

/* /var/www/html/html/resources/themes/default/inbox/show.twig */
class __TwigTemplate_52fd5fabab9c5ff60e0c70940bf31427e020531758538f1fe8c2ed0eb2fa5054 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/inbox/show.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/message.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "\t<div class=\"wide-layout\" id=\"page-wrapper\">

\t\t<div class=\"l-page indexpage\" id=\"content\" style=\"height: 800px;margin-bottom:150px;\">
\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t<li>
\t\t\t\t";
        // line 14
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_antiphishing_warning"));
        echo "
\t\t\t\t</li>
\t\t\t</div>

\t\t\t<div class=\"inbox-messages chatheader\">
\t\t\t\t<div class=\"messages-left\">
\t\t\t\t\t<div class=\"mp-Card message-left-header\">
\t\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t\t<h1>";
        // line 22
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_messages")), "html", null, true);
        echo "</h1>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"message-left-header-shadow\">
\t\t\t\t\t\t<div class=\"ConversationsToolsMolecule-root\"></div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"message-left-part\">
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t<ol class=\"ConversationsOrganism-listRoot\">
\t\t\t\t\t\t\t\t";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["inboxes"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["inbox"]) {
            // line 32
            echo "\t\t\t\t\t\t\t\t\t<li class=\"ConversationsOrganism-listItem\">
\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-root ConversationMolecule-";
            // line 33
            echo (((($context["id"] ?? null) == $this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "conversation_id", array()))) ? ("rootOpen") : ("selling"));
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 34
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("inbox.show", $this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "conversation_id", array())));
            echo "#chat\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-leftUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-thumbnailUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ThumbnailAtom-root ThumbnailAtomSizes-lg ThumbnailAtomBorderRadii-xs\" style=\"background-image: url(&quot;";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "getAvatar", array(), "method"), "html", null, true);
            echo "&quot;);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-thumbnailProfilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-sm ProfilePictureAtom-rootBordered ";
            // line 39
            echo ((((($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_mod", array()) == 1) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_headmod", array()) == 1)) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_admin", array()) == 1))) ? ("staff") : (""));
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 40
            echo twig_escape_filter($this->env, twig_first($this->env, $this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "username", array())), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-rightUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<h2 class=\"ConversationMolecule-title\">";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "username", array()), "html", null, true);
            echo "</h2>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 47
            if (( !$this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "is_seen", array()) && ($this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "user_id", array()) != $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array())))) {
                // line 48
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationMolecule-titleBadgeUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"BadgeAtom-root\">1</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 52
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-meta\">from
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "username", array()), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-latestMessageWrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 56
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('str_limit')->getCallable(), array("limit", call_user_func_array($this->env->getFilter('filter_message')->getCallable(), array($this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "message", array()))), 18)), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-left card-";
            // line 57
            echo ((((($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_mod", array()) == 1) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_headmod", array()) == 1)) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_admin", array()) == 1))) ? ("staff") : ("user"));
            echo "\">";
            echo ((((($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_mod", array()) == 1) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_headmod", array()) == 1)) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_admin", array()) == 1))) ? ("Romana Staff") : (((($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "trader_type", array()) == "individual")) ? ("Vendor") : ("Buyer"))));
            echo "</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<footer>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-receivedDateUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "created_at", array()), "diffForHumans", array(), "method"), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</footer>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['inbox'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "
\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<a name=\"chat\"></a>
\t\t\t\t<div class=\"chatindividual part2\">
\t\t\t\t\t<div class=\"chatbox\">
\t\t\t\t\t\t<header>
\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-root\">
\t\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-titleUnit\">
\t\t\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-backLinkUnit\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<h2 class=\"ConversationTopicOrganism-title\">
\t\t\t\t\t\t\t\t\t\t";
        // line 84
        if (((($context["secondUser"] ?? null) != null) && (($context["inviter"] ?? null) != null))) {
            // line 85
            echo "\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["secondUser"] ?? null), "username", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-profilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-md ";
            // line 87
            echo ((((($this->getAttribute(($context["secondUser"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["secondUser"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["secondUser"] ?? null), "is_admin", array()) == 1))) ? ("staff") : (""));
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 88
            echo twig_escape_filter($this->env, twig_first($this->env, $this->getAttribute(($context["secondUser"] ?? null), "username", array())), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t</span> 
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-name\">";
            // line 91
            echo twig_escape_filter($this->env, $this->getAttribute(($context["secondUser"] ?? null), "username", array()), "html", null, true);
            echo "<p class=\"card-blanc card-";
            echo ((((($this->getAttribute(($context["secondUser"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["secondUser"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["secondUser"] ?? null), "is_admin", array()) == 1))) ? ("staff") : ("user"));
            echo " \">";
            echo ((((($this->getAttribute(($context["secondUser"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["secondUser"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["secondUser"] ?? null), "is_admin", array()) == 1))) ? ("Romana Staff") : (((($this->getAttribute(($context["secondUser"] ?? null), "trader_type", array()) == "individual")) ? ("Vendor") : ("Buyer"))));
            echo "</p></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute(($context["inviter"] ?? null), "username", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-profilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-md ";
            // line 95
            echo ((((($this->getAttribute(($context["inviter"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["inviter"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["inviter"] ?? null), "is_admin", array()) == 1))) ? ("staff") : (""));
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 96
            echo twig_escape_filter($this->env, twig_first($this->env, $this->getAttribute(($context["inviter"] ?? null), "username", array())), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t</span> 
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-name\">(Invited)";
            // line 99
            echo twig_escape_filter($this->env, $this->getAttribute(($context["inviter"] ?? null), "username", array()), "html", null, true);
            echo " <p class=\"card-blanc card-";
            echo ((((($this->getAttribute(($context["inviter"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["inviter"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["inviter"] ?? null), "is_admin", array()) == 1))) ? ("staff") : ("user"));
            echo " \">";
            echo ((((($this->getAttribute(($context["inviter"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["inviter"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["inviter"] ?? null), "is_admin", array()) == 1))) ? ("Romana Staff") : (((($this->getAttribute(($context["inviter"] ?? null), "trader_type", array()) == "individual")) ? ("Vendor") : ("Buyer"))));
            echo "</p></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 102
        echo "\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["recipient"] ?? null), "username", array()), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-profilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-md ";
        // line 104
        echo ((((($this->getAttribute(($context["recipient"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["recipient"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["recipient"] ?? null), "is_admin", array()) == 1))) ? ("staff") : (""));
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
        // line 105
        echo twig_escape_filter($this->env, twig_first($this->env, $this->getAttribute(($context["recipient"] ?? null), "username", array())), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t</span> 
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-name\">";
        // line 108
        echo twig_escape_filter($this->env, $this->getAttribute(($context["recipient"] ?? null), "username", array()), "html", null, true);
        echo " <p class=\"card-blanc card-";
        echo ((((($this->getAttribute(($context["recipient"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["recipient"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["recipient"] ?? null), "is_admin", array()) == 1))) ? ("staff") : ("user"));
        echo "\">";
        echo ((((($this->getAttribute(($context["recipient"] ?? null), "is_mod", array()) == 1) || ($this->getAttribute(($context["recipient"] ?? null), "is_headmod", array()) == 1)) || ($this->getAttribute(($context["recipient"] ?? null), "is_admin", array()) == 1))) ? ("Romana Staff") : (((($this->getAttribute(($context["recipient"] ?? null), "trader_type", array()) == "individual")) ? ("Vendor") : ("Buyer"))));
        echo "</p></span>
\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t\t\t";
        // line 112
        if ((($context["inviter"] ?? null) == null)) {
            // line 113
            echo "\t\t\t\t\t\t\t\t\t<form action=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("invite.message", ($context["id"] ?? null)));
            echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t";
            // line 114
            echo csrf_field();
            echo "
\t\t\t\t\t\t\t\t\t<div class=\"px-invite\">
\t\t\t\t\t\t\t\t\t<button style=\"float:right;\" class=\"mp-Button mp-Button--secondary mp-Button--xs searchnew\" type=\"submit\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-search style-scope mp-Header\"></span>
\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t<input style=\"float:right;width:60%;\" class=\"mp-Input style-scope newinput\" placeholder=\"Invite 1 friend..\" name=\"username\" type=\"text\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t";
        }
        // line 123
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</header>
\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t<div class=\"MessagesOrganism-root\">
\t\t\t\t\t\t\t<div class=\"LegalDisclaimerMolecule-root\">";
        // line 129
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_warning"));
        echo "
\t\t\t\t\t\t\t\t\t<a target=\"_blank\" href=\"/wiki/43\" rel=\"noopener noreferrer\">";
        // line 130
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_read_more")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--xs mp-svg-arrow-right--action\"></span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        // line 134
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["messages"] ?? null));
        foreach ($context['_seq'] as $context["k"] => $context["fam"]) {
            // line 135
            echo "\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<h3 class=\"DateHeadingMolecule-root\">
\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 137
            echo twig_escape_filter($this->env, $context["k"], "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t\t";
            // line 139
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["fam"]);
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 140
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute(($context["recipient"] ?? null), "id", array()) == $this->getAttribute($this->getAttribute($context["msg"], "sender", array()), "id", array()))) {
                    // line 141
                    echo "\t\t\t\t\t\t\t\t\t<div class=\"MessagesOrganism-group\">
\t\t\t\t\t\t\t\t\t\t<ol class=\"MessagesOrganism-listRoot\">
\t\t\t\t\t\t\t\t\t\t\t<li class=\"MessagesOrganism-listItem MessagesOrganism-listItem_from_otherparticipant\">
\t\t\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>(";
                    // line 145
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["recipient"] ?? null), "username", array()), "html", null, true);
                    echo ")</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-root MessageMolecule-root_from_otherparticipant MessageMolecule-tail\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"Linkify\">";
                    // line 148
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('filter_message')->getCallable(), array($this->getAttribute($context["msg"], "message", array()))), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"MessageMolecule-receivedDatePlaceholder\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-meta \">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span><small style=\"font-size:9px;\">";
                    // line 152
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["msg"], "created_at", array()), "toTimeString", array(), "method"), "html", null, true);
                    echo "</small></span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                }
                // line 160
                echo "
\t\t\t\t\t\t\t\t";
                // line 161
                if (($this->getAttribute(($context["recipient"] ?? null), "id", array()) != $this->getAttribute($this->getAttribute($context["msg"], "sender", array()), "id", array()))) {
                    // line 162
                    echo "\t\t\t\t\t\t\t\t\t<div class=\"MessagesOrganism-group\">
\t\t\t\t\t\t\t\t\t\t<ol class=\"MessagesOrganism-listRoot\">
\t\t\t\t\t\t\t\t\t\t\t<li class=\"MessagesOrganism-listItem MessagesOrganism-listItem_from_me\">
\t\t\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>(";
                    // line 166
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["msg"], "sender", array()), "username", array()), "html", null, true);
                    echo ")</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-root MessageMolecule-root_from_me MessageMolecule-tail\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"Linkify\">";
                    // line 169
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('filter_message')->getCallable(), array($this->getAttribute($context["msg"], "message", array()))), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"MessageMolecule-receivedDatePlaceholder\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-meta MessageMolecule-sender\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span><small>";
                    // line 173
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["msg"], "created_at", array()), "toTimeString", array(), "method"), "html", null, true);
                    echo "</small></span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"MessageMolecule-readStatusWrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 175
                    if ($this->getAttribute($context["msg"], "is_seen", array())) {
                        // line 176
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"MessageReadStatusAtom-root\" title=\"";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_read")), "html", null, true);
                        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-sdk-svg-wrapper \" style=\"width: 18px; height: 18px;\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mp-sdk-svg mp-svg-checkmark-thick--success\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-sdk-svg-wrapper \" style=\"width: 18px; height: 18px;\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mp-sdk-svg mp-svg-checkmark-thick--success\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 185
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"MessageReadStatusAtom-root\" title=\"";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_sent")), "html", null, true);
                        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-sdk-svg-wrapper \" style=\"width: 18px; height: 18px;\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mp-sdk-svg mp-svg-checkmark-thick--secondary\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-sdk-svg-wrapper \" style=\"width: 18px; height: 18px;\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mp-sdk-svg mp-svg-checkmark-thick--secondary\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 194
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                }
                // line 202
                echo "\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 203
            echo "\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['fam'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 204
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</article>
\t\t\t\t\t<footer>
\t\t\t\t\t\t<div class=\"SmartSuggestionsOrganism-root\"></div>
\t\t\t\t\t\t<section class=\"MessageComposerOrganism-root\">
\t\t\t\t\t\t\t<form action=\"";
        // line 209
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("send.message"));
        echo "\" method=\"post\" style=\"display: contents;\">
\t\t\t\t\t\t\t\t";
        // line 210
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t\t<input name=\"recipient_id\" type=\"hidden\" value=\"";
        // line 211
        echo twig_escape_filter($this->env, ($context["id"] ?? null), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t<textarea name=\"message\" class=\"text-box ";
        // line 213
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "message"), "method")) ? (" invalid") : (""));
        echo "\" placeholder=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_write_comment")), "html", null, true);
        echo "\"></textarea>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"MessageComposerOrganism-send MessageComposerOrganism-empty\">
\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t<button title=\"Sturen\" tabindex=\"0\" class=\"mp-Button mp-Button--primary mp-Button--md\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-send--inverse\"></span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t\t<nav class=\"InlineComposerMenuMolecule-root\">
\t\t\t\t\t\t\t\t<a href=\"#report\" title=\"Report\" style=\"float: right;\" class=\"InlineComposerMenuOptionAtom-root\">
\t\t\t\t\t\t\t\t\t<span class=\"InlineComposerMenuOptionAtom-iconAirlock\">
\t\t\t\t\t\t\t\t\t\t<i class=\"mp-sdk-svg mp-svg-alert-blue\"></i>
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t<span style=\"float:right;\" title=\"Encrypt PGP\" class=\"InlineComposerMenuOptionAtom-root\">
\t\t\t\t\t\t\t\t\t<span class=\"InlineComposerMenuOptionAtom-iconAirlock\">
\t\t\t\t\t\t\t\t\t\t<i class=\"mp-sdk-svg mp-pgp-image\"></i>
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t";
        // line 234
        if (($this->getAttribute(($context["recipient"] ?? null), "pgp_key", array()) != null)) {
            // line 235
            echo "\t\t\t\t\t\t\t\t\t\t<input class=\"pgp\" type=\"checkbox\" name=\"encrypt\" value=\"1\">
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 237
            echo "\t\t\t\t\t\t\t\t\t\t<span class=\"InlineComposerMenuOptionAtom-label\">N/A PGP</span>
\t\t\t\t\t\t\t\t\t";
        }
        // line 239
        echo "\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t</nav>
\t\t\t\t\t\t</form>
\t\t\t\t\t</footer>
\t\t\t\t\t<div id=\"report\" class=\"overlay\">
\t\t\t\t\t\t<div class=\"popup\">
\t\t\t\t\t\t\t<h2>";
        // line 248
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_report_title")), "html", null, true);
        echo "#";
        echo twig_escape_filter($this->env, ($context["id"] ?? null), "html", null, true);
        echo "</h2>
\t\t\t\t\t\t\t<a class=\"close\" href=\"#\">&times;</a>
\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t\t";
        // line 251
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 252
            echo "\t\t\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t";
            // line 255
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
        }
        // line 259
        echo "\t\t\t\t\t\t\t\t";
        if ( !$this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "ifReportConversationIsDone", array(0 => ($context["id"] ?? null)), "method")) {
            // line 260
            echo "\t\t\t\t\t\t\t\t\t<p>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_report_text")), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t\t<form action=\"";
            // line 261
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("report.message", ($context["id"] ?? null)));
            echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t";
            // line 262
            echo csrf_field();
            echo "

\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<label>";
            // line 265
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_reason")), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t\t\t\t\t<input style=\"width:100%;height:80px;\" id=\"reason\" type=\"text\" placeholder=\"";
            // line 266
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_reason")), "html", null, true);
            echo "\" name=\"reason\" class=\"mp-Input ";
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "reason"), "method")) ? (" invalid") : (""));
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<label>";
            // line 270
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_extra")), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t\t\t\t\t<input style=\"width:100%;height:80px;\" id=\"notes\" type=\"text\" placeholder=\"";
            // line 271
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_notes")), "html", null, true);
            echo "\" name=\"notes\" class=\"mp-Input ";
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "notes"), "method")) ? (" invalid") : (""));
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"/captcha.html\"/>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"mp-Form-controlGroup-label optional-label\" for=\"captcha\">Captcha</label>
\t\t\t\t\t\t\t\t\t\t\t<input style=\"width:50%;\" id=\"captcha\" type=\"text\" placeholder=\"captcha\" name=\"captcha\" class=\"mp-Input ";
            // line 277
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
            echo "\" tabindex=\"2\">
\t\t\t\t\t\t\t\t\t\t\t";
            // line 278
            if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) {
                // line 279
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 280
                echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "captcha"), "method"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 283
            echo "\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"buttonbar\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"submit\" class=\"mp-Button mp-Button--primary\" value=\"";
            // line 286
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_sent")), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t";
        } else {
            // line 290
            echo "\t\t\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t";
            // line 293
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_received")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
        }
        // line 297
        echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/inbox/show.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  593 => 297,  586 => 293,  581 => 290,  574 => 286,  569 => 283,  563 => 280,  560 => 279,  558 => 278,  554 => 277,  543 => 271,  539 => 270,  530 => 266,  526 => 265,  520 => 262,  516 => 261,  511 => 260,  508 => 259,  501 => 255,  496 => 252,  494 => 251,  486 => 248,  475 => 239,  471 => 237,  467 => 235,  465 => 234,  439 => 213,  434 => 211,  430 => 210,  426 => 209,  419 => 204,  413 => 203,  407 => 202,  397 => 194,  384 => 185,  371 => 176,  369 => 175,  364 => 173,  357 => 169,  351 => 166,  345 => 162,  343 => 161,  340 => 160,  329 => 152,  322 => 148,  316 => 145,  310 => 141,  307 => 140,  303 => 139,  298 => 137,  294 => 135,  290 => 134,  283 => 130,  279 => 129,  271 => 123,  259 => 114,  254 => 113,  252 => 112,  241 => 108,  235 => 105,  231 => 104,  225 => 102,  215 => 99,  209 => 96,  205 => 95,  200 => 93,  191 => 91,  185 => 88,  181 => 87,  175 => 85,  173 => 84,  157 => 70,  143 => 62,  133 => 57,  129 => 56,  124 => 54,  120 => 52,  114 => 48,  112 => 47,  108 => 46,  99 => 40,  95 => 39,  90 => 37,  84 => 34,  80 => 33,  77 => 32,  73 => 31,  61 => 22,  50 => 14,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/inbox/show.twig", "");
    }
}
