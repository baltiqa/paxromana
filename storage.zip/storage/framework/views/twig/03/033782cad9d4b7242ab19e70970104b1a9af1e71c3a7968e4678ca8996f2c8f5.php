<?php

/* /var/www/html/html/resources/themes/default/account/listings.twig */
class __TwigTemplate_2794e186da1eaff133f9813de1fad88f6228125f16112438934f055fdc7916b1 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/listings.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 8
    public function block_user_area($context, array $blocks = array())
    {
        // line 9
        echo "\t<section id=\"content\">
\t\t<div id=\"seller-panel\">
\t\t\t";
        // line 11
        $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/listings.twig", 11)->display($context);
        // line 12
        echo "\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 13
            echo "\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t";
        }
        // line 20
        echo "\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 21
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t";
        }
        // line 28
        echo "\t\t\t<div class=\"canvas\">
\t\t\t\t<div id=\"ad-listing-table\" class=\"table ad-listing-container seller\">
\t\t\t\t\t<div id=\"table-head-stickies\">
\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div style=\"width:21%;margin:5px;\" class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t<div id=\"tableActionPanel\">
\t\t\t\t\t\t\t\t\t\t<form action=\"";
        // line 35
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.remove.listings"));
        echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 36
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"mp-Button mp-Button--primary mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-delete-white\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.notifications_delete_1")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 44
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_prod")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 47
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 50
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 53
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_supp")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 56
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_views")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"cell position-column\">
\t\t\t\t\t\t\t\t\t\t<span>";
        // line 59
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_action")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t<a style=\"float:right;\" href=\"";
        // line 60
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.trash.listings"));
        echo "\" class=\"mp-Button mp-Button--primary mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-delete-white\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 62
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_trashed")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, ($context["listings_deleted_count"] ?? null), "html", null, true);
        echo ")
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        // line 69
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["listings"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 70
            echo "\t\t\t\t\t\t\t<div id=\"ad-listing-table-body\" class=\"table-body\">
\t\t\t\t\t\t\t\t<div class=\"row ad-listing compact\">
\t\t\t\t\t\t\t\t\t<div class=\"cells\">
\t\t\t\t\t\t\t\t\t\t<div class=\"cell icon-column middle\">
\t\t\t\t\t\t\t\t\t\t\t<input name=\"ids[]\" value=\"";
            // line 74
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
            echo "\" type=\"checkbox\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell thumbnail-column\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 77
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["item"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["item"], "title", array()))))));
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getPhoto", array(), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"flex-row\">
\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"font-size:12px;\" class=\"type\">";
            // line 81
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["item"], "price", array()), $this->getAttribute($context["item"], "currency", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\" style=\"width: 16%;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"description-title\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 86
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["item"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["item"], "title", array()))))));
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>(parent)";
            // line 87
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
            echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 89
            if (($this->getAttribute($context["item"], "spotlight", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                // line 90
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<b>Ads+++:</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"active\">";
                // line 92
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "spotlight"), "method"), "days", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 93
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 94
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "spotlight"), "method"), "hours", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 95
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 96
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "spotlight"), "method"), "minutes", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 97
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 100
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">Ads+++:
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"disabled\">";
                // line 101
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.not_active")), "html", null, true);
                echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 104
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            if (($this->getAttribute($context["item"], "priority_until", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                // line 105
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<b>Ads ++:</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"active\">";
                // line 107
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "priority_until"), "method"), "days", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 108
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 109
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "priority_until"), "method"), "hours", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 110
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 111
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "priority_until"), "method"), "minutes", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 112
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 115
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">Ads++:
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"disabled\">";
                // line 116
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.not_active")), "html", null, true);
                echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 119
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            if (($this->getAttribute($context["item"], "bold_until", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                // line 120
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<b>Ads+:</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"active\">";
                // line 122
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "bold_until"), "method"), "days", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 123
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 124
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "bold_until"), "method"), "hours", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 125
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 126
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "bold_until"), "method"), "minutes", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 127
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 130
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">Ads+:
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"disabled\">";
                // line 131
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.not_active")), "html", null, true);
                echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 134
            echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity ";
            // line 138
            echo ((($this->getAttribute($context["item"], "is_published", array()) == 1)) ? ("active") : ("disabled"));
            echo "\">";
            echo twig_escape_filter($this->env, ((($this->getAttribute($context["item"], "is_published", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.active"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_2")))), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity\">";
            // line 143
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "orders", array()), "count", array(), "method"), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity\">";
            // line 148
            echo twig_escape_filter($this->env, ((($this->getAttribute($context["item"], "quantity", array()) ==  -1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_unlimited"))) : ($this->getAttribute($context["item"], "quantity", array()))), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"amount\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--sm mp-svg-eye-open-grey mp-hide-sm\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 154
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "views_count", array()), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell position-column features-column\" style=\"width: 26%;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"cta\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 158
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.ads", $context["item"]));
            echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\tAds
\t\t\t\t\t\t\t\t\t\t\t\t</a>|
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 161
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.edit", $context["item"]));
            echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 162
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_edit")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>|<a href=\"";
            // line 163
            echo ((($this->getAttribute($context["item"], "is_published", array()) != 1)) ? (call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.enable", $context["item"]))) : (call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.disable", $context["item"]))));
            echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 164
            echo twig_escape_filter($this->env, ((($this->getAttribute($context["item"], "is_published", array()) != 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_1"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_2")))), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</a>|<a href=\"";
            // line 166
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.clone", $context["item"]));
            echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 167
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_clone")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            // line 174
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["item"], "childs", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 175
                echo "\t\t\t\t\t\t\t<div id=\"ad-listing-table-body\" class=\"table-body child\">
\t\t\t\t\t\t\t\t<div class=\"row ad-listing compact\">
\t\t\t\t\t\t\t\t\t<div class=\"cells\">
\t\t\t\t\t\t\t\t\t\t<div class=\"cell icon-column middle\">
\t\t\t\t\t\t\t\t\t\t\t<input name=\"ids[]\" value=\"";
                // line 179
                echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "id", array()), "html", null, true);
                echo "\" type=\"checkbox\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell thumbnail-column\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 182
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["child"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["child"], "title", array()))))));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                // line 183
                echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "getPhoto", array(), "method"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"flex-row\">
\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"font-size:12px;\"  class=\"type\">";
                // line 186
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["child"], "price", array()), $this->getAttribute($context["child"], "currency", array())), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\" style=\"width: 16%;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"description-title\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 191
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["child"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["child"], "title", array()))))));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>(child)";
                // line 192
                echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "title", array()), "html", null, true);
                echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 194
                if (($this->getAttribute($context["child"], "spotlight", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                    // line 195
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<b>Ads+++:</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"active\">";
                    // line 197
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["child"], "until", array(0 => "spotlight"), "method"), "days", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 198
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 199
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["child"], "until", array(0 => "spotlight"), "method"), "hours", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 200
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 201
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["child"], "until", array(0 => "spotlight"), "method"), "minutes", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 202
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 205
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">Ads+++:
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"disabled\">";
                    // line 206
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.not_active")), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 209
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["child"], "priority_until", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                    // line 210
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<b>Ads ++:</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"active\">";
                    // line 212
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["child"], "until", array(0 => "priority_until"), "method"), "days", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 213
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 214
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["child"], "until", array(0 => "priority_until"), "method"), "hours", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 215
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 216
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["child"], "until", array(0 => "priority_until"), "method"), "minutes", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 217
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 220
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"adssize\">Ads++:
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"disabled\">";
                    // line 221
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.not_active")), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 224
                echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity ";
                // line 228
                echo ((($this->getAttribute($context["child"], "is_published", array()) == 1)) ? ("active") : ("disabled"));
                echo "\">";
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["child"], "is_published", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.active"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_2")))), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity\">";
                // line 233
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["child"], "orders", array()), "count", array(), "method"), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"listing-status\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"activity\">";
                // line 238
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["child"], "quantity", array()) ==  -1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_unlimited"))) : ($this->getAttribute($context["child"], "quantity", array()))), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell views-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"amount\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--sm mp-svg-eye-open-grey mp-hide-sm\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 244
                echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "views_count", array()), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell position-column features-column\" style=\"width: 20%;\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"cta\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 248
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.ads", $context["child"]));
                echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\tAds
\t\t\t\t\t\t\t\t\t\t\t\t</a>|
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 251
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.edit", $context["child"]));
                echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 252
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_edit")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>|<a href=\"";
                // line 253
                echo ((($this->getAttribute($context["child"], "is_published", array()) != 1)) ? (call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.enable", $context["child"]))) : (call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.disable", $context["child"]))));
                echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 254
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["child"], "is_published", array()) != 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_1"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_2")))), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 262
            echo "\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 263
        echo "\t\t\t\t</form>
\t\t\t\t<div class=\"mp-PaginationControls\">
\t\t\t\t\t";
        // line 265
        echo $this->getAttribute(($context["listings"] ?? null), "links", array(), "method");
        echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</section>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/listings.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  613 => 265,  609 => 263,  603 => 262,  589 => 254,  585 => 253,  581 => 252,  577 => 251,  571 => 248,  564 => 244,  555 => 238,  547 => 233,  537 => 228,  531 => 224,  525 => 221,  522 => 220,  516 => 217,  512 => 216,  508 => 215,  504 => 214,  500 => 213,  496 => 212,  492 => 210,  489 => 209,  483 => 206,  480 => 205,  474 => 202,  470 => 201,  466 => 200,  462 => 199,  458 => 198,  454 => 197,  450 => 195,  448 => 194,  443 => 192,  439 => 191,  429 => 186,  423 => 183,  419 => 182,  413 => 179,  407 => 175,  403 => 174,  393 => 167,  389 => 166,  384 => 164,  380 => 163,  376 => 162,  372 => 161,  366 => 158,  359 => 154,  350 => 148,  342 => 143,  332 => 138,  326 => 134,  320 => 131,  317 => 130,  311 => 127,  307 => 126,  303 => 125,  299 => 124,  295 => 123,  291 => 122,  287 => 120,  284 => 119,  278 => 116,  275 => 115,  269 => 112,  265 => 111,  261 => 110,  257 => 109,  253 => 108,  249 => 107,  245 => 105,  242 => 104,  236 => 101,  233 => 100,  227 => 97,  223 => 96,  219 => 95,  215 => 94,  211 => 93,  207 => 92,  203 => 90,  201 => 89,  196 => 87,  192 => 86,  182 => 81,  176 => 78,  172 => 77,  166 => 74,  160 => 70,  156 => 69,  144 => 62,  139 => 60,  135 => 59,  129 => 56,  123 => 53,  117 => 50,  111 => 47,  105 => 44,  97 => 39,  91 => 36,  87 => 35,  78 => 28,  71 => 24,  66 => 21,  63 => 20,  56 => 16,  51 => 13,  48 => 12,  46 => 11,  42 => 9,  39 => 8,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/listings.twig", "");
    }
}
