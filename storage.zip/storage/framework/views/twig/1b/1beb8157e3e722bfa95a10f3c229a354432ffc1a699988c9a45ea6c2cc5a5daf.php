<?php

/* /var/www/html/html/resources/themes/default/profile/show.twig */
class __TwigTemplate_95427ace7dc6aa6ba8c219826426b92529864f2c58546e36ae756b2f092e8c5e extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/profile/show.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"/web/css/own_profile_detail.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t\t";
        // line 10
        $this->loadTemplate("profile.head-profile.twig", "/var/www/html/html/resources/themes/default/profile/show.twig", 10)->display($context);
        // line 11
        echo "\t\t\t<div class=\"l-main-left\">
\t\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t   <div class=\"mp-Card-block\">
\t\t\t\t\t";
        // line 14
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab1")), "html", null, true);
        echo "
\t\t\t\t   </div>
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<div class=\"dealer-description\">
\t\t\t\t\t\t\t";
        // line 18
        echo nl2br(strip_tags(call_user_func_array($this->env->getFilter('xss_clean')->getCallable(), array(call_user_func_array($this->env->getFilter('bbc2html')->getCallable(), array(twig_convert_encoding($this->getAttribute(($context["profile"] ?? null), "bio", array()), "UTF-8", "HTML-ENTITIES"))))), "<b>,<i>,<u>,<ul>,<li>,<span>,<h1><h2><h3>"));
        echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div style=\"margin-top:20px;\" class=\"mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pgp_key_of")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "username", array()), "html", null, true);
        echo "
\t\t\t\t   </div>
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<div class=\"dealer-description\">
\t\t\t\t\t\t\t<pre style=\"word-wrap: break-word; white-space: pre-wrap; line-height: normal;\">";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "pgp_key", array()), "html", null, true);
        echo "</pre>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<aside class=\"l-side-right\">
\t\t\t";
        // line 34
        if (($this->getAttribute(($context["profile"] ?? null), "trader_type", array()) == "individual")) {
            // line 35
            echo "\t\t\t\t<div class=\"contact-info mp-Card mp-Card--rounded\">
\t\t\t\t\t<div class=\"mp-Card-block seller-info\">
\t\t\t\t\t\t";
            // line 37
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_vendorinfo")), "html", null, true);
            echo "
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"mp-Card-block mp-Card-block\">
\t\t\t\t\t\t<ul class=\"sales\">
\t\t\t\t\t\t\t";
            // line 41
            if (($this->getAttribute($this->getAttribute(($context["profile"] ?? null), "markets", array()), "count", array(), "method") != 0)) {
                // line 42
                echo "\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["profile"] ?? null), "markets", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["markets"]) {
                    // line 43
                    echo "\t\t\t\t\t\t\t\t";
                    if (($this->getAttribute($context["markets"], "market_title", array()) == "Silk")) {
                        // line 44
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Silk Road\" src=\"/web/images/si.png\"/> 
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 48
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 49
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"normal\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 52
$context["markets"], "market_title", array()) == "Berlus")) {
                        // line 53
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Berlusconi Market\" src=\"/web/images/ber.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 57
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 58
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"normal\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 62
$context["markets"], "market_title", array()) == "Dream")) {
                        // line 63
                        echo "
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Dream Market\" src=\"/web/images/d.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 68
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t\t(<i class=\"normal\">";
                        // line 69
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "rate", array()), "html", null, true);
                        echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"smstar\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t\t\t\t\t\t\t</b>)</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 77
$context["markets"], "market_title", array()) == "Samsara")) {
                        // line 78
                        echo "
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"SamSara Market\" src=\"/web/images/samsara.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 83
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 84
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"normal\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>


\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 90
$context["markets"], "market_title", array()) == "Empire")) {
                        // line 91
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Empire Market\" src=\"/web/images/eeim.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 95
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 96
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"normal\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 101
$context["markets"], "market_title", array()) == "Cryptonia")) {
                        // line 102
                        echo "
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Cryptonia Market\" src=\"/web/images/cd.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 107
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 108
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "percentage", array()), "html", null, true);
                        echo "%</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 112
$context["markets"], "market_title", array()) == "Nightmare")) {
                        // line 113
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Nightmare Market\" src=\"/web/images/nih.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 117
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 118
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 123
$context["markets"], "market_title", array()) == "Apollon")) {
                        // line 124
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Apollon Market\" src=\"/web/images/apol.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 128
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 129
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"normal\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 134
$context["markets"], "market_title", array()) == "Tochka")) {
                        // line 135
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Tochka Market\" src=\"/web/images/tochka.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 139
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 140
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"normal\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 145
$context["markets"], "market_title", array()) == "Grey")) {
                        // line 146
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Grey Market\" src=\"/web/images/grey.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 150
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t\t(<i class=\"normal\">";
                        // line 151
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "rate", array()), "html", null, true);
                        echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"smstar\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t\t\t\t\t\t\t</b>)</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 159
$context["markets"], "market_title", array()) == "Dark")) {
                        // line 160
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Dark Market\" src=\"/web/images/darkm.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 164
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 165
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"normal\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                    } elseif (($this->getAttribute(                    // line 170
$context["markets"], "market_title", array()) == "Wallstreet")) {
                        // line 171
                        echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Wallstreet Market\" src=\"/web/images/walls.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                        // line 175
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                        echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                        // line 176
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                        echo "</i>/<i class=\"normal\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                        echo "</i>/<i class=\"red\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                        echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
                    }
                    // line 182
                    echo "\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['markets'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 183
                echo "\t\t\t\t\t\t\t";
            } else {
                // line 184
                echo "\t\t\t\t\t\t\t<p>";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales_nothing")), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t";
            }
            // line 186
            echo "\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
        }
        // line 190
        echo "

\t\t\t\t<div class=\"contact-info mp-Card mp-Card--rounded\">
\t\t\t\t\t<div class=\"mp-Card-block seller-info\">
\t\t\t\t\t\t";
        // line 194
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_gen_info")), "html", null, true);
        echo "
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"mp-Card-block mp-Card-block\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t ";
        // line 198
        if (($this->getAttribute(($context["profile"] ?? null), "trader_type", array()) == "individual")) {
            // line 199
            echo "\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<span>";
            // line 200
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_disputes")), "html", null, true);
            echo ":<b>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_won")), "html", null, true);
            echo ":<i class=\"green\">";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "countDisputeWin", array(), "method"), "html", null, true);
            echo "</i>/";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_lost")), "html", null, true);
            echo ":<i class=\"red\">";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "countDisputeLoss", array(), "method"), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<span>Sold:<b><i>";
            // line 205
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["profile"] ?? null), "orders", array()), "count", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t";
        } else {
            // line 210
            echo "\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<span>";
            // line 211
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_disputes")), "html", null, true);
            echo ":<b>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_won")), "html", null, true);
            echo ":<i class=\"green\">";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "countBuyerDisputeWin", array(), "method"), "html", null, true);
            echo "</i>/";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_lost")), "html", null, true);
            echo ":<i class=\"red\">";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "countBuyerDisputeLoss", array(), "method"), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t";
        }
        // line 216
        echo "\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<span>";
        // line 217
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_orders_placed")), "html", null, true);
        echo ":<b><i>";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["profile"] ?? null), "normal_orders", array()), "count", array()), "html", null, true);
        echo "</i>
\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</li>\t\t\t\t\t
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</aside>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/profile/show.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  496 => 217,  493 => 216,  477 => 211,  474 => 210,  466 => 205,  450 => 200,  447 => 199,  445 => 198,  438 => 194,  432 => 190,  426 => 186,  420 => 184,  417 => 183,  411 => 182,  398 => 176,  392 => 175,  386 => 171,  384 => 170,  372 => 165,  366 => 164,  360 => 160,  358 => 159,  347 => 151,  341 => 150,  335 => 146,  333 => 145,  321 => 140,  315 => 139,  309 => 135,  307 => 134,  295 => 129,  289 => 128,  283 => 124,  281 => 123,  271 => 118,  265 => 117,  259 => 113,  257 => 112,  250 => 108,  244 => 107,  237 => 102,  235 => 101,  223 => 96,  217 => 95,  211 => 91,  209 => 90,  196 => 84,  190 => 83,  183 => 78,  181 => 77,  170 => 69,  164 => 68,  157 => 63,  155 => 62,  144 => 58,  138 => 57,  132 => 53,  130 => 52,  120 => 49,  114 => 48,  108 => 44,  105 => 43,  100 => 42,  98 => 41,  91 => 37,  87 => 35,  85 => 34,  76 => 28,  67 => 24,  58 => 18,  51 => 14,  46 => 11,  44 => 10,  40 => 8,  37 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/profile/show.twig", "");
    }
}
