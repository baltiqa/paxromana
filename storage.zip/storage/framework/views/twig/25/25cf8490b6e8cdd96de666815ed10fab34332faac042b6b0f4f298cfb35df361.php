<?php

/* /var/www/html/html/resources/themes/default/profile/reviews.twig */
class __TwigTemplate_466b041f0137904dfdc0aeb4fa659747e0affccb23058dbd06ebee1d8397b22a extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/profile/reviews.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"/web/css/own_profile_detail.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t";
        // line 10
        $this->loadTemplate("profile.head-profile.twig", "/var/www/html/html/resources/themes/default/profile/reviews.twig", 10)->display($context);
        // line 11
        echo "\t\t\t<div class=\"l-main-left\" style=\"width:100%;\">
\t\t\t\t<div class=\"show-avg-ratings\">
\t\t\t\t\t<table style=\"width:100%;background-color:#FFFFFF;\">
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>";
        // line 15
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_age")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t<th>1 ";
        // line 16
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_stars")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t<th>2 ";
        // line 17
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_stars")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t<th>3 ";
        // line 18
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_stars")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t<th>4 ";
        // line 19
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_stars")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t<th>5 ";
        // line 20
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_stars")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t<th>";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rating")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_newer_than_1month")), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 25
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month1count"] ?? null), "rate1", array()) == null)) ? (0) : ($this->getAttribute(($context["month1count"] ?? null), "rate1", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 26
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month1count"] ?? null), "rate2", array()) == null)) ? (0) : ($this->getAttribute(($context["month1count"] ?? null), "rate2", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 27
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month1count"] ?? null), "rate3", array()) == null)) ? (0) : ($this->getAttribute(($context["month1count"] ?? null), "rate3", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 28
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month1count"] ?? null), "rate4", array()) == null)) ? (0) : ($this->getAttribute(($context["month1count"] ?? null), "rate4", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 29
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month1count"] ?? null), "rate5", array()) == null)) ? (0) : ($this->getAttribute(($context["month1count"] ?? null), "rate5", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>(";
        // line 30
        echo twig_escape_filter($this->env, (((($context["month1"] ?? null) == 0)) ? ("5.00") : (twig_number_format_filter($this->env, ($context["month1"] ?? null), 2))), "html", null, true);
        echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t</span>)</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>";
        // line 35
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_newer_than_3month")), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 36
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month2count"] ?? null), "rate1", array()) == null)) ? (0) : ($this->getAttribute(($context["month2count"] ?? null), "rate1", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 37
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month2count"] ?? null), "rate2", array()) == null)) ? (0) : ($this->getAttribute(($context["month2count"] ?? null), "rate2", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 38
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month2count"] ?? null), "rate3", array()) == null)) ? (0) : ($this->getAttribute(($context["month2count"] ?? null), "rate3", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 39
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month2count"] ?? null), "rate4", array()) == null)) ? (0) : ($this->getAttribute(($context["month2count"] ?? null), "rate4", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 40
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month2count"] ?? null), "rate5", array()) == null)) ? (0) : ($this->getAttribute(($context["month2count"] ?? null), "rate5", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>(";
        // line 41
        echo twig_escape_filter($this->env, (((($context["month3"] ?? null) == 0)) ? ("5.00") : (twig_number_format_filter($this->env, ($context["month3"] ?? null), 2))), "html", null, true);
        echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t</span>)</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>";
        // line 46
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_older")), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 47
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month3count"] ?? null), "rate1", array()) == null)) ? (0) : ($this->getAttribute(($context["month3count"] ?? null), "rate1", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 48
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month3count"] ?? null), "rate2", array()) == null)) ? (0) : ($this->getAttribute(($context["month3count"] ?? null), "rate2", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 49
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month3count"] ?? null), "rate3", array()) == null)) ? (0) : ($this->getAttribute(($context["month3count"] ?? null), "rate3", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 50
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month3count"] ?? null), "rate4", array()) == null)) ? (0) : ($this->getAttribute(($context["month3count"] ?? null), "rate4", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>";
        // line 51
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["month3count"] ?? null), "rate5", array()) == null)) ? (0) : ($this->getAttribute(($context["month3count"] ?? null), "rate5", array()))), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t<td>(";
        // line 52
        echo twig_escape_filter($this->env, (((($context["month3older"] ?? null) == 0)) ? ("5.00") : (twig_number_format_filter($this->env, ($context["month3older"] ?? null), 2))), "html", null, true);
        echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t</span>)</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</table>
\t\t\t\t</div>
\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t";
        // line 63
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_antiphishing_warning"));
        echo "</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t\t";
        // line 69
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["comments"] ?? null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 70
            echo "\t\t\t\t\t\t<article class=\"user-review mp-Card-block\">
\t\t\t\t\t\t\t<header class=\"user-review-header\">
\t\t\t\t\t\t\t\t";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "created_at", array()), "diffForHumans", array(0 => null, 1 => true, 2 => true), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t<span class=\"mp-StarRating mp-StarRating--5 \">
\t\t\t\t\t\t\t\t\t";
            // line 74
            echo twig_include($this->env, $context, "components.star_rating", array("rating" => $this->getAttribute($context["comment"], "rating", array())));
            echo "
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t";
            // line 76
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["comment"], "comment", array()), 0, 25), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t<span style=\"float:right;\" class=\"mp-text-meta\">";
            // line 77
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('filter_username')->getCallable(), array($this->getAttribute($this->getAttribute($context["comment"], "commenter", array()), "username", array()))), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t~";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "order", array()), "price", array()), "html", null, true);
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "order", array()), "currency", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t";
            // line 79
            if ($this->getAttribute($this->getAttribute($context["comment"], "commenter", array()), "trusted", array(), "method")) {
                // line 80
                echo "\t\t\t\t\t\t\t\t(<i style=\"color:#00CF72;font-weight:bold;\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_trusted_buyer")), "html", null, true);
                echo "</i>
\t\t\t\t\t\t\t\t<img title=\"";
                // line 81
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_trusted_buyer")), "html", null, true);
                echo "\" width=\"16\" src=\"/web/images/check2.png\">)
\t\t\t\t\t\t\t\t";
            } else {
                // line 83
                echo "\t\t\t\t\t\t\t\t(<i style=\"color:red;font-weight:bold;\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_new_buyer")), "html", null, true);
                echo "</i>)
\t\t\t\t\t\t\t\t";
            }
            // line 84
            echo "</span>
\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t</article>
\t\t\t\t\t";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 88
        echo "\t\t\t\t</div>
\t\t\t\t<br>
\t\t\t\t";
        // line 90
        echo $this->getAttribute(($context["comments"] ?? null), "links", array());
        echo "
\t\t\t</div>
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/profile/reviews.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  276 => 90,  272 => 88,  255 => 84,  249 => 83,  244 => 81,  239 => 80,  237 => 79,  232 => 78,  228 => 77,  224 => 76,  219 => 74,  214 => 72,  210 => 70,  193 => 69,  184 => 63,  170 => 52,  166 => 51,  162 => 50,  158 => 49,  154 => 48,  150 => 47,  146 => 46,  138 => 41,  134 => 40,  130 => 39,  126 => 38,  122 => 37,  118 => 36,  114 => 35,  106 => 30,  102 => 29,  98 => 28,  94 => 27,  90 => 26,  86 => 25,  82 => 24,  76 => 21,  72 => 20,  68 => 19,  64 => 18,  60 => 17,  56 => 16,  52 => 15,  46 => 11,  44 => 10,  40 => 8,  37 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/profile/reviews.twig", "");
    }
}
