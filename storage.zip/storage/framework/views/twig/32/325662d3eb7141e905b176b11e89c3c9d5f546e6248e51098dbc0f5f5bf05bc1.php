<?php

/* /var/www/html/html/resources/themes/default/wallet/xmr.twig */
class __TwigTemplate_8a330685e6a9b72be03b4c687d04a4cf5053f50572a94bd36a532c830a297c73 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/wallet/xmr.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_wallet.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_user_area($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t";
        // line 10
        $this->loadTemplate("account.head_wallet.twig", "/var/www/html/html/resources/themes/default/wallet/xmr.twig", 10)->display($context);
        // line 11
        echo "\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t ";
        // line 12
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 13
            echo "\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t<div>
                        ";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
            ";
        }
        // line 20
        echo "            ";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "success"), "method")) {
            // line 21
            echo "\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t<div>
                        ";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "success"), "method"), "html", null, true);
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
            ";
        }
        // line 28
        echo "\t\t\t";
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) {
            // line 29
            echo "\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li>>";
            // line 33
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_disabled_now")), "html", null, true);
            echo "</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t</div>
\t\t\t";
        }
        // line 38
        echo "\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<label class=\"form-label\" for=\"btcadres\">";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_your")), "html", null, true);
        echo " Monero(XMR) ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_address")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<div class=\"input-group \">
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"input-disabled mp-Input\" value=\"";
        // line 43
        echo twig_escape_filter($this->env, ($context["address"] ?? null), "html", null, true);
        echo "\" readonly=\"readonly\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<div class=\"qrcode\">
\t\t\t\t\t\t\t\t<img src=\"data:image/png;base64,";
        // line 48
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('base64_encode')->getCallable(), array($this->getAttribute($this->getAttribute($this->getAttribute(($context["QrCode"] ?? null), "format", array(0 => "png"), "method"), "size", array(0 => 200), "method"), "generate", array(0 => ($context["address"] ?? null)), "method"))), "html", null, true);
        echo "\"/>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-group verifyaddress\">
\t\t\t\t\t\t\t\t<label class=\"form-label\" for=\"xmr\">";
        // line 51
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_verification")), "html", null, true);
        echo "<span class=\"svg-icon-check1\"></span> </label>
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"mp-Input\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, ($context["address"] ?? null), "html", null, true);
        echo "\" readonly=\"readonly\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 53
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.monero-sign-wallet"));
        echo "\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_pgp_verify")), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"mp-Alert \" style=\"background-color:#F1F1E8;\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<li style=\"color:black;\">
\t\t\t\t\t\t\t\t";
        // line 60
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_info", array("crypto" => "moneros"))), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\" style=\"margin-left: 25%;\">
\t\t\t\t\t\t\t<table id=\"escrow\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td>";
        // line 67
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_available")), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<b>XMR</b>&nbsp;&nbsp;";
        // line 70
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($this->getAttribute(($context["user"] ?? null), "xmr_balance", array()) + $this->getAttribute(($context["user"] ?? null), "escrowMonero", array(), "method")), 6), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td>Escrow</td>
\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<b>XMR</b>&nbsp;-";
        // line 76
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "escrowMonero", array(), "method"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td>";
        // line 79
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_balance")), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<b>XMR</b>&nbsp;&nbsp;";
        // line 82
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["user"] ?? null), "xmr_balance", array()), 6), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<form action=\"../withdraw/xmr\" method=\"post\">
                            ";
        // line 87
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t<fieldset>
\t\t\t\t\t\t\t\t<legend>";
        // line 89
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_withdraw_now")), "html", null, true);
        echo "</legend>
\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\"> 
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"xmraddress\" placeholder=\"Monero ";
        // line 92
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_address")), "html", null, true);
        echo "\" class=\"mp-Input\" value=\"\" ";
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"xmramount\" placeholder=\"Monero ";
        // line 98
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_2")), "html", null, true);
        echo "\" class=\"mp-Input\" value=\"\" ";
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Select\">
\t\t\t\t\t\t\t\t\t\t<select class=\"\" name=\"xmr_fee_type\" ";
        // line 105
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t\t\t<option value=\"1\">";
        // line 106
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.speed_1")), "html", null, true);
        echo " +(";
        echo twig_escape_filter($this->env, ($context["xmr_fee_normal"] ?? null), "html", null, true);
        echo ") XMR</option>
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t<label>";
        // line 108
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.fee_cost", array("crypto" => "XMR"))), "html", null, true);
        echo " + 0.9%</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"max\" value=\"max\" ";
        // line 113
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo "><b>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_withdrawmax")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"withdrawPIN\" placeholder=\"";
        // line 118
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_withdraw_now")), "html", null, true);
        echo " PIN\" class=\"mp-Input\" value=\"\" ";
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"submit\" name=\"submit\" class=\"mp-Button mp-Button--primary mp-Button--lg\" value=\"";
        // line 125
        echo twig_escape_filter($this->env, ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_disabled"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_withdraw_now")))), "html", null, true);
        echo "\" ";
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</fieldset>
\t\t\t\t\t\t</form>

\t\t\t\t\t\t<div class=\"show-avg-ratings\">
\t\t\t\t\t\t\t<h3>";
        // line 132
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_account_history")), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t<table style=\"width:100%\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t\t\t<th>";
        // line 136
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_1")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t\t<th>";
        // line 137
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_2")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t\t<th>";
        // line 138
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t</tr>
                                ";
        // line 140
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["transactions"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["transaction"]) {
            // line 141
            echo "\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 142
            echo twig_escape_filter($this->env, $this->getAttribute($context["transaction"], "id", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 143
            echo twig_escape_filter($this->env, $this->getAttribute($context["transaction"], "type", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 144
            echo twig_escape_filter($this->env, $this->getAttribute($context["transaction"], "amount", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 145
            echo twig_escape_filter($this->env, $this->getAttribute($context["transaction"], "status", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t</tr>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['transaction'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 148
        echo "\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t";
        // line 149
        if ((twig_length_filter($this->env, ($context["transactions"] ?? null)) > 1)) {
            // line 150
            echo "\t\t\t\t\t\t\t<a href=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.emptyxmr"));
            echo "\" style=\"float:right;margin:5px;\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t\t<span>";
            // line 151
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_clear_history")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t";
        }
        // line 154
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/wallet/xmr.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  339 => 154,  333 => 151,  328 => 150,  326 => 149,  323 => 148,  314 => 145,  310 => 144,  306 => 143,  302 => 142,  299 => 141,  295 => 140,  290 => 138,  286 => 137,  282 => 136,  275 => 132,  263 => 125,  251 => 118,  241 => 113,  233 => 108,  226 => 106,  222 => 105,  210 => 98,  199 => 92,  193 => 89,  188 => 87,  180 => 82,  174 => 79,  168 => 76,  159 => 70,  153 => 67,  143 => 60,  131 => 53,  127 => 52,  123 => 51,  117 => 48,  109 => 43,  102 => 41,  97 => 38,  89 => 33,  83 => 29,  80 => 28,  73 => 24,  68 => 21,  65 => 20,  58 => 16,  53 => 13,  51 => 12,  48 => 11,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/wallet/xmr.twig", "");
    }
}
