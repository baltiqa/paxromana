<?php

/* /var/www/html/html/resources/themes/default/auth/mnemonic.twig */
class __TwigTemplate_f7f2ef758d7ece75b676ef48aa97b7a03a4d22f3afcc13e14abcfd42cb75ade5 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.frontpage", "/var/www/html/html/resources/themes/default/auth/mnemonic.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.frontpage";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/css/index.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        // line 7
        echo "\t<header>
\t\t<div class=\"mp-Header-ribbonTop\"></div>
\t\t<div class=\"mp-Header-ribbonBottom\"></div>
\t</header>
";
    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        // line 14
        echo "<div id=\"page-wrapper\">

    <div id=\"content\" class=\"l-page\">
       <a class=\"pagelogo\" href=\"/\" title=\"Pax Romana\"></a>
            ";
        // line 18
        $this->loadTemplate("auth.flags.twig", "/var/www/html/html/resources/themes/default/auth/mnemonic.twig", 18)->display($context);
        // line 19
        echo "            <div class=\"mp-Alert \" style=\"background-color:#D4EFFA;\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t<li style=\"color:black;\">";
        // line 22
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.session_title")), "html", null, true);
        echo "</li>
\t\t\t\t\t</div>
\t\t\t\t</div>
        ";
        // line 25
        if ($this->getAttribute(($context["errors"] ?? null), "any", array(), "method")) {
            // line 26
            echo "        <div class=\"mp-Alert mp-Alert--error\">
            <span aria-hidden=\"true\" class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
            <div>
                <ul>
                        <li>";
            // line 30
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_error")), "html", null, true);
            echo "</li>
                </ul>
            </div>
          </div>
          ";
        }
        // line 35
        echo "        <div class=\"mp-Card mp-Card--rounded login\">
            <div class=\"mp-Card-block\">
                <div id=\"login-tabs\" class=\"mp-Tab-bar mp-Tab-bar--center sdk-custom\">
                    <h2 class=\"mp-text-header2 sub-header\">";
        // line 38
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_title")), "html", null, true);
        echo "</h2>
                </div>
            </div>
            <div class=\"mp-Card-block\">
                <div class=\"mp-Form mp-Form--aligned\">
                    <div class=\"mp-Form-body sdk-custom\">
                        <form id=\"account-login-form\" class=\"new-design-form\" method=\"post\"
                            action=\"";
        // line 45
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("mnemonic_post"));
        echo "\">
                            ";
        // line 46
        echo csrf_field();
        echo "
                            <p>";
        // line 47
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_text1"));
        echo "</p>
                            <div class=\"form-squeeze form-login\">
                                <h4>";
        // line 49
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_key")), "html", null, true);
        echo "</h4>
                                <div class=\"linesOver\">
                                    <p class=\"textFrom\">";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "mnemonic", array()), "html", null, true);
        echo "</p>
                                </div>
                                <p><b>";
        // line 53
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_mnemonicText1")), "html", null, true);
        echo "</b></p>
                                <div class=\"mp-Form-controlGroup\">
                                    <label class=\"mp-Form-controlGroup-label optional-label\" for=\"Mnemonic\">";
        // line 55
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_mnemonic")), "html", null, true);
        echo "</label>
                                    <input type=\"text\" name=\"mnemonic\" placeholder=\"";
        // line 56
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_mnemonic_placeholder")), "html", null, true);
        echo "\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "mnemonic"), "method")) ? (" invalid") : (""));
        echo "\"  value=\"\" tabindex=\"1\">
                                </div>

                                <h4>";
        // line 59
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_withdrawPin")), "html", null, true);
        echo "</h4>
                                <div class=\"linesOver\">
                                    <p class=\"textFrom\">";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdrawpin", array()), "html", null, true);
        echo "</p>
                                </div>

                                <p><b>";
        // line 64
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_withdrawPinText")), "html", null, true);
        echo "</b></p>
                                <div class=\"mp-Form-controlGroup\">
                                    <label class=\"mp-Form-controlGroup-label optional-label\" for=\"Mnemonic\">";
        // line 66
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_withdrawPin")), "html", null, true);
        echo "</label>
                                    <input type=\"text\" name=\"withdrawpin\" placeholder=\"";
        // line 67
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_withdrawPin_placeholder")), "html", null, true);
        echo "\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "withdrawpin"), "method")) ? (" invalid") : (""));
        echo "\"  value=\"\" tabindex=\"1\" maxlength=\"6\">
                                </div>

                                <p>";
        // line 70
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_mnemonicText2"));
        echo "</p>

                                <div class=\"mp-Form-controlGroup centered-control-group last-control-group\">
                                    <button id=\"account-login-button\"
                                        class=\"mp-Button mp-Button--primary width-button\">
                                        <span>";
        // line 75
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_continue")), "html", null, true);
        echo "</span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
";
    }

    // line 88
    public function block_footer($context, array $blocks = array())
    {
        // line 89
        echo "
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/auth/mnemonic.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  200 => 89,  197 => 88,  181 => 75,  173 => 70,  165 => 67,  161 => 66,  156 => 64,  150 => 61,  145 => 59,  137 => 56,  133 => 55,  128 => 53,  123 => 51,  118 => 49,  113 => 47,  109 => 46,  105 => 45,  95 => 38,  90 => 35,  82 => 30,  76 => 26,  74 => 25,  68 => 22,  63 => 19,  61 => 18,  55 => 14,  52 => 13,  44 => 7,  41 => 6,  34 => 4,  31 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/auth/mnemonic.twig", "");
    }
}
