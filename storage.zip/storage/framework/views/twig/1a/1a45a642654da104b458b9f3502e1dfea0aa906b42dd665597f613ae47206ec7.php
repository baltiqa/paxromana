<?php

/* /var/www/html/html/resources/themes/default/notifications.twig */
class __TwigTemplate_013752bdcdcf95a95e7508cda62adf4f36a3f8432f07829c0cabd6a03587e5f8 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/notifications.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/notification.css\" rel=\"stylesheet\">

";
    }

    // line 8
    public function block_content($context, array $blocks = array())
    {
        // line 9
        echo "\t<div id=\"page-wrapper\" class=\"mymp\">
\t\t<div class=\"l-page\">
\t\t\t<h1 class=\"page-header\">";
        // line 11
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.notification_head")), "html", null, true);
        echo "</h1>
\t\t\t<div style=\"touch-action: pan-y; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">
\t\t\t";
        // line 13
        if (($this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "notifications", array()), "count", array()) != null)) {
            // line 14
            echo "\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "notifications", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["notification"]) {
                // line 15
                echo "\t\t\t\t<div class=\"notification-item \">
\t\t\t\t\t<div class=\"swipe-action\">
\t\t\t\t\t\t<span class=\"swipe-label\">";
                // line 17
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.notifications_delete_1")), "html", null, true);
                echo "</span>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"mp-Listing-compact sdk-custom notification-content\">
\t\t\t\t\t\t<div class=\"mp-Listing-compact-body\">
\t\t\t\t\t\t\t<figure class=\"mp-Listing-compact-picture mp-Icon mp-Icon--xxl mp-svg-image-grey\" style=\"background-image: url(";
                // line 21
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["notification"], "data", array()), "image", array(), "array"), "html", null, true);
                echo "); background-position: center center;\"></figure>
\t\t\t\t\t\t\t<div class=\"mp-Listing-compact-content\">
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-compact-title sdk-custom\"></div>
\t\t\t\t\t\t\t\t<div class=\"notification-message ";
                // line 25
                echo ((($this->getAttribute($context["notification"], "read_at", array()) == null)) ? ("unread") : (""));
                echo " \">
\t\t\t\t\t\t\t\t\t";
                // line 26
                if (($this->getAttribute($this->getAttribute($context["notification"], "data", array()), "url", array(), "array") == null)) {
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["notification"], "data", array()), "message", array(), "array"), "html", null, true);
                } else {
                    echo "<a href=\"/notifications/go/";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["notification"], "id", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["notification"], "data", array()), "message", array(), "array"), "html", null, true);
                    echo "</a>";
                }
                // line 27
                echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"actions\"></div>
\t\t\t\t\t\t\t\t<div class=\"meta-data\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--xs mp-svg-megaphone-grey\"></span>
\t\t\t\t\t\t\t\t\t<span class=\"timestamp\">";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["notification"], "created_at", array()), "diffForHumans", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"remove-action\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--md mp-svg-delete\"></span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"snippet-menu-toggle\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--lg mp-svg-arrow-down\"></span>
\t\t\t\t\t\t\t\t\t<ul class=\"mp-Nav-dropdown-menu sdk-custom\">
\t\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/notifications/delete/";
                // line 40
                echo twig_escape_filter($this->env, $this->getAttribute($context["notification"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.notifications_delete_2")), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['notification'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 49
            echo "\t\t\t\t<a href=\"/notifications/markread\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t\t<span>";
            // line 50
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.notifications_mark_read")), "html", null, true);
            echo "</span>
\t\t\t\t</a>
\t\t\t\t<a href=\"/notifications/empty\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t<span>";
            // line 53
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.notifications_empty_notification")), "html", null, true);
            echo "</span>
\t\t\t\t</a>

\t\t\t\t";
        } else {
            // line 57
            echo "\t\t\t\t<div class=\"empty-state-content\">
    <span aria-hidden=\"true\" class=\"mp-Icon mp-svg-notification-grey sdk-custom\"></span>
    <h3 class=\"heading\">";
            // line 59
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.notifications_no_not")), "html", null, true);
            echo "</h3>
    <p class=\"empty-state-text\">";
            // line 60
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.notifications_no_not_text")), "html", null, true);
            echo "</p>
  </div>
\t\t\t\t";
        }
        // line 63
        echo "\t\t\t</div>
\t\t</div>
\t</div>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/notifications.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 63,  150 => 60,  146 => 59,  142 => 57,  135 => 53,  129 => 50,  126 => 49,  109 => 40,  97 => 31,  91 => 27,  81 => 26,  77 => 25,  70 => 21,  63 => 17,  59 => 15,  54 => 14,  52 => 13,  47 => 11,  43 => 9,  40 => 8,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/notifications.twig", "");
    }
}
