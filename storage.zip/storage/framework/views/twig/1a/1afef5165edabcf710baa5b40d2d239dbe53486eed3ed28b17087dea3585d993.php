<?php

/* /var/www/html/html/resources/themes/default/account/referrals.twig */
class __TwigTemplate_917a46b240dbddebc21b9b92e2a669750c6b29bcf07800aa882ece85f6f63133 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/referrals.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_user_area($context, array $blocks = array())
    {
        // line 8
        echo "    <section id=\"content\">
        <div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\" style=\"background: white;color: black;\">
            <h1>";
        // line 10
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_ref_link")), "html", null, true);
        echo ": </h1>
            <div style=\"margin-left: 20px;font-weight: bold;font-style: italic;border: 1px solid;padding: 5px;border-radius: 5px;background-color: silver;\">
                ";
        // line 12
        echo $this->env->getExtension('TwigBridge\Extension\Laravel\Url')->url("/");
        echo "/register/referrer/";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "id", array()), "html", null, true);
        echo "
            </div>
               &nbsp;<b>";
        // line 14
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_earn")), "html", null, true);
        echo "</b>
        </div>
        <div id=\"seller-panel\">
            <div class=\"canvas\">
                <div id=\"ad-listing-table\" class=\"table ad-listing-container seller\">
                    <div id=\"table-head-stickies\">
                        <div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
                            <div class=\"row\">
                                <div class=\"cells\">
                                    <div class=\"cell icon-column middle\">
                                    ";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_commission")), "html", null, true);
        echo "
                                    </div>
                                    <div class=\"cell views-column\">
                                        <span>BTC</span>
                                    </div>
                                    <div class=\"cell views-column\">
                                        <span>LTC</span>
                                    </div>
                                    <div class=\"cell views-column\">
                                        <span>XMR</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id=\"scroll-under-top-border\"></div>
                    </div>
                        <div id=\"ad-listing-table-body\" class=\"table-body\">
                            <div class=\"row ad-listing compact\">
                                <div class=\"cells\">
                                    <div class=\"cell icon-column middle\">
                                    ";
        // line 44
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_paid_out")), "html", null, true);
        echo "
                                    </div>
                                    <div class=\"cell icon-column middle\">
                                        <span>";
        // line 47
        echo twig_escape_filter($this->env, $this->getAttribute(($context["refferals"] ?? null), 0, array(), "array"), "html", null, true);
        echo "</span>
                                    </div>
                                    <div class=\"cell icon-column middle\">
                                        <span>";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute(($context["refferals"] ?? null), 1, array(), "array"), "html", null, true);
        echo "</span>
                                    </div>
                                    <div class=\"cell icon-column middle\">
                                        <span>";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute(($context["refferals"] ?? null), 2, array(), "array"), "html", null, true);
        echo "</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </section>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/referrals.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 53,  106 => 50,  100 => 47,  94 => 44,  71 => 24,  58 => 14,  51 => 12,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/referrals.twig", "");
    }
}
