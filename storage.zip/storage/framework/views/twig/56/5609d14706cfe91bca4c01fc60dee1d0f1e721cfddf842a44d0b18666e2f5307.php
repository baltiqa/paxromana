<?php

/* account.orders.sales.navbar.twig */
class __TwigTemplate_122db75f4ad6cdc6a7e5426010ca7bee27816ae71806c6f76f5d12a5bceb3746 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t\t<div class=\"mp-Tab-bar\">
\t\t\t<a href=\"/account/orders\" class=\"mp-Tab ";
        // line 2
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 11)) ? ("is-selected") : (""));
        echo "\">
\t\t\t\t";
        // line 3
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_head1")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, ($context["processing"] ?? null), "html", null, true);
        echo ")
\t\t\t</a>
\t\t\t<a href=\"/account/orders/state/1\"  class=\"mp-Tab ";
        // line 5
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 12)) ? ("is-selected") : (""));
        echo "\">
\t\t\t\t";
        // line 6
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_head2")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, ($context["accepted"] ?? null), "html", null, true);
        echo ")
\t\t\t</a>
\t\t\t<a href=\"/account/orders/state/2\" class=\"mp-Tab ";
        // line 8
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 13)) ? ("is-selected") : (""));
        echo "\">
\t\t\t\t";
        // line 9
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_head3")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, ($context["shipped"] ?? null), "html", null, true);
        echo ")
\t\t\t</a>
\t\t\t<a href=\"/account/orders/state/3\"  class=\"mp-Tab ";
        // line 11
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 16)) ? ("is-selected") : (""));
        echo "\">
\t\t\t\t";
        // line 12
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_head6")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, ($context["finalized"] ?? null), "html", null, true);
        echo ")
\t\t\t</a>
\t\t\t<a href=\"/account/orders/state/4\"  class=\"mp-Tab ";
        // line 14
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 15)) ? ("is-selected") : (""));
        echo "\">
\t\t\t\t";
        // line 15
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_head4")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, ($context["disputed"] ?? null), "html", null, true);
        echo ")
\t\t\t</a>
\t\t\t<a href=\"/account/orders/state/5\"  class=\"mp-Tab ";
        // line 17
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 14)) ? ("is-selected") : (""));
        echo "\">
\t\t\t\t";
        // line 18
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_head5")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, ($context["cancelled"] ?? null), "html", null, true);
        echo ") 
\t\t\t</a>
\t\t</div>";
    }

    public function getTemplateName()
    {
        return "account.orders.sales.navbar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 18,  77 => 17,  70 => 15,  66 => 14,  59 => 12,  55 => 11,  48 => 9,  44 => 8,  37 => 6,  33 => 5,  26 => 3,  22 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "account.orders.sales.navbar.twig", "");
    }
}
