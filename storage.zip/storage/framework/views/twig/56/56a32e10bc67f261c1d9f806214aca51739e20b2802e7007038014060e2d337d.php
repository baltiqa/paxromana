<?php

/* /var/www/html/html/resources/themes/default/account/purchase_history/show.twig */
class __TwigTemplate_6ef3c1af8b1c2023057e25b1c1b42442c73b8678c1ab981a1ac6ae09ac9a557a extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/purchase_history/show.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "\t<div id=\"content\" class=\"l-page\">
\t\t";
        // line 8
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 9
            echo "\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t<div>
\t\t\t\t\t";
            // line 12
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method");
            echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t";
        }
        // line 16
        echo "\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t<div class=\"content\">
\t\t\t\t\t<h2 class=\"pull-left\" style=\"margin: 0;\">
\t\t\t\t\t\t<strong>";
        // line 20
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order")), "html", null, true);
        echo " #";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "id", array()), "html", null, true);
        echo "</strong>
\t\t\t\t\t</h2>
\t\t\t\t\t<h2 class=\"pull-right\" style=\"margin: 0;\">
\t\t\t\t\t\t<a class=\"text-info\" href=\"/account/purchase-history\">
\t\t\t\t\t\t\t<strong>← ";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_back_to_overview")), "html", null, true);
        echo "</strong>
\t\t\t\t\t\t</a>
\t\t\t\t\t</h2><br>

\t\t\t\t\t<table class=\"table table-orders-meta\">
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t<i class=\"mp-Icon mp-svg-clock-grey\" title=\"";
        // line 32
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_date_bought")), "html", null, true);
        echo "\"></i>
\t\t\t\t\t\t\t\t\t";
        // line 33
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "created_at", array()), "toFormattedDateString", array()), "html", null, true);
        echo "&nbsp;&nbsp;&nbsp;
\t\t\t\t\t\t\t\t\t<i class=\"mp-Button-icon mp-Button-icon--left mp-svg-handshake\" title=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "payment_type", array()), "payment_name", array()), "html", null, true);
        echo "\"></i>
\t\t\t\t\t\t\t\t\t";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "payment_type", array()), "payment_name", array()), "html", null, true);
        echo "&nbsp;&nbsp;&nbsp;
\t\t\t\t\t\t\t\t\t<i class=\"mp-Button-icon mp-Button-icon--left ";
        // line 36
        echo ((($this->getAttribute(($context["order"] ?? null), "is_digtal", array()) == 0)) ? ("mp-svg-postpackage") : ("mp-svg-digital"));
        echo " \" title=\"";
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["order"] ?? null), "is_digtal", array()) == "0")) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2")))), "html", null, true);
        echo "\"></i>
\t\t\t\t\t\t\t\t\t";
        // line 37
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["order"] ?? null), "is_digtal", array()) == "0")) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2")))), "html", null, true);
        echo "&nbsp;&nbsp;
\t\t\t\t\t\t\t\t\t<i class=\"mp-Icon mp-svg-profile style-scope mp-header\" title=\"";
        // line 38
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_seller")), "html", null, true);
        echo "\"></i>
\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
        // line 39
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "seller", array()), "username", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "seller", array()), "username", array()), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        // line 41
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) {
            // line 42
            echo "\t\t\t\t\t\t\t\t\t<td class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 43
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status1")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 46
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "shipped")) {
            // line 47
            echo "\t\t\t\t\t\t\t\t\t<td class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 48
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status2")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 51
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "finalized")) {
            // line 52
            echo "\t\t\t\t\t\t\t\t\t<td style=\"background-color:green;\" class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 53
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status3")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 56
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "disputed")) {
            // line 57
            echo "\t\t\t\t\t\t\t\t\t<td style=\"background-color:red;\" class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 58
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status4")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 61
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "cancelled")) {
            // line 62
            echo "\t\t\t\t\t\t\t\t\t<td style=\"background-color:red;\" class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 63
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status5")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 66
        echo "\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>


\t\t\t\t\t<table style=\"width:100%\" class=\"table table-bordered\">
\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<th style=\"width: 100px;\" class=\"text-center\">";
        // line 74
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t<th>";
        // line 75
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_prod")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t<th style=\"width: 150px;\" class=\"text-right\">";
        // line 76
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_subtotal")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</thead>
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td style=\"width: 100px;\" rowspan=\"2\" class=\"text-center\">";
        // line 81
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "amount", array()), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t";
        // line 84
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "product_title", array()), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t<td style=\"width: 150px;\" rowspan=\"2\" class=\"text-right\">
\t\t\t\t\t\t\t\t\t";
        // line 88
        if (($this->getAttribute(($context["order"] ?? null), "currency", array()) == "BTC")) {
            // line 89
            echo "\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, ($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "shipping_fee", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\tBTC (";
            // line 90
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice(($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "shipping_fee", array())), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 91
($context["order"] ?? null), "currency", array()) == "LTC")) {
            // line 92
            echo "\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, ($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "shipping_fee", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\tLTC (";
            // line 93
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice(($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "shipping_fee", array())), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 94
($context["order"] ?? null), "currency", array()) == "XMR")) {
            // line 95
            echo "\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, ($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "shipping_fee", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\tXMR (";
            // line 96
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice(($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "shipping_fee", array())), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t";
        }
        // line 98
        echo "\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"text-muted\">";
        // line 101
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispatched_on")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 102
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "updated_at", array()), "toFormattedDateString", array()), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>

\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<p class=\"text-info\">
\t\t\t\t\t\t\t";
        // line 109
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "shipped")) {
            // line 110
            echo "\t\t\t\t\t\t\t\t<li>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_finalized")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 111
            echo twig_escape_filter($this->env, ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "days", array()) + ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "weeks", array()) * 7)), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 112
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 113
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 114
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 115
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 116
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 117
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 118
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</li><br>
\t\t\t\t\t\t\t";
        }
        // line 121
        echo "
\t\t\t\t\t\t\t";
        // line 122
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "accepted")) {
            // line 123
            echo "\t\t\t\t\t\t\t\t<li>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_cancelled")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 124
            echo twig_escape_filter($this->env, ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "days", array()) + ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "weeks", array()) * 7)), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 125
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 126
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 127
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 128
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 129
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 130
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 131
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</li><br>
\t\t\t\t\t\t\t";
        }
        // line 134
        echo "
\t\t\t\t\t\t\t";
        // line 135
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "finalized")) {
            // line 136
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_fin"));
            echo "
\t\t\t\t\t\t\t\t";
            // line 137
            if (($this->getAttribute(($context["order"] ?? null), "feedback", array()) != null)) {
                // line 138
                echo "\t\t\t\t\t\t\t\t\t<br>";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_left_feedback")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
                // line 140
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "username", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "username", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t(";
                // line 141
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "feedback", array()), "rate", array()), 2), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t";
                // line 142
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rating")), "html", null, true);
                echo ")</b><br>
\t\t\t\t\t\t\t\t\t";
                // line 143
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute(($context["order"] ?? null), "feedback", array()), "comment", array()) == null)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_no_comment"))) : ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "feedback", array()), "comment", array()))), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t";
            }
            // line 145
            echo "\t\t\t\t\t\t\t";
        }
        // line 146
        echo "
\t\t\t\t\t\t\t";
        // line 147
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "disputed")) {
            // line 148
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_disp"));
            echo "
\t\t\t\t\t\t\t";
        }
        // line 150
        echo "\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "cancelled")) {
            // line 151
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_canc"));
            echo "
\t\t\t\t\t\t\t";
        }
        // line 153
        echo "
\t\t\t\t\t\t\t";
        // line 154
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) {
            // line 155
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_process"));
            echo "
\t\t\t\t\t\t\t";
        }
        // line 157
        echo "
\t\t\t\t\t\t\t";
        // line 158
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "shipped")) {
            // line 159
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_ship"));
            echo "
\t\t\t\t\t\t\t";
        }
        // line 161
        echo "\t\t\t\t\t\t</p>
\t\t\t\t\t\t<table class=\"table\" style=\"float:right;width: 50%; margin: 0;\">
\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<th style=\"border-top: 0; padding-top: 0;\" class=\"text-right\">";
        // line 165
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_1")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t'";
        // line 166
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "shipping", array()), "name", array()), "html", null, true);
        echo "/";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "shipping", array()), "days", array()), "html", null, true);
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_2")), "html", null, true);
        echo "'
\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t<td style=\"width: 150px; border-top: none; padding-top: 0;\" class=\"text-right\">
\t\t\t\t\t\t\t\t\t\t";
        // line 169
        if (($this->getAttribute(($context["order"] ?? null), "currency", array()) == "BTC")) {
            // line 170
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? null), "shipping_fee", array()), 7), "html", null, true);
            echo "BTC
\t\t\t\t\t\t\t\t\t\t\t<br>(";
            // line 171
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute(($context["order"] ?? null), "shipping_fee", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 172
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 173
($context["order"] ?? null), "currency", array()) == "LTC")) {
            // line 174
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? null), "shipping_fee", array()), 7), "html", null, true);
            echo "LTC
\t\t\t\t\t\t\t\t\t\t\t<br>(";
            // line 175
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute(($context["order"] ?? null), "shipping_fee", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 176
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 177
($context["order"] ?? null), "currency", array()) == "XMR")) {
            // line 178
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? null), "shipping_fee", array()), 7), "html", null, true);
            echo "XMR
\t\t\t\t\t\t\t\t\t\t\t<br>(";
            // line 179
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute(($context["order"] ?? null), "shipping_fee", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 180
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 182
        echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<th class=\"text-right lead\">
\t\t\t\t\t\t\t\t\t\t<strong>";
        // line 187
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_total")), "html", null, true);
        echo "</strong>
\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t<td style=\"width: 150px;\" class=\"text-right lead\">
\t\t\t\t\t\t\t\t\t\t<strong>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 191
        if (($this->getAttribute(($context["order"] ?? null), "currency", array()) == "BTC")) {
            // line 192
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? null), "price", array()), 7), "html", null, true);
            echo "BTC  (";
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute(($context["order"] ?? null), "price", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 193
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 194
($context["order"] ?? null), "currency", array()) == "LTC")) {
            // line 195
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? null), "price", array()), 7), "html", null, true);
            echo "LTC  (";
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute(($context["order"] ?? null), "price", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 196
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 197
($context["order"] ?? null), "currency", array()) == "XMR")) {
            // line 198
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? null), "price", array()), 7), "html", null, true);
            echo "XMR  (";
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute(($context["order"] ?? null), "price", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 199
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 201
        echo "
\t\t\t\t\t\t\t\t\t\t</strong>
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t</table>
\t\t\t\t\t</div>


\t\t\t\t\t<div style=\"margin-top: 50px;\" class=\"l-body-content mp-Card-block\">
\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t<b>";
        // line 212
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_seller_note")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t</h2>

\t\t\t\t\t\t<div class=\"form-field form-textarea\">
\t\t\t\t\t\t\t<textarea style=\"height:150px;background-color:#F5F7FA;\" readonly=\"readonly\" class=\"mp-Textarea \" disabled>";
        // line 216
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "notes", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t";
        // line 219
        if ($this->getAttribute(($context["order"] ?? null), "autodispatch", array())) {
            // line 220
            echo "\t\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
            // line 221
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_dispatch_notes")), "html", null, true);
            echo "</b>
\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t<div class=\"form-field form-textarea\">
\t\t\t\t\t\t\t\t<textarea style=\"height:150px;background-color:#F5F7FA;\" readonly=\"readonly\" class=\"mp-Textarea \" disabled>";
            // line 224
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "autodispatch", array()), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 227
        echo "

\t\t\t\t\t\t";
        // line 229
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "shipped")) {
            // line 230
            echo "\t\t\t\t\t\t\t<input id=\"message-box\" type=\"checkbox\">
\t\t\t\t\t\t\t<form action=\"";
            // line 231
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.dispute.create", $this->getAttribute(($context["order"] ?? null), "hash", array())));
            echo "\" method=\"post\">
\t\t\t\t\t\t\t\t";
            // line 232
            echo csrf_field();
            echo "
\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"mp-Button mp-Button--primary mp-Button--xs mp-button-right\">
\t\t\t\t\t\t\t\t\t";
            // line 234
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_create_dispute")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t<label for=\"message-box\" class=\"mp-Button mp-Button--green mp-Button--xs mp-button-right\">";
            // line 237
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_finalize_order")), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t<div class=\"message\">
\t\t\t\t\t\t\t\t<div class=\"popup\">
\t\t\t\t\t\t\t\t   <div class=\"message-box-header\">
\t\t\t\t\t\t\t\t\t";
            // line 241
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_finalize_order")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<label for=\"message-box\" class=\"close\">
\t\t\t\t\t\t\t\t\t\t<span>×</span>
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<p>";
            // line 248
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_finalize_order_u_sure")), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"content-footer\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<form action=\"";
            // line 253
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.finalize.order", $this->getAttribute(($context["order"] ?? null), "hash", array())));
            echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 254
            echo csrf_field();
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"message-box\" class=\"mp-Button mp-Button--primary mp-Button--xs\">";
            // line 255
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_cancel")), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"mp-Button mp-Button--green mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 257
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_finalize_order")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 265
        echo "\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "finalized")) {
            // line 266
            echo "\t\t\t\t\t\t\t<a href=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.purchase-history.feedback", ($context["order"] ?? null)));
            echo "\" class=\"mp-Button mp-Button--primary mp-Button--xs mp-button-right\">
\t\t\t\t\t\t\t\t<span>";
            // line 267
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_leave_feedback")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t";
        }
        // line 270
        echo "

\t\t\t\t\t</div>


\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/purchase_history/show.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  692 => 270,  686 => 267,  681 => 266,  678 => 265,  667 => 257,  662 => 255,  658 => 254,  654 => 253,  646 => 248,  636 => 241,  629 => 237,  623 => 234,  618 => 232,  614 => 231,  611 => 230,  609 => 229,  605 => 227,  599 => 224,  593 => 221,  590 => 220,  588 => 219,  582 => 216,  575 => 212,  562 => 201,  557 => 199,  550 => 198,  548 => 197,  544 => 196,  537 => 195,  535 => 194,  531 => 193,  524 => 192,  522 => 191,  515 => 187,  508 => 182,  503 => 180,  499 => 179,  494 => 178,  492 => 177,  488 => 176,  484 => 175,  479 => 174,  477 => 173,  473 => 172,  469 => 171,  464 => 170,  462 => 169,  453 => 166,  449 => 165,  443 => 161,  437 => 159,  435 => 158,  432 => 157,  426 => 155,  424 => 154,  421 => 153,  415 => 151,  412 => 150,  406 => 148,  404 => 147,  401 => 146,  398 => 145,  393 => 143,  389 => 142,  385 => 141,  379 => 140,  373 => 138,  371 => 137,  366 => 136,  364 => 135,  361 => 134,  355 => 131,  351 => 130,  347 => 129,  343 => 128,  339 => 127,  335 => 126,  331 => 125,  327 => 124,  322 => 123,  320 => 122,  317 => 121,  311 => 118,  307 => 117,  303 => 116,  299 => 115,  295 => 114,  291 => 113,  287 => 112,  283 => 111,  278 => 110,  276 => 109,  266 => 102,  262 => 101,  257 => 98,  251 => 96,  246 => 95,  244 => 94,  239 => 93,  234 => 92,  232 => 91,  227 => 90,  222 => 89,  220 => 88,  213 => 84,  207 => 81,  199 => 76,  195 => 75,  191 => 74,  181 => 66,  175 => 63,  172 => 62,  169 => 61,  163 => 58,  160 => 57,  157 => 56,  151 => 53,  148 => 52,  145 => 51,  139 => 48,  136 => 47,  133 => 46,  127 => 43,  124 => 42,  122 => 41,  115 => 39,  111 => 38,  107 => 37,  101 => 36,  97 => 35,  93 => 34,  89 => 33,  85 => 32,  74 => 24,  65 => 20,  59 => 16,  52 => 12,  47 => 9,  45 => 8,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/purchase_history/show.twig", "");
    }
}
