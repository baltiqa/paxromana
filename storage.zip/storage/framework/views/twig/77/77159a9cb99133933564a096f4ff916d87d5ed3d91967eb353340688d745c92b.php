<?php

/* /var/www/html/html/resources/themes/default/error.twig */
class __TwigTemplate_c8920eee8a368cb03b48c8c54caea5789346d4d211ce0639db72a0527f8bc7aa extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/error.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<style>
@media (min-width: 46.875em) {
body .l-page .page-404-error-text {
    margin: 50px 70px;
}

}


body .l-page .page-404-error-text {
    font-size: 1.5em;
    line-height: 1.2em;
    margin: 30px;
    font-weight: 700;
    text-align: center;
    color: #2d3c4d;
}
#page-wrapper {
    min-height: 100%;
    /* margin-bottom: -226px; */
}

</style>

";
    }

    // line 30
    public function block_content($context, array $blocks = array())
    {
        // line 31
        echo "<div id=\"page-wrapper\">
            <div id=\"content\" class=\"l-page\">
                    <div class=\"page-404-error-text\">
                        <b>";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.error")), "html", null, true);
        echo " ID #";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error_code"), "method"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("validation.error_code_contact")), "html", null, true);
        echo "</b><br><br>
                        <img class=\"centerphishing\" src=\"/web/images/antiphishing/06.png\" width=\"500\" title=\"Alexander The Great\"/>
                    </div>
            </div>
 </div>
\t";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/error.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 34,  63 => 31,  60 => 30,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/error.twig", "");
    }
}
