<?php

/* /var/www/html/html/resources/themes/default/account/orders/index.twig */
class __TwigTemplate_3d48e0dc5244ae6de889a0b2681056e62010633f62edcb83172d8054cfbb6292 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/orders/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 5
    public function block_user_area($context, array $blocks = array())
    {
        // line 6
        echo "\t<div id=\"content\">
\t\t";
        // line 7
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 8
            echo "\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t<div>
\t\t\t\t\t";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t";
        }
        // line 15
        echo "\t\t<div id=\"seller-panel\">
\t\t\t<div class=\"canvas\">
\t\t\t\t";
        // line 17
        if (($this->getAttribute(($context["orders"] ?? null), "count", array()) == null)) {
            // line 18
            echo "\t\t\t\t\t<div style=\"background-color:white;\" class=\"canvas\">
\t\t\t\t\t\t";
            // line 19
            $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/orders/index.twig", 19)->display($context);
            // line 20
            echo "\t\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t<div class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t\t";
            // line 24
            $this->loadTemplate("account.orders.sales.navbar.twig", "/var/www/html/html/resources/themes/default/account/orders/index.twig", 24)->display($context);
            // line 25
            echo "\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div style=\"margin:0;\" class=\"mp-Alert mp-Alert--info-light\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t";
            // line 34
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_no_sales")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        } else {
            // line 39
            echo "\t\t\t\t\t\t<form method=\"get\" style=\"margin-bottom:2px;\" action=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/orders\">
\t\t\t\t\t\t\t<input class=\"mp-Input style-scope listing-search\" placeholder=\"";
            // line 40
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_search")), "html", null, true);
            echo "\" name=\"q\" type=\"text\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "q"), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--secondary mp-Button--xs mp-SearchForm-search style-scope mp-Header\" type=\"submit\">
\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-search style-scope mp-Header\"></span>
\t\t\t\t\t\t\t\t<span class=\"mp-show-md style-scope mp-Header\"></span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t</form>
\t\t\t\t\t\t<div class=\"mp-Topbar\">
\t\t\t\t\t\t\t<section class=\"mp-Topbar-inner-wrapper\">
\t\t\t\t\t\t\t\t<div class=\"mp-Tab-bar \">

\t\t\t\t\t\t\t\t\t<a href=\"/account/vendor_settings\" class=\"mp-Tab ";
            // line 50
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 1)) ? ("is-selected") : (""));
            echo " \">
\t\t\t\t\t\t\t\t\t\t ";
            // line 51
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_1")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"/account/listings\" class=\"mp-Tab ";
            // line 53
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 2)) ? ("is-selected") : (""));
            echo " \">
                      \t\t\t\t  ";
            // line 54
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_2")), "html", null, true);
            echo "(";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "listings", array()), "count", array(), "method"), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"/account/orders\" class=\"mp-Tab ";
            // line 56
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 5)) ? ("is-selected") : (""));
            echo " \">
                        \t\t\t";
            // line 57
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_3")), "html", null, true);
            echo "(";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "orders", array()), "count", array(), "method"), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"/account/disputes#chat\" class=\"mp-Tab ";
            // line 59
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 15)) ? ("is-selected") : (""));
            echo " \">
                        \t\t\t\t ";
            // line 60
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_4")), "html", null, true);
            echo "(";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "disputesSeller", array()), "count", array(), "method"), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"/account/feedbacks\" class=\"mp-Tab ";
            // line 62
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 3)) ? ("is-selected") : (""));
            echo " \">
                      \t\t\t    ";
            // line 63
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_5")), "html", null, true);
            echo "(";
            echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "count_reviews", array(), "method"), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<div style=\"float:right;\" class=\"head-button-orders\">
\t\t\t\t\t\t\t\t\t\t<form action=\"";
            // line 66
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.update.orders"));
            echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t\t";
            // line 67
            echo csrf_field();
            echo "
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" name=\"status\" value=\"accept\" class=\"mp-Button mp-Button--primary mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-shoppingcart\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 70
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_accept")), "html", null, true);
            echo " 
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" name=\"status\" value=\"cancel\" class=\"mp-Button mp-Button--dangerous mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-delete-white\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 74
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_cancel")), "html", null, true);
            echo " 
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div id=\"ad-listing-table\" class=\"table ad-listing-container seller\">
\t\t\t\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 85
            $this->loadTemplate("account.orders.sales.navbar.twig", "/var/www/html/html/resources/themes/default/account/orders/index.twig", 85)->display($context);
            // line 86
            echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
            // line 90
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? null));
            foreach ($context['_seq'] as $context["i"] => $context["item"]) {
                // line 91
                echo "\t\t\t\t\t\t\t\t\t\t<div id=\"ad-listing-table-body\" class=\"table-body\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"row ad-listing compact\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"cells\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"cell icon-column\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"check\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"ids[]\" value=\"";
                // line 97
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "\" type=\"checkbox\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<b>";
                // line 98
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order")), "html", null, true);
                echo " ID:
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 100
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"cell thumbnail-column\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumbnail-wrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 105
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method"), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                // line 106
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method") == null)) ? ("/web/images/noimage.png") : ($this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method"))), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"cell\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"10\" cols=\"30\" style=\"resize: vertical;\" readonly=\"\" value=\"\">";
                // line 111
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_address", array()), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"title\" href=\"";
                // line 115
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.orders.show", $context["item"]));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 116
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "product_title", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 119
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t#";
                // line 120
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "hash", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t     \t<label>";
                // line 123
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t     \t<b>";
                // line 124
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["item"], "is_digital", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1")))), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t         </div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 127
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")), "html", null, true);
                echo "</label><br><a href=\"/profile/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t        <label>";
                // line 130
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_shipping_method")), "html", null, true);
                echo "</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "shipping", array()), "name", array()), "html", null, true);
                echo "/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "shipping", array()), "days", array()), "html", null, true);
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                echo "/
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 131
                if (($this->getAttribute($context["item"], "currency", array()) == "BTC")) {
                    // line 132
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "BTC
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 133
$context["item"], "currency", array()) == "LTC")) {
                    // line 134
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "LTC
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 135
$context["item"], "currency", array()) == "XMR")) {
                    // line 136
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "XMR
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 138
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 140
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_purschased")), "html", null, true);
                echo ":</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "created_at", array()), "toFormattedDateString", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 143
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
                echo ":</label><br><b>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "amount", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 144
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"cell position-column features-column\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 149
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_auto_cancelled")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 151
                if ((twig_date_format_filter($this->env, $this->getAttribute($context["item"], "auto_final", array()), "Y-m-d H:i:s") < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                    // line 152
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t    0 ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                    echo " / 0 ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                    echo " / 0 ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                    echo " - 0 ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 154
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "days", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tdays
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 156
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\thours
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 158
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tmin
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 160
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tsec
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 163
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 164
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item2")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"";
                // line 165
                echo ((($this->getAttribute($context["item"], "currency", array()) == "BTC")) ? ("btc20") : (((($this->getAttribute($context["item"], "currency", array()) == "XMR")) ? ("xmr20") : ("ltc20"))));
                echo "\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 166
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "payment_type", array()), "payment_name", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 169
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item3")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 170
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "price", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 171
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "currency", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 174
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
                echo "</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"";
                // line 175
                echo ((($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) ? ("color:black") : (((($this->getAttribute(($context["order"] ?? null), "status", array()) == "shipped")) ? ("color:blue;") : (((($this->getAttribute(($context["order"] ?? null), "status", array()) == "cancelled")) ? ("color:red;") : (((($this->getAttribute(($context["order"] ?? null), "status", array()) == "disputed")) ? ("color:red;") : ("color:green;"))))))));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 176
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "status", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"cta\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 180
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.orders.show", $context["item"]));
                echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 181
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_details")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 189
            echo "\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t";
            // line 190
            echo $this->getAttribute(($context["orders"] ?? null), "links", array(), "method");
            echo "

\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 194
        echo "\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>


\t";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/orders/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  470 => 194,  463 => 190,  460 => 189,  446 => 181,  442 => 180,  435 => 176,  431 => 175,  427 => 174,  421 => 171,  417 => 170,  413 => 169,  407 => 166,  403 => 165,  399 => 164,  396 => 163,  390 => 160,  385 => 158,  380 => 156,  374 => 154,  362 => 152,  360 => 151,  355 => 149,  347 => 144,  341 => 143,  333 => 140,  329 => 138,  323 => 136,  321 => 135,  316 => 134,  314 => 133,  309 => 132,  307 => 131,  298 => 130,  288 => 127,  282 => 124,  278 => 123,  272 => 120,  268 => 119,  262 => 116,  258 => 115,  251 => 111,  243 => 106,  239 => 105,  231 => 100,  226 => 98,  222 => 97,  214 => 91,  210 => 90,  204 => 86,  202 => 85,  188 => 74,  181 => 70,  175 => 67,  171 => 66,  163 => 63,  159 => 62,  152 => 60,  148 => 59,  141 => 57,  137 => 56,  130 => 54,  126 => 53,  121 => 51,  117 => 50,  102 => 40,  97 => 39,  89 => 34,  78 => 25,  76 => 24,  70 => 20,  68 => 19,  65 => 18,  63 => 17,  59 => 15,  52 => 11,  47 => 8,  45 => 7,  42 => 6,  39 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/orders/index.twig", "");
    }
}
