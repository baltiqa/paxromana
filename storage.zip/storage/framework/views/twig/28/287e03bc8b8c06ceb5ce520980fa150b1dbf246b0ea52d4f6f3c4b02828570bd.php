<?php

/* /var/www/html/html/resources/themes/default/wallet/btc.twig */
class __TwigTemplate_ec177123f1562a4e1229347891bc55b6ccb0f774e8c9d5c5d8b270e15926921e extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/wallet/btc.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_wallet.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_user_area($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t\t";
        // line 10
        $this->loadTemplate("account.head_wallet.twig", "/var/www/html/html/resources/themes/default/wallet/btc.twig", 10)->display($context);
        // line 11
        echo "
\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t";
        // line 13
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 14
            echo "\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 21
        echo "\t\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "success"), "method")) {
            // line 22
            echo "\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "success"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 29
        echo "
\t\t\t\t\t";
        // line 30
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) {
            // line 31
            echo "\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li>>";
            // line 35
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_disabled_now")), "html", null, true);
            echo "</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t</div>
\t\t\t";
        }
        // line 40
        echo "\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<label class=\"form-label\" for=\"btc\">";
        // line 43
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_your")), "html", null, true);
        echo " bitcoin(BTC) ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_address")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<div class=\"input-group \">
\t\t\t\t\t\t\t\t<input type=\"text\"  class=\"input-disabled mp-Input\" value=\"";
        // line 45
        echo twig_escape_filter($this->env, ($context["address"] ?? null), "html", null, true);
        echo "\" readonly=\"readonly\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<div class=\"qrcode\">
\t\t\t\t\t\t\t\t<img src=\"data:image/png;base64,";
        // line 50
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('base64_encode')->getCallable(), array($this->getAttribute($this->getAttribute($this->getAttribute(($context["QrCode"] ?? null), "format", array(0 => "png"), "method"), "size", array(0 => 3000), "method"), "BTC", array(0 => ($context["address"] ?? null), 1 => 0), "method"))), "html", null, true);
        echo "\"/>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-group verifyaddress\">
\t\t\t\t\t\t\t\t<label class=\"form-label\" for=\"btc\">";
        // line 53
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_verification")), "html", null, true);
        echo "<span class=\"svg-icon-check1\"></span>
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"mp-Input\" value=\"";
        // line 55
        echo twig_escape_filter($this->env, ($context["address"] ?? null), "html", null, true);
        echo "\" readonly=\"readonly\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 56
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.bitcoin-sign-wallet"));
        echo "\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_pgp_verify")), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"mp-Alert \" style=\"background-color:#F1F1E8;\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<li style=\"color:black;\">
\t\t\t\t\t\t\t\t";
        // line 63
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_info", array("crypto" => "bitcoins"))), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\" style=\"margin-left: 25%;\">
\t\t\t\t\t\t\t<table id=\"escrow\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td>";
        // line 70
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_available")), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<b>₿</b>&nbsp;&nbsp;";
        // line 73
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($this->getAttribute(($context["user"] ?? null), "btc_balance", array()) + $this->getAttribute(($context["user"] ?? null), "escrowBitcoin", array(), "method")), 6), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td>Escrow</td>
\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<b>₿</b>&nbsp;-";
        // line 79
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "escrowBitcoin", array(), "method"), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<td>";
        // line 82
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_balance")), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<b>₿</b>&nbsp;&nbsp;";
        // line 85
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["user"] ?? null), "btc_balance", array()), 6), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<form action=\"../withdraw/btc\" method=\"post\">
\t\t\t\t\t\t\t";
        // line 91
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t<fieldset>
\t\t\t\t\t\t\t\t<legend>";
        // line 93
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_withdraw_now")), "html", null, true);
        echo "</legend>
\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"btcaddress\" placeholder=\"Bitcoin ";
        // line 96
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_address")), "html", null, true);
        echo "\" class=\"mp-Input\" value=\"\" ";
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"btcamount\" placeholder=\"Bitcoin ";
        // line 102
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_2")), "html", null, true);
        echo "\" class=\"mp-Input\" value=\"\" ";
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Select\">
\t\t\t\t\t\t\t\t\t\t<select class=\"\" name=\"btc_fee_type\" ";
        // line 109
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t\t\t<option value=\"1\">";
        // line 110
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.speed_1")), "html", null, true);
        echo " +(";
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice(($context["btc_fee"] ?? null), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo ")</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"2\">";
        // line 111
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.speed_2")), "html", null, true);
        echo " +(";
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice((($context["btc_fee"] ?? null) * 2), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo ")</option>
\t\t\t\t\t\t\t\t\t\t\t<option value=\"3\">";
        // line 112
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.speed_3")), "html", null, true);
        echo " +(";
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice((($context["btc_fee"] ?? null) * 4), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo ")</option>
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t<label>";
        // line 114
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.fee_cost", array("crypto" => "₿"))), "html", null, true);
        echo " + 0.9%</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"max\" value=\"max\" ";
        // line 119
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo "><b>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_withdrawmax")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"withdrawPIN\" placeholder=\"";
        // line 124
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_withdraw_now")), "html", null, true);
        echo " PIN\" class=\"mp-Input\" value=\"\" ";
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"submit\" name=\"submit\" class=\"mp-Button mp-Button--primary mp-Button--lg\" value=\"";
        // line 131
        echo twig_escape_filter($this->env, ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_disabled"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_withdraw_now")))), "html", null, true);
        echo "\" ";
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "withdraw_disabled", array()) == 1)) ? ("disabled") : (""));
        echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</fieldset>
\t\t\t\t\t\t</form>


\t\t\t\t\t\t<div class=\"show-avg-ratings\">
\t\t\t\t\t\t\t<h3>";
        // line 139
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_account_history")), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t<table style=\"width:100%\">
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t\t\t<th>";
        // line 143
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_1")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t\t<th>";
        // line 144
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_2")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t\t<th>";
        // line 145
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t";
        // line 147
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["transactions"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["transaction"]) {
            // line 148
            echo "\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 149
            echo twig_escape_filter($this->env, $this->getAttribute($context["transaction"], "id", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 150
            echo twig_escape_filter($this->env, $this->getAttribute($context["transaction"], "type", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 151
            echo twig_escape_filter($this->env, $this->getAttribute($context["transaction"], "amount", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 152
            echo twig_escape_filter($this->env, $this->getAttribute($context["transaction"], "status", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['transaction'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 155
        echo "\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t";
        // line 156
        if ((twig_length_filter($this->env, ($context["transactions"] ?? null)) >= 1)) {
            // line 157
            echo "\t\t\t\t\t\t\t<a href=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.emptybtc"));
            echo "\"  style=\"float:right;margin:5px;\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t\t<span>";
            // line 158
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_clear_history")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t";
        }
        // line 161
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/wallet/btc.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  360 => 161,  354 => 158,  349 => 157,  347 => 156,  344 => 155,  335 => 152,  331 => 151,  327 => 150,  323 => 149,  320 => 148,  316 => 147,  311 => 145,  307 => 144,  303 => 143,  296 => 139,  283 => 131,  271 => 124,  261 => 119,  253 => 114,  245 => 112,  238 => 111,  231 => 110,  227 => 109,  215 => 102,  204 => 96,  198 => 93,  193 => 91,  184 => 85,  178 => 82,  172 => 79,  163 => 73,  157 => 70,  147 => 63,  135 => 56,  131 => 55,  126 => 53,  120 => 50,  112 => 45,  105 => 43,  100 => 40,  92 => 35,  86 => 31,  84 => 30,  81 => 29,  74 => 25,  69 => 22,  66 => 21,  59 => 17,  54 => 14,  52 => 13,  48 => 11,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/wallet/btc.twig", "");
    }
}
