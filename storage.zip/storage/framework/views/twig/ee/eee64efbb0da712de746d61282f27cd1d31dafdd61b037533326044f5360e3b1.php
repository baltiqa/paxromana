<?php

/* /var/www/html/html/resources/themes/default/wallet/index.twig */
class __TwigTemplate_139dbb63c485b7d5f3035a3b4f121a42a73b429d85ff6f141d61d26ac1ca5817 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/wallet/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_profile.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_user_area($context, array $blocks = array())
    {
        // line 8
        echo "<div style=\"padding-bottom: 350px;\" class=\"content-wallets\">
\t\t<h2>";
        // line 9
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_h_title")), "html", null, true);
        echo "</h2>
\t\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<h3 style=\"color: #000; font-size: 18px; font-weight: 400; margin-bottom: 8px;\">
\t\t\t\t\t\t\tBitcoin ";
        // line 13
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "
\t\t\t\t\t\t</h3>
\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t<p style=\"float:left;width: 75%;\">
\t\t\t\t\t\t\t\t<u>Bitcoin (BTC)</u>
\t\t\t\t\t\t\t\t";
        // line 18
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_btc_text")), "html", null, true);
        echo "</p>
\t\t\t\t\t\t\t<div style=\"float:right;\">
\t\t\t\t\t\t\t\t<a href=\"/account/wallet/btc\" title=\"";
        // line 20
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_see_your")), "html", null, true);
        echo " BTC ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon--vertical mp-Button-icon--left btc20\"></span>
\t\t\t\t\t\t\t\t\t";
        // line 22
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_go_to")), "html", null, true);
        echo " BTC ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo " ⟶
\t\t\t\t\t\t\t\t</a><br>
\t\t\t\t\t\t\t\t";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_balance")), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "btc_balance", array()), 4), "html", null, true);
        echo "

\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<h3 style=\"color: #000; font-size: 18px; font-weight: 400; margin-bottom: 8px;\">
\t\t\t\t\t\t\tMonero ";
        // line 33
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_recommended")), "html", null, true);
        echo ")
\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t<div style=\"float:left\">
\t\t\t\t\t\t\t\t<a href=\"/account/wallet/xmr\" title=\"";
        // line 37
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_see_your")), "html", null, true);
        echo " XMR ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon--vertical mp-Button-icon--left xmr20\"></span>
\t\t\t\t\t\t\t\t\t";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_go_to")), "html", null, true);
        echo "  XMR ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo " ⟶
\t\t\t\t\t\t\t\t</a><br>
\t\t\t\t\t\t\t\t";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_balance")), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "xmr_balance", array()), 4), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<p style=\"float:right;width: 75%;\">
\t\t\t\t\t\t\t\t<u>Monero (XMR)</u> 
\t\t\t\t\t\t\t\t";
        // line 45
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_xmr_text")), "html", null, true);
        echo "
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<h3 style=\"color: #000; font-size: 18px; font-weight: 400; margin-bottom: 8px;\">
\t\t\t\t\t\t\tLitecoin ";
        // line 53
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "
\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t<p style=\"float:left;width: 75%;\">
\t\t\t\t\t\t\t\t<u>Litcoin (LTC)</u> ";
        // line 57
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_ltc_text")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<div style=\"float:right;\">
\t\t\t\t\t\t\t\t<a href=\"/account/wallet/ltc\" title=\"";
        // line 60
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_see_your")), "html", null, true);
        echo " LTC ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon--vertical mp-Button-icon--left ltc20\"></span>
\t\t\t\t\t\t\t\t\t";
        // line 62
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_go_to")), "html", null, true);
        echo " LTC ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo " ⟶
\t\t\t\t\t\t\t\t</a><br>
\t\t\t\t\t\t\t\t";
        // line 64
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_balance")), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "ltc_balance", array()), 4), "html", null, true);
        echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/wallet/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 64,  156 => 62,  149 => 60,  143 => 57,  136 => 53,  125 => 45,  116 => 41,  109 => 39,  102 => 37,  93 => 33,  79 => 24,  72 => 22,  65 => 20,  60 => 18,  52 => 13,  45 => 9,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/wallet/index.twig", "");
    }
}
