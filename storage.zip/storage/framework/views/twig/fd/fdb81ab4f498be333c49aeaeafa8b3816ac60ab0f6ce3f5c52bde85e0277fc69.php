<?php

/* /var/www/html/html/resources/themes/default/account/favorites.twig */
class __TwigTemplate_b89351bbc2b6536d6494a2f66a24d10d71c0d64467915e9e7fa39e9f87d749b3 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/favorites.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_favourite.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_user_area($context, array $blocks = array())
    {
        // line 8
        echo "\t\t<h2>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_fav_title")), "html", null, true);
        echo "</h2>
\t";
        // line 9
        if (($this->getAttribute(($context["favorites"] ?? null), "count", array()) != null)) {
            // line 10
            echo "\t\t<section class=\"FavoriteSellersContainer-favorite_sellers_container\">
\t\t\t<div class=\"ListHeader-headers-container\">
\t\t\t\t<div class=\"ListHeader-button-container\">
\t\t\t\t\t<form action=\"/account/favorites/remove\" method=\"post\">
\t\t\t\t\t  ";
            // line 14
            echo csrf_field();
            echo "
\t\t\t\t\t<button class=\"mp-Button mp-Button--primary mp-Button--md\">
\t\t\t\t\t\t<span class=\"mp-Button-icon mp-Button-icon--left mp-svg-delete-white\"></span>";
            // line 16
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_delete")), "html", null, true);
            echo "</button>
\t\t\t\t\t\t                ";
            // line 17
            if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "favorites"), "method")) {
                echo " <b>";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_delete_of")), "html", null, true);
                echo "</b> ";
            }
            // line 18
            echo "\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"list-container\">
\t\t\t\t";
            // line 21
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["favorites"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["favorite"]) {
                // line 22
                echo "\t\t\t\t\t<div class=\"mp-Listing-compact FavoriteSellerListItem-favorite-sellers-list-item\">
\t\t\t\t\t\t<div class=\"mp-Listing-compact-body\">
\t\t\t\t\t\t\t<div class=\"mp-Listing-compact-selector\"><input name=\"favorites[]\" value=\"";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($context["favorite"], "id", array()), "html", null, true);
                echo "\" type=\"checkbox\"></div>
\t\t\t\t\t\t\t<div class=\"mp-Listing-compact-content\">
\t\t\t\t\t\t\t\t<h4 class=\"mp-Listing-compact-title mp-Listing-compact-title--link\">
\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 27
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["favorite"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["favorite"], "title", array()))))));
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["favorite"], "title", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t</h4>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['favorite'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "\t\t\t\t</form>
\t\t\t</div>
\t\t</section>
\t";
        } else {
            // line 37
            echo "\t\t<section class=\"FavoritesContainer-favorites_container\">
\t\t\t<div class=\"FavoritesList-list-container\"></div>
\t\t\t<div class=\"mp-Alert mp-Alert--info-light\">
\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t<div>
\t\t\t\t\t<span>
\t\t\t\t\t\t";
            // line 43
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_no_fav")), "html", null, true);
            echo "
\t\t\t\t\t</span>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t";
        }
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/favorites.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 43,  109 => 37,  103 => 33,  89 => 27,  83 => 24,  79 => 22,  75 => 21,  70 => 18,  64 => 17,  60 => 16,  55 => 14,  49 => 10,  47 => 9,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/favorites.twig", "");
    }
}
