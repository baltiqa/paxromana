<?php

/* /var/www/html/html/resources/themes/default/help.twig */
class __TwigTemplate_aff80a35427da2871727506b5b38a06410a73a9963594b868fe096fb7f323dd7 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
\t<head>
\t\t<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
\t\t<title>";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "title"), "method"), "html", null, true);
        echo "</title>

\t\t<link href=\"/web/css/wiki.css\" rel=\"stylesheet\">
\t\t<link href=\"/web/images/favicon.ico\" rel=\"shortcut icon\">

\t</head>
\t<body class=\"mediawiki\">
\t\t<div id=\"globalWrapper\">
\t\t\t<div id=\"column-content\">
\t\t\t\t<div class=\"mw-body\" id=\"content\" role=\"main\">
\t\t\t\t\t<div class=\"mw-indicators mw-body-content\"></div>
\t\t\t\t\t<h1 class=\"firstHeading\" id=\"firstHeading\">Wiki Page</h1>
\t\t\t\t\t<div class=\"mw-body-content\" id=\"bodyContent\">
\t\t\t\t\t\t<div class=\"mw-content-ltr\" id=\"mw-content-text\">
\t\t\t\t\t\t\t<blockquote style=\"background-color: #E6E8F8; border: solid thin grey;\">
\t\t\t\t\t\t\t\t<center>
\t\t\t\t\t\t\t\t\t<b>Welcome to
\t\t\t\t\t\t\t\t\t\t<a class=\"external text\" href=\"Main_Page.html\" rel=\"nofollow noreferrer noopener\" target=\"_blank\">The Roman Wiki</a>
\t\t\t\t\t\t\t\t\t\t- Get your information how to use the marketplace Pax Romana!</b>
\t\t\t\t\t\t\t\t</center>
\t\t\t\t\t\t\t</blockquote>
\t\t\t\t\t\t\t<table class=\"toccolours vatop infobox\" cellpadding=\"1\" cellspacing=\"1\" style=\"float:right; clear:right; width:270px; padding:0px; margin:0px 0px 1em 1em; font-size:85%;\">
\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td style=\"background-color:#e3e3e3; color:#000000;\" align=\"center\" colspan=\"3\">
\t\t\t\t\t\t\t\t\t\t\t<div style=\"font-weight:bold; font-size:120%;\">Ross Ulbricht
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>

\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td align=\"center\" style=\"padding:0;\" colspan=\"3\">
\t\t\t\t\t\t\t\t\t\t\t<img alt=\"Ross Ulbricht\" src=\"/web/images/freedom.jpg\" width=\"266\" height=\"381\">
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td align=\"center\" colspan=\"3\">
\t\t\t\t\t\t\t\t\t\t\t<div style=\"font-size:85%\">
\t\t\t\t\t\t\t\t\t\t\t\t<i>Dread Pirate Roberts</i>
\t\t\t\t\t\t\t\t\t\t\t\tSilk Road(defunct)</div>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td style=\"background-color:#e3e3e3; color:#000000;\" align=\"center\" colspan=\"3\">
\t\t\t\t\t\t\t\t\t\t\t<b>Written By</b>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td style=\"font-weight:bold;\">Profession</td>
\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\">Creator of Silk Road(defunct)
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td style=\"font-weight:bold;\">Period</td>
\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\">Feb/2011 - May/2013
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td style=\"font-weight:bold;\">Criminal Status</td>
\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\">In Prison
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td style=\"font-weight:bold;\">Advice</td>
\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\">Be smart, take the OPSEC measures seriously.</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t<h1>
\t\t\t\t\t\t\t\t<span class=\"mw-headline\">";
        // line 74
        echo twig_escape_filter($this->env, $this->getAttribute(($context["single_news"] ?? null), "title", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</h1>
\t\t\t\t\t\t\t<small>
\t\t\t\t\t\t\t\t<b>Posted
\t\t\t\t\t\t\t\t\t";
        // line 78
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["single_news"] ?? null), "created_at", array()), "diffForHumans", array(0 => null, 1 => true), "method"), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\tago</b>
\t\t\t\t\t\t\t</small><br>
\t\t\t\t\t\t\t";
        // line 81
        echo $this->getAttribute(($context["single_news"] ?? null), "body", array());
        echo "\t\t\t
\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"article-feedback\">
\t\t\t\t\t\t\t\t\t<div id=\"feedback-button\" style=\"display:inline\">
\t\t\t\t\t\t\t\t\t\t<hr class=\"article-hr\">What do you think about it?
\t\t\t\t\t\t\t\t\t\t<div class=\"btn-group feedback-radio-group\">
\t\t\t\t\t\t\t\t\t\t\t<a  href=\"/wiki/";
        // line 87
        echo twig_escape_filter($this->env, $this->getAttribute(($context["single_news"] ?? null), "id", array()), "html", null, true);
        echo "/voteup\"><label style=\"background-color:#F0F0F0;\" class=\"btn btn-secondary radio-btn\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["single_news"] ?? null), "vote_up", array()), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"height: 21px; width: 21px;\" src=\"/web/images/thumbs-up-solid.png\">
\t\t\t\t\t\t\t\t\t\t\t</label></a>
\t\t\t\t\t\t\t\t\t\t\t<a  href=\"/wiki/";
        // line 90
        echo twig_escape_filter($this->env, $this->getAttribute(($context["single_news"] ?? null), "id", array()), "html", null, true);
        echo "/votedown\"><label style=\"background-color:#F0F0F0\" class=\"btn btn-secondary radio-btn\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["single_news"] ?? null), "vote_down", array()), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"height: 21px; width: 21px;\" src=\"/web/images/thumbs-down-solid.png\">
\t\t\t\t\t\t\t\t\t\t\t</label></a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div id=\"column-one\">
\t\t\t\t<div class=\"portlet\" id=\"p-logo\" role=\"banner\">
\t\t\t\t\t<a class=\"mw-wiki-logo\" href=\"/wiki/\" title=\"Visit the main page\"></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"portlet\" id=\"p-search\" role=\"search\">
\t\t\t\t\t<h3>
\t\t\t\t\t\t<label for=\"searchInput\">Search</label>
\t\t\t\t\t</h3>
\t\t\t\t\t<div class=\"pBody\" id=\"searchBody\">
\t\t\t\t\t\t<form action=\"";
        // line 108
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("page"));
        echo "\" id=\"searchform\" name=\"searchform\" method=\"GET\">
\t\t\t\t\t\t\t<input id=\"searchInput\" name=\"search\" placeholder=\"Search The Wiki\" title=\"Search The Wiki\" text=\"search\">
\t\t\t\t\t\t\t<button class=\"searchButton\" id=\"mw-searchButton\" title=\"Search the pages for this text\" type=\"submit\" value=\"Search\">Search</button>
\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<label>contents</label>
\t\t\t\t<div>
\t\t\t\t\t<div class=\"toc\" id=\"toc\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t";
        // line 118
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["newscat"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["cat"]) {
            // line 119
            echo "\t\t\t\t\t\t\t\t<li  class=\"toclevel-1\">
\t\t\t\t\t\t\t\t\t<a ";
            // line 120
            echo (((($this->getAttribute($context["cat"], "id", array()) == $this->getAttribute(($context["single_news"] ?? null), "id", array())) || ($this->getAttribute(($context["single_news"] ?? null), "parent_id", array()) == $this->getAttribute($context["cat"], "id", array())))) ? ("style=\"color:black;font-weight:bold;\"") : (""));
            echo " href=\"";
            echo ((($this->getAttribute($context["cat"], "disabled", array()) == 0)) ? (call_user_func_array($this->env->getFunction('route')->getCallable(), array("page.single", $this->getAttribute($context["cat"], "id", array())))) : ("#"));
            echo "\">
\t\t\t\t\t\t\t\t\t\t<span class=\"tocnumber\">";
            // line 121
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t<span class=\"toctext\">";
            // line 122
            echo twig_escape_filter($this->env, $this->getAttribute($context["cat"], "title", array()), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t";
            // line 124
            if (($this->getAttribute($this->getAttribute($context["cat"], "newsc", array(), "method"), "count", array()) != 0)) {
                // line 125
                echo "\t\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t\t";
                // line 126
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["cat"], "newsc", array(), "method"));
                foreach ($context['_seq'] as $context["childkey"] => $context["newschild"]) {
                    // line 127
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<li  class=\"toclevel-2\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a ";
                    // line 128
                    echo ((($this->getAttribute($context["newschild"], "id", array()) == $this->getAttribute(($context["single_news"] ?? null), "id", array()))) ? ("style=\"color:black;font-weight:bold;\"") : (""));
                    echo " href=\"";
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("page.single", $this->getAttribute($context["newschild"], "id", array())));
                    echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"tocnumber\">";
                    // line 129
                    echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
                    echo ".";
                    echo twig_escape_filter($this->env, ($context["childkey"] + 1), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"toctext\">";
                    // line 130
                    echo twig_escape_filter($this->env, $this->getAttribute($context["newschild"], "title", array()), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['childkey'], $context['newschild'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 134
                echo "\t\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t\t";
            }
            // line 136
            echo "\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['cat'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 138
        echo "\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<h2>Navigation menu</h2>
\t\t\t\t<div class=\"portlet\" id=\"p-cactions\" role=\"navigation\">
\t\t\t\t\t<h3>Views</h3>
\t\t\t\t\t<div class=\"pBody\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li id=\"ca-nstab-main\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 147
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("page"));
        echo "\" title=\"Home\">Home Wiki</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"selected\" id=\"ca-nstab-main\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 150
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("page.single", $this->getAttribute(($context["single_news"] ?? null), "id", array())));
        echo "\" title=\"Home\">Wiki Page</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li id=\"ca-viewsource\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 153
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/account/create/ticket\" title=\"View the content page [c]\">Create Ticket</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li id=\"ca-talk\">
\t\t\t\t\t\t\t\t<a href=\"/d/RomanRoad\" title=\"View the content page [c]\">Dread Roman</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li id=\"ca-history\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 159
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/pgp.txt\" title=\"PGP Key of Pax Romana\">Pax Romana PGP</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li id=\"ca-history\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 162
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/\" title=\"View the content page [c]\">Go Back to Market</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"portlet\" id=\"p-personal\">
\t\t\t\t\t<h3>Personal tools</h3>
\t\t\t\t\t<div class=\"pBody\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li id=\"pt-login\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 172
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/profile/";
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
        echo "\" title=\"Your account\">";
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"portlet\" id=\"p-tb\">
\t\t\t\t\t<h3>Tools</h3>
\t\t\t\t\t<div class=\"pBody\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li><a href=\"";
        // line 181
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/help/mirrors\" title=\"Mirros Explanation\">Mirrors</a></li>
\t\t\t\t\t\t\t<li><a href=\"";
        // line 182
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/account/create/ticket?t=vendor\" title=\"Request FE rights\">Request FE rights</a></li>
\t\t\t\t\t\t\t<li><a href=\"";
        // line 183
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/account/apply_vendor\" title=\"Apply Vendor\">Apply Vendorship</a></li>
\t\t\t\t\t\t\t<li><a href=\"";
        // line 184
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/account/ticket/create\" title=\"Contact Support\">Contact Support</a></li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"visualClear\"></div>
\t\t\t<div id=\"footer\" role=\"contentinfo\">
\t\t\t\t<ul id=\"f-list\">
\t\t\t\t\t<li>Copyright © 2019-2020 Pax Romana Wiki</li>
\t\t\t\t</ul>
\t\t\t\t<span style=\"display:none;\">Some parts of our wiki are from different sources such as a market. We thank you for the texts :D</span>
\t\t\t</div>
\t\t</div>
\t</body>
</html>

";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/help.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  309 => 184,  305 => 183,  301 => 182,  297 => 181,  281 => 172,  268 => 162,  262 => 159,  253 => 153,  247 => 150,  241 => 147,  230 => 138,  223 => 136,  219 => 134,  209 => 130,  203 => 129,  197 => 128,  194 => 127,  190 => 126,  187 => 125,  185 => 124,  180 => 122,  176 => 121,  170 => 120,  167 => 119,  163 => 118,  150 => 108,  127 => 90,  119 => 87,  110 => 81,  104 => 78,  97 => 74,  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/help.twig", "");
    }
}
