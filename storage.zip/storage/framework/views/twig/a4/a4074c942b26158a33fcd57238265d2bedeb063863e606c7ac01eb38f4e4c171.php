<?php

/* account.master */
class __TwigTemplate_6b366a2d67c1a9e4ec382b71c8e8d8971a6cffdefc15231be59614d5dd8e06bd extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "account.master", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_profile.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "<div id=\"page-wrapper\" class=\"mymp require\">
            <div class=\"mp-Topbar\">
                <section class=\"mp-Topbar-inner-wrapper\">
                    <div class=\"mp-Topbar-title\">
                        ";
        // line 11
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_account")), "html", null, true);
        echo "
                    </div>                   
                    <div class=\"mp-Tab-bar has-sticky\">
                        <a href=\"/account/edit_profile\" class=\"mp-Tab ";
        // line 14
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "id"), "method") == 1)) ? ("is-selected") : (""));
        echo "\">
                        ";
        // line 15
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_account")), "html", null, true);
        echo " 
                        </a>
\t\t\t\t    \t";
        // line 17
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "trader_type", array()) == "individual")) {
            // line 18
            echo "                        <a href=\"/account/vendor_settings\" class=\"mp-Tab ";
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "id"), "method") == 2)) ? ("is-selected") : (""));
            echo " \">
                        ";
            // line 19
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_v_panel")), "html", null, true);
            echo " 
                        </a>
                        ";
        }
        // line 22
        echo "                        <a href=\"/account/purchase-history\" class=\"mp-Tab ";
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "id"), "method") == 6)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 23
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_orders")), "html", null, true);
        echo " 
                        </a>
                        ";
        // line 25
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "trader_type", array()) == "buyer")) {
            // line 26
            echo "                        <a href=\"/account/disputes#chat\" class=\"mp-Tab ";
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "id"), "method") == 15)) ? ("is-selected") : (""));
            echo " \">
                        ";
            // line 27
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_disputes")), "html", null, true);
            echo " 
                        </a>
                        ";
        }
        // line 30
        echo "                         <a href=\"/account/favorites\" class=\"mp-Tab ";
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "id"), "method") == 3)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 31
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_favorites")), "html", null, true);
        echo " 
                        </a>
                         <a href=\"/account/referrals\" class=\"mp-Tab ";
        // line 33
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "id"), "method") == 21)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_reff")), "html", null, true);
        echo " 
                        </a>
                        <a href=\"/account/wallet\" class=\"mp-Tab ";
        // line 36
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "id"), "method") == 4)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 37
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_wallet")), "html", null, true);
        echo "
                        </a>
                        <a href=\"/account/tickets\" class=\"mp-Tab ";
        // line 39
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "id"), "method") == 23)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 40
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_tickets")), "html", null, true);
        echo "
                        </a>
                    </div>
                </section>
            </div>
            
            <div class=\"l-page\">
                 ";
        // line 47
        $this->displayBlock('user_area', $context, $blocks);
        // line 48
        echo "            </div>
        </div>

";
    }

    // line 47
    public function block_user_area($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "account.master";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 47,  144 => 48,  142 => 47,  132 => 40,  128 => 39,  123 => 37,  119 => 36,  114 => 34,  110 => 33,  105 => 31,  100 => 30,  94 => 27,  89 => 26,  87 => 25,  82 => 23,  77 => 22,  71 => 19,  66 => 18,  64 => 17,  59 => 15,  55 => 14,  49 => 11,  43 => 7,  40 => 6,  33 => 3,  30 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "account.master", "");
    }
}
