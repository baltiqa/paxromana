<?php

/* /var/www/html/html/resources/themes/default/account/feedbacks.twig */
class __TwigTemplate_c188cc1fc296f034c6027b3a217f20199f9325312df7177c8b2f2c8e793a9db1 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/feedbacks.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_favourite.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_user_area($context, array $blocks = array())
    {
        // line 8
        echo "\t\t";
        $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/feedbacks.twig", 8)->display($context);
        // line 9
        echo "\t";
        if (($this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "comments", array()), "count", array()) != null)) {
            // line 10
            echo "\t\t<section class=\"FavoriteSellersContainer-favorite_sellers_container\">
\t\t\t<div class=\"list-container\">
\t\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t\t";
            // line 13
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "comments", array()));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
                // line 14
                echo "\t\t\t\t\t\t<article class=\"user-review mp-Card-block\">
\t\t\t\t\t\t\t<header class=\"user-review-header\">
\t\t\t\t\t\t\t\t";
                // line 16
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "created_at", array()), "diffForHumans", array(0 => null, 1 => true, 2 => true), "method"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t<span class=\"mp-StarRating mp-StarRating--5 \">
\t\t\t\t\t\t\t\t\t";
                // line 18
                echo twig_include($this->env, $context, "components.star_rating", array("rating" => $this->getAttribute($context["comment"], "rating", array())));
                echo "
\t\t\t\t\t\t\t\t</span>";
                // line 19
                echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["comment"], "comment", array()), 0, 25), "html", null, true);
                echo "  
\t\t\t\t\t\t\t\t<span style=\"float:right;\" class=\"mp-text-meta\"><a href=\"/profile/";
                // line 20
                echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
                echo "</a>  ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "order", array()), "price", array()), "html", null, true);
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "order", array()), "currency", array()), "html", null, true);
                echo " ";
                if ($this->getAttribute($this->getAttribute($context["comment"], "commenter", array()), "trusted", array(), "method")) {
                    echo " (<i style=\"color:#00CF72;font-weight:bold;\">";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_trusted_buyer")), "html", null, true);
                    echo "</i> <img title=\"verified\" width=\"16\" src=\"/web/images/check2.png\">) ";
                } else {
                    echo " (<i style=\"color:red;font-weight:bold;\">";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_new_buyer")), "html", null, true);
                    echo "</i>) ";
                }
                echo "</span>
\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t</article>
\t\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 24
            echo "\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t";
        } else {
            // line 28
            echo "\t\t<section class=\"FavoritesContainer-favorites_container\">
\t\t\t<div class=\"FavoritesList-list-container\"></div>
\t\t\t<div class=\"mp-Alert mp-Alert--info-light\">
\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t<div>
\t\t\t\t\t<span>
\t\t\t\t\t\t";
            // line 34
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_no_feedback")), "html", null, true);
            echo "
\t\t\t\t\t</span>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t";
        }
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/feedbacks.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 34,  126 => 28,  120 => 24,  87 => 20,  83 => 19,  79 => 18,  74 => 16,  70 => 14,  53 => 13,  48 => 10,  45 => 9,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/feedbacks.twig", "");
    }
}
