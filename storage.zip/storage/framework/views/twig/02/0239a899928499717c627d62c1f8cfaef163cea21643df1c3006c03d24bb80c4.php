<?php

/* /var/www/html/html/resources/themes/default/listing/create/create_listing.twig */
class __TwigTemplate_5fe07909237e2f066e2fee2098b44d3f1ce684b06520ca580b27e06998ea632e extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/listing/create/create_listing.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/place_ads.css\" rel=\"stylesheet\">
\t<link href=\"";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/extra.css\" rel=\"stylesheet\">
";
    }

    // line 8
    public function block_content($context, array $blocks = array())
    {
        // line 9
        echo "\t<div id=\"page-wrapper\">
\t\t<div class=\"l-page\" style=\"padding-top: 50px;\">
\t\t\t<section>
\t\t\t\t<h1 class=\"pull-left page-header\">";
        // line 12
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_create_title"));
        echo "</h1>
\t\t\t\t<h2 class=\"pull-right\">
\t\t\t\t\t<a class=\"text-info\" href=\"";
        // line 14
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.listings.index"));
        echo "\">
\t\t\t\t\t\t<strong>← ";
        // line 15
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_back_to_overview")), "html", null, true);
        echo "</strong>
\t\t\t\t\t</a>
\t\t\t\t</h2>
\t\t\t\t<div class=\"clearboth\"></div>
\t\t\t\t";
        // line 19
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 20
            echo "\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t";
            // line 23
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method");
            echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 27
        echo "\t\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 28
            echo "\t\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
                            <span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t";
            // line 31
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method");
            echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 35
        echo "\t\t\t\t<form id=\"syi-form\" method=\"post\"  action=\"";
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.create"));
        echo "\" accept-charset=\"UTF-8\" enctype=\"multipart/form-data\">
\t\t\t\t\t";
        // line 36
        echo csrf_field();
        echo "
\t\t\t\t\t<div class=\"box box-stacked\">
\t\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t\t\t<div  class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_parent")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 42
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_parent_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t<select class=\"form-control ";
        // line 46
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "parent"), "method")) ? (" invalid") : (""));
        echo "\" id=\"parent\" name=\"parent\">
\t\t\t\t\t\t\t\t\t\t\t<option value=\"nope\">";
        // line 47
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_parent_no")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 48
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["own_listing"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["own"]) {
            // line 49
            echo "\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["own"], "id", array()), "html", null, true);
            echo "\" ";
            echo twig_escape_filter($this->env, ($this->getAttribute($context["own"], "id", array()) == call_user_func_array($this->env->getFunction('old')->getCallable(), array("parent"))), "html", null, true);
            echo " ? 'selected=selected' : ''}}>#";
            echo twig_escape_filter($this->env, $this->getAttribute($context["own"], "id", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["own"], "title", array()), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['own'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 59
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_title")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 60
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_title_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"title\" id=\"title\" class=\"mp-Input ";
        // line 63
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "title"), "method")) ? (" invalid") : (""));
        echo "\" value=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("title")), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 68
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_description")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 69
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_description_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<textarea class=\"mp-Textarea ";
        // line 72
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "description"), "method")) ? (" invalid") : (""));
        echo "\" id=\"description\" name=\"description\" maxlength=\"\" data-maxlength=\"\" placeholder=\"\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("description")), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t\t\t\t<input id=\"message-box\" type=\"checkbox\">
\t\t\t\t\t\t\t\t</br>
\t\t\t\t\t\t\t</br>
\t\t\t\t\t\t\t\t<label for=\"message-box\" class=\"mp-Button mp-Button--primary mp-Button--xs \">Romana ";
        // line 76
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<div class=\"message\">
\t\t\t\t\t\t\t\t<div class=\"popup\">
\t\t\t\t\t\t\t\t\t<div class=\"message-box-header\">
\t\t\t\t\t\t\t\t\t\tRomana ";
        // line 80
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t<label for=\"message-box\" class=\"close\">
\t\t\t\t\t\t\t\t\t\t\t<span>×</span>
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<table style=\"width:100%;\">
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>";
        // line 89
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes1")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th></th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>";
        // line 91
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes2")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[h1]Romana[/h1]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><h1>Romana</h1></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[h2]Romana[/h2]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><h2>Romana</h2></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[h3]Romana[/h3]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><h3>Romana</h3></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[b]Romana[/b]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><b>Romana</b></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[i]Romana[/i]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><i>Romana</i></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[u]Romana[/u]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><u>Romana</u></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[li]Romana[/li]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><li style=\"list-style: square;\">Romana</li></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[color=red]Romana[/color]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><span style=\"color:red;\">Romana</spanspan></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[color=white]Romana[/color]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><span style=\"color:white;\">Romana</spanspan></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[color=blue]Romana[/color]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><span style=\"color:blue;\">Romana</spanspan></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t</table><br>
\t\t\t\t\t\t\t\t\t\t\t<b>";
        // line 144
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes_request")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"content-footer\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<label for=\"message-box\" class=\"mp-Button mp-Button--primary mp-Button--xs\">";
        // line 149
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes_close")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 160
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_tags")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 161
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_tags_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<textarea class=\"mp-Textarea ";
        // line 164
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "tags"), "method")) ? (" invalid") : (""));
        echo "\" id=\"tags\" name=\"tags\" maxlength=\"\" placeholder=\"\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("tags")), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 170
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_categories")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 171
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_categories_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t<select class=\"form-control ";
        // line 176
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "category"), "method")) ? (" invalid") : (""));
        echo "\" id=\"category\" name=\"category\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 177
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["categories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 178
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            if ((twig_length_filter($this->env, $this->getAttribute($context["category"], "child", array())) != null)) {
                // line 179
                echo "\t\t\t\t\t\t\t\t\t\t\t<optgroup class=\"optstyle\" label=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 180
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["category"], "child", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 181
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t ";
                    if ((twig_length_filter($this->env, $this->getAttribute($context["child"], "child", array())) != null)) {
                        // line 182
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<optgroup class=\"optstyle\" label=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "name", array()), "html", null, true);
                        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 183
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["child"], "child", array()));
                        foreach ($context['_seq'] as $context["_key"] => $context["child2"]) {
                            // line 184
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "id", array()), "html", null, true);
                            echo "\" ";
                            echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == $this->getAttribute($context["child2"], "id", array()))) ? ("selected=\"selected\"") : (""));
                            echo ">";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "name", array()), "html", null, true);
                            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child2'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 186
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 188
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "id", array()), "html", null, true);
                        echo "\" ";
                        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == $this->getAttribute($context["child"], "id", array()))) ? ("selected=\"selected\"") : (""));
                        echo ">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "name", array()), "html", null, true);
                        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 190
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 191
                echo "\t\t\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 193
                echo "\t\t\t\t\t\t\t\t\t\t\t<option class=\"optstyle\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
                echo "\" ";
                echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == $this->getAttribute($context["category"], "id", array()))) ? ("selected=\"selected\"") : (""));
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 195
            echo "\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 196
        echo "\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 203
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 204
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t<select class=\"";
        // line 208
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "listingclass"), "method")) ? (" invalid") : (""));
        echo "\" name=\"listingclass\">
\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 209
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("listingclass")) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 210
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("listingclass")) == 2)) ? ("selected=\"selected\"") : (""));
        echo " value=\"2\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 218
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 219
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t<select class=\"";
        // line 223
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "status"), "method")) ? (" invalid") : (""));
        echo "\" name=\"status\">
\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 224
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("status")) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_1")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 225
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("status")) == 0)) ? ("selected=\"selected\"") : (""));
        echo " value=\"0\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 232
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 233
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t<select class=\"";
        // line 237
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "escrow"), "method")) ? (" invalid") : (""));
        echo "\" name=\"escrow\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 238
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "has_fe", array()) == 1)) {
            // line 239
            echo "\t\t\t\t\t\t\t\t\t\t\t\t<option ";
            echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("escrow")) == 2)) ? ("selected=\"selected\"") : (""));
            echo " value=\"2\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow_1")), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 241
        echo "\t\t\t\t\t\t\t\t\t\t\t<option ";
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("escrow")) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 242
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("escrow")) == 4)) ? ("selected=\"selected\"") : (""));
        echo " value=\"4\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow_3")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"box box-stacked\">
\t\t\t\t\t\t<div class=\"box-header\">
\t\t\t\t\t\t\t<h2 class=\"heading-2\">";
        // line 251
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_details")), "html", null, true);
        echo "</h2>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t\t\t<div class=\"section-content\">
\t\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<label for=\"price\">";
        // line 257
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_price")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 258
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_price_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-4 form-group\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<select class=\"";
        // line 264
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "currency"), "method")) ? (" invalid") : (""));
        echo "\" name=\"currency\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 265
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "usd")) ? ("selected=\"selected\"") : (""));
        echo " value=\"usd\">USD</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 266
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "eur")) ? ("selected=\"selected\"") : (""));
        echo " value=\"eur\">EUR</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 267
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "gbp")) ? ("selected=\"selected\"") : (""));
        echo " value=\"gbp\">GBP</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 268
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "aud")) ? ("selected=\"selected\"") : (""));
        echo " value=\"aud\">AUD</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 269
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "cad")) ? ("selected=\"selected\"") : (""));
        echo " value=\"cad\">CAD</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 270
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "brl")) ? ("selected=\"selected\"") : (""));
        echo " value=\"brl\">BRL</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 271
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "dkk")) ? ("selected=\"selected\"") : (""));
        echo " value=\"dkk\">DKK</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 272
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "sek")) ? ("selected=\"selected\"") : (""));
        echo " value=\"sek\">SEK</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 273
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "nok")) ? ("selected=\"selected\"") : (""));
        echo " value=\"nok\">NOK</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 274
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "try")) ? ("selected=\"selected\"") : (""));
        echo " value=\"try\">TRY</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 275
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "cny")) ? ("selected=\"selected\"") : (""));
        echo " value=\"cny\">CNY</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 276
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "hkd")) ? ("selected=\"selected\"") : (""));
        echo " value=\"hkd\">HKD</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 277
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "rub")) ? ("selected=\"selected\"") : (""));
        echo " value=\"rub\">RUB</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 278
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "inr")) ? ("selected=\"selected\"") : (""));
        echo " value=\"inr\">INR</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 279
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("currency")) == "jpy")) ? ("selected=\"selected\"") : (""));
        echo " value=\"jpy\">JPY</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-8 form-group \">
\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"price\" id=\"price\" class=\"mp-Input ";
        // line 284
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "price"), "method")) ? (" invalid") : (""));
        echo "\" value=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("price")), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 291
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 292
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity_d"));
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"quantity\" id=\"quantity\" class=\"mp-Input ";
        // line 295
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "quantity"), "method")) ? (" invalid") : (""));
        echo "\" value=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("quantity")), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 300
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_from")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 301
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_from_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t\t<select class=\"";
        // line 305
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "shipped_from"), "method")) ? (" invalid") : (""));
        echo "\" name=\"shipped_from\">
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 306
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["countries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 307
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
            echo ((($this->getAttribute($context["country"], "country_short_name", array()) == call_user_func_array($this->env->getFunction('old')->getCallable(), array("shipped_from")))) ? ("selected=\"selected\"") : (""));
            echo " value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_short_name", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_name", array()), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 309
        echo "\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"row form-group \">
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<label for=\"ships_to\">";
        // line 316
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_to")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 317
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_to_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Select country \">
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t<select id=\"ships_to\" class=\"";
        // line 322
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "ships_to"), "method")) ? (" invalid") : (""));
        echo "\" style=\"height:200px;\" name=\"ships_to[]\" multiple=\"\">
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 323
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["countries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 324
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_short_name", array()), "html", null, true);
            echo "\" ";
            if (twig_in_filter($this->getAttribute($context["country"], "country_short_name", array()), call_user_func_array($this->env->getFunction('old')->getCallable(), array("ships_to")))) {
                echo " selected=\"selected\" ";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_name", array()), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 326
        echo "\t\t\t\t\t\t\t\t\t\t\t</select>



\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"box box-stacked\">
\t\t\t\t\t\t<div class=\"box-header\">
\t\t\t\t\t\t\t<h2 class=\"heading-2\">";
        // line 338
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image")), "html", null, true);
        echo "
\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t\t\t<div class=\"section-content\">
\t\t\t\t\t\t\t\t<p style=\"color: #656d78;margin-bottom: 20px;\">";
        // line 343
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image_d"));
        echo "</p>
\t\t\t\t\t\t\t\t<div class=\"row form-group \">
\t\t\t\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 346
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "image_1"), "method")) {
            echo "<p style=\"color: red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_invalid_img")), "html", null, true);
            echo "</p>";
        }
        // line 347
        echo "\t\t\t\t\t\t\t\t\t\t\t<p><b>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image1")), "html", null, true);
        echo "</b>(";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_optional")), "html", null, true);
        echo ")</p>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"image_1\" id=\"image_1\" type=\"file\">
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 354
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "image_2"), "method")) {
            echo "<p style=\"color: red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_invalid_img")), "html", null, true);
            echo ".</p>";
        }
        // line 355
        echo "\t\t\t\t\t\t\t\t\t\t\t<p><b>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image1")), "html", null, true);
        echo " 2</b>(";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_optional")), "html", null, true);
        echo ")</p>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"image_2\" id=\"image_2\" type=\"file\">
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 362
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "image_3"), "method")) {
            echo "<p style=\"color: red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_invalid_img")), "html", null, true);
            echo ".</p>";
        }
        // line 363
        echo "\t\t\t\t\t\t\t\t\t\t\t<p><b>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image1")), "html", null, true);
        echo " 3</b>(";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_optional")), "html", null, true);
        echo ")</p>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"image_3\" id=\"image_3\" type=\"file\">
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>


\t\t\t\t\t<div class=\"box box-stacked\">
\t\t\t\t\t\t<div class=\"box-header\">
\t\t\t\t\t\t\t<h2 class=\"heading-2\">
\t\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t";
        // line 378
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t<p style=\"color: #656d78;margin-bottom: 20px;\">";
        // line 381
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_d")), "html", null, true);
        echo "</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t\t\t<div class=\"clear-fix\">
\t\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<label for=\"postage_option\">";
        // line 387
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_1")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t\t\t\t\t<label for=\"postage_shipping\">";
        // line 390
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_2")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t\t\t\t\t<label for=\"postage_price\">";
        // line 393
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_3")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t\t";
        // line 398
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 4));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 399
            echo "\t\t\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-6 \">
\t\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" placeholder=\"";
            // line 401
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_1")), "html", null, true);
            echo "\" name=\"postage_option_";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "\" id=\"title_postage\" class=\"mp-Input ";
            echo ((($context["i"] == 1)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_1"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 2)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_2"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 3)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_3"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 4)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_4"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 5)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_5"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 6)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_6"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 7)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_7"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 8)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_8"), "method")) ? (" invalid") : (""))) : (""))))))))))))))));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, ((($context["i"] == 1)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_1"))) : (((($context["i"] == 2)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_2"))) : (((($context["i"] == 3)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_3"))) : (((($context["i"] == 4)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_4"))) : (((($context["i"] == 5)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_5"))) : (((($context["i"] == 6)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_6"))) : (((($context["i"] == 7)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_7"))) : (((($context["i"] == 8)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_8"))) : ("")))))))))))))))), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-2 \">
\t\t\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" placeholder=\"";
            // line 404
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_2")), "html", null, true);
            echo "\" name=\"postage_shipping_";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "\" id=\"days\" class=\"mp-Input ";
            echo ((($context["i"] == 1)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_1"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 2)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_2"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 3)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_3"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 4)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_4"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 5)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_5"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 6)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_6"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 7)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_7"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 8)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_8"), "method")) ? (" invalid") : (""))) : (""))))))))))))))));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, ((($context["i"] == 1)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_1"))) : (((($context["i"] == 2)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_2"))) : (((($context["i"] == 3)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_3"))) : (((($context["i"] == 4)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_4"))) : (((($context["i"] == 5)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_5"))) : (((($context["i"] == 6)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_6"))) : (((($context["i"] == 7)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_7"))) : (((($context["i"] == 8)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_8"))) : ("")))))))))))))))), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" placeholder=\"";
            // line 407
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_3")), "html", null, true);
            echo "\" name=\"postage_price_";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "\" id=\"price\" class=\"mp-Input ";
            echo ((($context["i"] == 1)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_1"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 2)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_2"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 3)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_3"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 4)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_4"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 5)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_5"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 6)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_6"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 7)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_7"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 8)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_8"), "method")) ? (" invalid") : (""))) : (""))))))))))))))));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, ((($context["i"] == 1)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_1"))) : (((($context["i"] == 2)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_2"))) : (((($context["i"] == 3)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_3"))) : (((($context["i"] == 4)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_4"))) : (((($context["i"] == 5)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_5"))) : (((($context["i"] == 6)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_6"))) : (((($context["i"] == 7)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_7"))) : (((($context["i"] == 8)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_8"))) : ("")))))))))))))))), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 412
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"box box-stacked\">
\t\t\t\t\t\t<div class=\"box-header\">
\t\t\t\t\t\t\t<h2 class=\"heading-2\">
\t\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t";
        // line 419
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_dispatch_notes")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t<p style=\"color: #656d78;margin-bottom: 20px;\">";
        // line 422
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_dispatch_notes_d")), "html", null, true);
        echo " </p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t\t<textarea class=\"mp-Textarea\" id=\"autodispatch\" name=\"autodispatch\" style=\"height:150px;\" placeholder=\"\">";
        // line 425
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "autodispatch", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"box box-stacked\" id=\"place-advertisement\">
\t\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t\t\t<button type=\"submit\" id=\"syi-place-ad-button\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t\t<span>";
        // line 431
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_create_listing")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</section>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/listing/create/create_listing.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  944 => 431,  935 => 425,  929 => 422,  923 => 419,  914 => 412,  897 => 407,  885 => 404,  873 => 401,  869 => 399,  865 => 398,  857 => 393,  851 => 390,  845 => 387,  836 => 381,  830 => 378,  809 => 363,  803 => 362,  790 => 355,  784 => 354,  771 => 347,  765 => 346,  759 => 343,  751 => 338,  737 => 326,  722 => 324,  718 => 323,  714 => 322,  706 => 317,  702 => 316,  693 => 309,  680 => 307,  676 => 306,  672 => 305,  665 => 301,  661 => 300,  651 => 295,  645 => 292,  641 => 291,  629 => 284,  621 => 279,  617 => 278,  613 => 277,  609 => 276,  605 => 275,  601 => 274,  597 => 273,  593 => 272,  589 => 271,  585 => 270,  581 => 269,  577 => 268,  573 => 267,  569 => 266,  565 => 265,  561 => 264,  552 => 258,  548 => 257,  539 => 251,  525 => 242,  518 => 241,  510 => 239,  508 => 238,  504 => 237,  497 => 233,  493 => 232,  481 => 225,  475 => 224,  471 => 223,  464 => 219,  460 => 218,  447 => 210,  441 => 209,  437 => 208,  430 => 204,  426 => 203,  417 => 196,  411 => 195,  401 => 193,  397 => 191,  391 => 190,  381 => 188,  377 => 186,  364 => 184,  360 => 183,  355 => 182,  352 => 181,  348 => 180,  343 => 179,  340 => 178,  336 => 177,  332 => 176,  324 => 171,  320 => 170,  309 => 164,  303 => 161,  299 => 160,  285 => 149,  277 => 144,  221 => 91,  216 => 89,  204 => 80,  197 => 76,  188 => 72,  182 => 69,  178 => 68,  168 => 63,  162 => 60,  158 => 59,  149 => 52,  141 => 50,  132 => 49,  128 => 48,  124 => 47,  120 => 46,  113 => 42,  109 => 41,  101 => 36,  96 => 35,  89 => 31,  84 => 28,  81 => 27,  74 => 23,  69 => 20,  67 => 19,  60 => 15,  56 => 14,  51 => 12,  46 => 9,  43 => 8,  37 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/listing/create/create_listing.twig", "");
    }
}
