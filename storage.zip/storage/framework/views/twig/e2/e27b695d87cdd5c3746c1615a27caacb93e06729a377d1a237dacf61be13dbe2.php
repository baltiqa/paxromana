<?php

/* /var/www/html/html/resources/themes/default/auth/confirmationphishing.twig */
class __TwigTemplate_f0661604175ec2f952d16839e466458f272960c63d1468f4bc851fab853e1ca1 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.frontpage", "/var/www/html/html/resources/themes/default/auth/confirmationphishing.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.frontpage";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/css/index.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        // line 7
        echo "\t<header>
\t\t<div class=\"mp-Header-ribbonTop\"></div>
\t\t<div class=\"mp-Header-ribbonBottom\"></div>
\t</header>
";
    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        // line 13
        echo "\t<div id=\"page-wrapper\">
\t\t<div class=\"l-page pagelog\">
\t\t\t<section class=\"l-main-right\">
\t\t\t\t<a class=\"pagelogo\" href=\"/\" title=\"Pax Romana\"></a>
\t\t\t\t";
        // line 17
        $this->loadTemplate("auth.flags.twig", "/var/www/html/html/resources/themes/default/auth/confirmationphishing.twig", 17)->display($context);
        // line 18
        echo "\t\t\t\t<div class=\"mp-Card mp-Card--rounded login\">
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<div class=\"mp-Form mp-Form--aligned\">
\t\t\t\t\t\t\t<h2 class=\"centerphishing\">
\t\t\t\t\t\t\t";
        // line 22
        if ((($context["random"] ?? null) == 1)) {
            echo "Antoninus Pius";
        }
        if ((($context["random"] ?? null) == 2)) {
            echo "Hadrianus";
        }
        if ((($context["random"] ?? null) == 3)) {
            echo "Julius Caesar";
        }
        if ((($context["random"] ?? null) == 4)) {
            echo "Marcus Aurelius";
        }
        if ((($context["random"] ?? null) == 5)) {
            echo "Trajanus";
        }
        if ((($context["random"] ?? null) == 6)) {
            echo "Alexander The Great";
        }
        // line 23
        echo "\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t\t<div class=\"form-squeeze\">
\t\t\t\t\t\t\t\t\t<img class=\"centerphishing\" src=\"/web/images/antiphishing/0";
        // line 25
        echo twig_escape_filter($this->env, ($context["random"] ?? null), "html", null, true);
        echo ".png\" width=\"600\" title=\"Anti Phishing\"/>
\t\t\t\t\t\t\t\t\t<h3 style=\"width: 100%;\" class=\"centerphishing\">
\t\t\t\t\t\t\t\t\t";
        // line 27
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.anti_phishing_part_1")), "html", null, true);
        echo " ";
        if ((($context["random"] ?? null) == 1)) {
            echo "Antoninus Pius";
        }
        if ((($context["random"] ?? null) == 2)) {
            echo "Hadrianus";
        }
        if ((($context["random"] ?? null) == 3)) {
            echo "Julius Caesar";
        }
        if ((($context["random"] ?? null) == 4)) {
            echo "Marcus Aurelius";
        }
        if ((($context["random"] ?? null) == 5)) {
            echo "Trajanus";
        }
        echo " ";
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.anti_phishing_part_2"));
        echo "
\t\t\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/\" class=\"mp-Button mp-Button--primary width-button\">
\t\t\t\t\t\t\t\t\t\t\t<span>";
        // line 31
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.anti_phishing_submit")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<div class=\"godlike godphishing\">";
        // line 33
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.anti_phishing_why")), "html", null, true);
        echo "?
\t\t\t\t\t\t\t\t\t\t\t<span class=\"godliketext right-phishing\">";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.anti_phishing_why_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</section>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/auth/confirmationphishing.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 34,  126 => 33,  121 => 31,  96 => 27,  91 => 25,  87 => 23,  68 => 22,  62 => 18,  60 => 17,  54 => 13,  51 => 12,  43 => 7,  40 => 6,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/auth/confirmationphishing.twig", "");
    }
}
