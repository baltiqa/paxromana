<?php

/* /var/www/html/html/resources/themes/default/inbox/index.twig */
class __TwigTemplate_606e51ff99b9eb019dd566aa20258bf3a19b1f35e2fbe5c9a6a995a2778cd5b5 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/inbox/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/message.css\" rel=\"stylesheet\">
\t<style>
\t\t#page-wrapper {
\t\t\tmargin-bottom: 0;
\t\t}

\t</style>

";
    }

    // line 14
    public function block_content($context, array $blocks = array())
    {
        // line 15
        echo "\t<div class=\"wide-layout\" id=\"page-wrapper\">
\t
\t\t<div class=\"l-page indexpage\" id=\"content\" style=\"height: 800px;margin-bottom:150px;\">
\t\t\t<div class=\"mp-Alert mp-Alert--error\"><span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t<li>
\t\t\t\t\t\t";
        // line 20
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_antiphishing_warning"));
        echo "
\t\t\t\t\t</li>
\t\t</div>
\t\t ";
        // line 23
        if ((twig_length_filter($this->env, ($context["inboxes"] ?? null)) == 0)) {
            // line 24
            echo "<div class=\"ContentPlaceholderMolecule-root pageHeaderOffsetBorder\">
<div class=\"ContentPlaceholderMolecule-rootInner\">
<div class=\"ContentPlaceholderMolecule-iconUnit\">
<span class=\"mp-Icon mp-Icon--xxl mp-svg-messages--secondary\"></span>
</div><p class=\"ContentPlaceholderMolecule-text\"> ";
            // line 28
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_nothing")), "html", null, true);
            echo "</p>
</div>
</div>
\t\t ";
        } else {
            // line 32
            echo "\t\t\t<div class=\"inbox-messages chatheader\">
\t\t\t\t<div class=\"messages-left\">
\t\t\t\t\t<div class=\"mp-Card message-left-header\">
\t\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t\t<h1>";
            // line 36
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_messages")), "html", null, true);
            echo "</h1>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"message-left-header-shadow\">
\t\t\t\t\t\t<div class=\"ConversationsToolsMolecule-root\"></div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"message-left-part\">
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t<ol class=\"ConversationsOrganism-listRoot\">
               \t\t\t\t\t ";
            // line 45
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["inboxes"] ?? null));
            foreach ($context['_seq'] as $context["k"] => $context["inbox"]) {
                // line 46
                echo "\t\t\t\t\t\t\t\t<li class=\"ConversationsOrganism-listItem\">
\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-root ConversationMolecule-selling\">
\t\t\t\t\t\t\t\t\t\t<label class=\"ConversationMolecule-selectLabel\">
\t\t\t\t\t\t\t\t\t\t<input id=\"checkbox1\" type=\"checkbox\"></label>
\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationMolecule-trashcan\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--md mp-svg-trash\"></span>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 53
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("inbox.show", $this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "conversation_id", array())));
                echo "#chat\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-leftUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-thumbnailUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ThumbnailAtom-root ThumbnailAtomSizes-lg ThumbnailAtomBorderRadii-xs\" style=\"background-image: url(&quot;";
                // line 56
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "getAvatar", array(), "method"), "html", null, true);
                echo "&quot;);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-thumbnailProfilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-sm ProfilePictureAtom-rootBordered ";
                // line 58
                echo ((((($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_mod", array()) == 1) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_headmod", array()) == 1)) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_admin", array()) == 1))) ? ("staff") : (""));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 59
                echo twig_escape_filter($this->env, twig_first($this->env, $this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "username", array())), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-rightUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t<h2 class=\"ConversationMolecule-title\">";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "username", array()), "html", null, true);
                echo "</h2>
\t\t\t\t\t\t\t\t\t\t\t\t ";
                // line 66
                if (( !$this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "is_seen", array()) && ($this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "user_id", array()) != $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array())))) {
                    // line 67
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationMolecule-titleBadgeUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"BadgeAtom-root\">1</span>
\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t ";
                }
                // line 71
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-meta\">from ";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "username", array()), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-latestMessageWrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 74
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('str_limit')->getCallable(), array("limit", call_user_func_array($this->env->getFilter('filter_message')->getCallable(), array($this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "message", array()))), 18)), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-left card-";
                // line 75
                echo ((((($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_mod", array()) == 1) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_headmod", array()) == 1)) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_admin", array()) == 1))) ? ("staff") : ("user"));
                echo "\">";
                echo ((((($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_mod", array()) == 1) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_headmod", array()) == 1)) || ($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "is_admin", array()) == 1))) ? ("Romana Staff") : (((($this->getAttribute($this->getAttribute($context["inbox"], "withUser", array()), "trader_type", array()) == "individual")) ? ("Vendor") : ("Buyer"))));
                echo "</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t<footer>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-receivedDateUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 80
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["inbox"], "thread", array()), "created_at", array()), "diffForHumans", array(), "method"), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</footer>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['inbox'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 88
            echo "
\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<a name=\"chat\"></a>
\t\t\t\t<div class=\"chatindividual part2\">
\t\t\t\t\t<div class=\"chatbox\">
\t\t\t\t\t\t<header>
\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-root\">
\t\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-titleUnit\">
\t\t\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-backLinkUnit\">
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<h2 class=\"ConversationTopicOrganism-title\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/Augustus\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-profilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-md\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>S</span>
\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-name\">Augustus
\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-blanc card-staff\">Romana Staff</p>
\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</header>
\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t<div class=\"MessagesOrganism-root\">
\t\t\t\t\t\t\t\t<div class=\"LegalDisclaimerMolecule-root\">";
            // line 121
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_warning"));
            echo "
\t\t\t\t\t\t\t\t\t<a target=\"_blank\" href=\"/wiki/43\" rel=\"noopener noreferrer\">";
            // line 122
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_read_more")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--xs mp-svg-arrow-right--action\"></span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"MessagesOrganism-group\">
\t\t\t\t\t\t\t\t\t<ol class=\"MessagesOrganism-listRoot\">
\t\t\t\t\t\t\t\t\t\t<li class=\"MessagesOrganism-listItem MessagesOrganism-listItem_from_otherparticipant\">
\t\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-root MessageMolecule-root_from_otherparticipant MessageMolecule-tail\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 131
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.inbox_welcome"));
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</article>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t";
        }
        // line 143
        echo "
\t\t</div>
\t</div>

";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/inbox/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  246 => 143,  231 => 131,  219 => 122,  215 => 121,  180 => 88,  166 => 80,  156 => 75,  152 => 74,  147 => 72,  144 => 71,  138 => 67,  136 => 66,  132 => 65,  123 => 59,  119 => 58,  114 => 56,  108 => 53,  99 => 46,  95 => 45,  83 => 36,  77 => 32,  70 => 28,  64 => 24,  62 => 23,  56 => 20,  49 => 15,  46 => 14,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/inbox/index.twig", "");
    }
}
