<?php

/* /var/www/html/html/resources/themes/default/inbox/create.twig */
class __TwigTemplate_5a4ffc60ce66212790ed737bc9354ae59d4ccc11c8f7c7173a49c9f488780ebe extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/inbox/create.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/sent_message.css\" rel=\"stylesheet\">

\t<style>
\t\t.mp-FooterAlternative {
\t\t\tposition: absolute;
\t\t}
\t</style>


";
    }

    // line 16
    public function block_content($context, array $blocks = array())
    {
        // line 17
        echo "\t<div id=\"page-wrapper\">
\t\t<div class=\"l-page\">
\t\t\t<h1 class=\"page-header\">
\t\t\t\t";
        // line 20
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_title")), "html", null, true);
        echo "
\t\t\t\t";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "
\t\t\t</h1>
\t\t\t<section id=\"content\">
\t\t\t\t<div class=\"mp-Card\">
\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t";
        // line 26
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 27
            echo "\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t";
            // line 30
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method");
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 34
        echo "\t\t\t\t\t\t<form id=\"asq-form\" action=\"";
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "/message\" method=\"post\">
\t\t\t\t\t\t    ";
        // line 35
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t<div class=\"tip mp-Card mp-Card-block mp-Card-block--highlight\">
\t\t\t\t\t\t\t\t<h6>
\t\t\t\t\t\t\t\t\t";
        // line 38
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_title1")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</h6>
\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li>";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_tips1")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t";
        // line 44
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_tips2"));
        echo "
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t";
        // line 47
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_tips3")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t";
        // line 50
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_tips4")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<h3>";
        // line 54
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_your_message")), "html", null, true);
        echo "</h3>

\t\t\t\t\t\t\t<div class=\"form-field form-textarea\">
\t\t\t\t\t\t\t\t<textarea class=\"mp-Textarea ";
        // line 57
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "message"), "method")) ? (" invalid") : (""));
        echo "\" id=\"message\" name=\"message\" maxlength=\"10000\" data-maxlength=\"10000\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("message")), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t <div class=\"mp-Form-controlGroup\">
                                            <img src=\"/captcha.html\" />
                                            <label class=\"mp-Form-controlGroup-label optional-label\"
                                                for=\"captcha\">Captcha</label>
                                            <input style=\"width:50%;\" id=\"captcha\" type=\"text\" placeholder=\"captcha\" name=\"captcha\"
                                                class=\"mp-Input ";
        // line 65
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
        echo "\"
                                                tabindex=\"2\">
                                            ";
        // line 67
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) {
            // line 68
            echo "                                            <div
                                                class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
                                                ";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "captcha"), "method"), "html", null, true);
            echo "
                                            </div>
                                            ";
        }
        // line 73
        echo "                                </div>

\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"1\" name=\"encrypt\"/>";
        // line 75
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pgp")), "html", null, true);
        echo "

\t\t\t\t\t\t\t<div class=\"buttonbar\">
\t\t\t\t\t\t\t\t<input id=\"send-asq\" type=\"submit\" class=\"mp-Button mp-Button--primary\" value=\"";
        // line 78
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_sent")), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<h3>";
        // line 81
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pgp_key_of")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t";
        // line 82
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t<pre style=\"word-wrap: break-word; white-space: pre-wrap; line-height: normal;\">";
        // line 83
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "pgp_key", array()), "html", null, true);
        echo "</pre>


\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<p class=\"asq-disclaimer\">
\t\t\t\t";
        // line 91
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_disclaimer")), "html", null, true);
        echo "
\t\t\t\t</p>

\t\t\t</section>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/inbox/create.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  194 => 91,  183 => 83,  179 => 82,  175 => 81,  169 => 78,  163 => 75,  159 => 73,  153 => 70,  149 => 68,  147 => 67,  142 => 65,  129 => 57,  123 => 54,  116 => 50,  110 => 47,  104 => 44,  98 => 41,  92 => 38,  86 => 35,  81 => 34,  74 => 30,  69 => 27,  67 => 26,  59 => 21,  55 => 20,  50 => 17,  47 => 16,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/inbox/create.twig", "");
    }
}
