<?php

/* /var/www/html/html/resources/themes/default/account/edit_pgp.twig */
class __TwigTemplate_0d1761c3f7701a2670bcd11102d340d18467da8de3f42c4b9658b34087bc051e extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/edit_pgp.twig", 1);
        $this->blocks = array(
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_user_area($context, array $blocks = array())
    {
        // line 4
        echo "\t<div id=\"content\">
\t\t<div style=\"margin-bottom: 50%;\" class=\"mp-Card mp-Card--rounded\">
       \t\t\t";
        // line 6
        $this->loadTemplate("account.head_normal_bar.twig", "/var/www/html/html/resources/themes/default/account/edit_pgp.twig", 6)->display($context);
        // line 7
        echo "
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t<form method=\"POST\" action=\"";
        // line 9
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.update.pgp"));
        echo "\" accept-charset=\"UTF-8\">
\t\t\t\t\t";
        // line 10
        echo csrf_field();
        echo "
\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t\t";
        // line 12
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 13
            echo "\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 20
        echo "
\t\t\t\t\t\t";
        // line 21
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 22
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 29
        echo "
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 32
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pub_key")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pub_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<textarea style=\"height:800px;\" class=\"mp-Textarea ";
        // line 35
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "pgp_key"), "method")) ? (" invalid") : (""));
        echo "\" id=\"pgp_key\" name=\"pgp_key\">";
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "pgp_key", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<button id=\"confirm-profile\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t<span>";
        // line 40
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.reset_password_continue")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<a id=\"cancel-profile\" href=\"/account/edit_profile\" class=\"secondary medium mp-Button mp-Button--secondary\">
\t\t\t\t\t\t\t\t<span>";
        // line 43
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_cancel")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/edit_pgp.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 43,  105 => 40,  95 => 35,  91 => 34,  86 => 32,  81 => 29,  74 => 25,  69 => 22,  67 => 21,  64 => 20,  57 => 16,  52 => 13,  50 => 12,  45 => 10,  41 => 9,  37 => 7,  35 => 6,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/edit_pgp.twig", "");
    }
}
