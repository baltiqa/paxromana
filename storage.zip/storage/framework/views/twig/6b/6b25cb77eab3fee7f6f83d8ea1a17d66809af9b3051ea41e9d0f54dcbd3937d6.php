<?php

/* /var/www/html/html/resources/themes/default/auth/login.twig */
class __TwigTemplate_657bcccf8df707f50ad55d3668b38672376a5015b6ac4ca97a6a6b49f1c714d7 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.frontpage", "/var/www/html/html/resources/themes/default/auth/login.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.frontpage";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/css/index.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        // line 7
        echo "\t<header>
\t\t<div class=\"mp-Header-ribbonTop\"></div>
\t\t<div class=\"mp-Header-ribbonBottom\"></div>
\t</header>
";
    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        // line 13
        echo "\t<div id=\"page-wrapper\">
\t\t<div class=\"l-page pagelog\">
\t\t\t<section class=\"l-main-right\">
\t\t\t\t<a class=\"pagelogo\" href=\"/\" title=\"Pax Romana\"></a>
\t\t\t\t";
        // line 17
        $this->loadTemplate("auth.flags.twig", "/var/www/html/html/resources/themes/default/auth/login.twig", 17)->display($context);
        // line 18
        echo "\t\t\t\t<div class=\"mp-Alert \" style=\"background-color:#D4EFFA;\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t<li style=\"color:black;\">";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.session_title")), "html", null, true);
        echo "</li>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"mp-Card mp-Card--rounded login\">
\t\t\t\t\t";
        // line 25
        if (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "username"), "method") || $this->getAttribute(($context["errors"] ?? null), "has", array(0 => "password"), "method"))) {
            // line 26
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li>";
            // line 30
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_error")), "html", null, true);
            echo "</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 35
        echo "\t\t\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 36
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 43
        echo "\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<div class=\"mp-Form mp-Form--aligned\">
\t\t\t\t\t\t\t<form id=\"account-login-form\" class=\"new-design-form\" method=\"post\" action=\"";
        // line 45
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("login"));
        echo "\">
\t\t\t\t\t\t\t\t";
        // line 46
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t\t<div class=\"form-squeeze\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t<label class=\"optional-label\" for=\"username\">";
        // line 49
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_username")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"username\" placeholder=\"";
        // line 50
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_username")), "html", null, true);
        echo "\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "username"), "method")) ? (" invalid") : (""));
        echo "\" value=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("username")), "html", null, true);
        echo "\" tabindex=\"1\" required>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t<label class=\"optional-label\" for=\"password\">";
        // line 53
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_pasword")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<input id=\"password\" type=\"password\" placeholder=\"";
        // line 54
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_pasword")), "html", null, true);
        echo "\" name=\"password\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "username"), "method")) ? (" invalid") : (""));
        echo "\" tabindex=\"2\" required>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t<label class=\"optional-label\" for=\"captcha\">";
        // line 57
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_captcha")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<img src=\"/captcha.html\"/>
\t\t\t\t\t\t\t\t\t\t<input id=\"captcha\" type=\"text\" placeholder=\"";
        // line 59
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_captcha_text")), "html", null, true);
        echo "\" name=\"captcha\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
        echo "\" tabindex=\"2\" required>
\t\t\t\t\t\t\t\t\t\t";
        // line 60
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) {
            // line 61
            echo "\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "captcha"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 65
        echo "\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t<span>";
        // line 68
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_button")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t<a href=\"/register\" class=\"mp-Button mp-Button--register\">
\t\t\t\t\t\t\t\t\t\t\t<span>";
        // line 71
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.register_button")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t<a class=\"mp-TextLink\" href=\"/verify\" tabindex=\"3\">";
        // line 75
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.verify_mirror")), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t\t\t\t<div class=\"godlike mp-Icon mp-svg-info\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"godliketext godlike-right\">";
        // line 77
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.verify_mirror_warning")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t</div><br>
\t\t\t\t\t\t\t\t\t\t<a class=\"mp-TextLink\" href=\"/password/reset\" tabindex=\"3\">";
        // line 79
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.forget_password")), "html", null, true);
        echo "?</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<center>
\t\t\t\t\t\t\t\t\t\t<q>";
        // line 82
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.smart_text")), "html", null, true);
        echo "</q>
\t\t\t\t\t\t\t\t\t</center>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</section>
\t\t<div class=\"index-log mp-FooterAlternative \">
\t\t\t\t\t\t<a  href=\"http://dreadditevelidot.onion/d/RomanRoad\">
\t\t\t\t\t\t\t<img width=\"30\" title=\"Pax Romana Forum\" src=\"/web/images/dread.png\"/>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<span class=\"footer-draw\"></span>
\t\t\t\t\t\t\t<a  href=\"http://raptortiabg7uyez.onion/\">
\t\t\t\t\t\t\t<img width=\"30\" title=\"Raptor Get your links safely\" src=\"/web/images/raptor.png\"/>
\t\t\t\t\t\t</a>
\t\t\t\t</div>\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/auth/login.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 82,  195 => 79,  190 => 77,  185 => 75,  178 => 71,  172 => 68,  167 => 65,  161 => 62,  158 => 61,  156 => 60,  150 => 59,  145 => 57,  137 => 54,  133 => 53,  123 => 50,  119 => 49,  113 => 46,  109 => 45,  105 => 43,  98 => 39,  93 => 36,  90 => 35,  82 => 30,  76 => 26,  74 => 25,  67 => 21,  62 => 18,  60 => 17,  54 => 13,  51 => 12,  43 => 7,  40 => 6,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/auth/login.twig", "");
    }
}
