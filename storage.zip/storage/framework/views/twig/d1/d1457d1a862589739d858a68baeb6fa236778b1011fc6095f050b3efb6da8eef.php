<?php

/* /var/www/html/html/resources/themes/default/account/disputes/dispute.twig */
class __TwigTemplate_f4e6353c500b473afc9caa3fd8c42a87a46dd897e6aeaa536a036bb8a2868c85 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/disputes/dispute.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/message.css\" rel=\"stylesheet\">
\t<style>
\t\t#page-wrapper {
\t\t\tmargin-bottom: 0;
\t\t}
\t</style>
";
    }

    // line 11
    public function block_user_area($context, array $blocks = array())
    {
        // line 12
        echo "\t<div class=\"wide-layout\" id=\"page-wrapper\">
\t\t";
        // line 13
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "trader_type", array()) == "individual")) {
            // line 14
            echo "        \t";
            $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/disputes/dispute.twig", 14)->display($context);
            // line 15
            echo "        ";
        }
        // line 16
        echo "\t\t<div class=\"l-page indexpage\" id=\"content\" style=\"height: 800px;margin-bottom:150px;\">
\t\t\t<div style=\"top: 10px;\" class=\"inbox-messages chatheader\">
\t\t\t\t<div class=\"messages-left\">
\t\t\t\t\t<div class=\"mp-Card message-left-header\">
\t\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t\t<h1>";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_disputes")), "html", null, true);
        echo "</h1>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"message-left-header-shadow\">
\t\t\t\t\t\t<div class=\"ConversationsToolsMolecule-root\"></div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"message-left-part\">
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t<ol class=\"ConversationsOrganism-listRoot\">
\t\t\t\t\t\t\t\t";
        // line 30
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "trader_type", array()) == "buyer")) {
            // line 31
            echo "\t\t\t\t\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "disputesBuyer", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["dispute"]) {
                // line 32
                echo "\t\t\t\t\t\t\t\t\t\t<li class=\"ConversationsOrganism-listItem\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-root ConversationMolecule-selling\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 34
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.dispute.show", $this->getAttribute($context["dispute"], "id", array())));
                echo "#chat\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-leftUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-thumbnailUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ThumbnailAtom-root ThumbnailAtomSizes-lg ThumbnailAtomBorderRadii-xs\" style=\"background-image: url(";
                // line 37
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["dispute"], "seller", array()), "avatar", array()), "html", null, true);
                echo ");\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-thumbnailProfilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-sm ProfilePictureAtom-rootBordered\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 40
                echo twig_escape_filter($this->env, twig_first($this->env, $this->getAttribute($this->getAttribute($context["dispute"], "seller", array()), "username", array())), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-rightUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h2 class=\"ConversationMolecule-title\">";
                // line 46
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute")), "html", null, true);
                echo " #";
                echo twig_escape_filter($this->env, $this->getAttribute($context["dispute"], "id", array()), "html", null, true);
                echo "</h2>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-meta\">";
                // line 48
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_seller")), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["dispute"], "seller", array()), "username", array()), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-latestMessageWrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 50
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('str_limit')->getCallable(), array("limit", $this->getAttribute($this->getAttribute($this->getAttribute($context["dispute"], "replies", array()), "last", array()), "message", array()), 18)), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<footer>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-receivedDateUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 55
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
                echo ": ";
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["dispute"], "resolved", array()) == 0)) ? ("Unsolved") : (((($this->getAttribute($context["dispute"], "winner", array()) == $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array()))) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_won"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_lost")))))), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</footer>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['dispute'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 63
            echo "\t\t\t\t\t\t\t\t";
        } else {
            // line 64
            echo "\t\t\t\t\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "disputesSeller", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["dispute"]) {
                // line 65
                echo "\t\t\t\t\t\t\t\t\t\t\t<li class=\"ConversationsOrganism-listItem\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-root ConversationMolecule-selling\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 67
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.dispute.show", $this->getAttribute($context["dispute"], "id", array())));
                echo "#chat\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-leftUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-thumbnailUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ThumbnailAtom-root ThumbnailAtomSizes-lg ThumbnailAtomBorderRadii-xs\" style=\"background-image: url(";
                // line 70
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["dispute"], "buyer", array()), "avatar", array()), "html", null, true);
                echo ");\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-thumbnailProfilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-sm ProfilePictureAtom-rootBordered\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 73
                echo twig_escape_filter($this->env, twig_first($this->env, $this->getAttribute($this->getAttribute($context["dispute"], "buyer", array()), "username", array())), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-rightUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h2 class=\"ConversationMolecule-title\">";
                // line 79
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute")), "html", null, true);
                echo " #";
                echo twig_escape_filter($this->env, $this->getAttribute($context["dispute"], "id", array()), "html", null, true);
                echo "</h2>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-meta\">";
                // line 81
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["dispute"], "buyer", array()), "username", array()), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-latestMessageWrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 83
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('str_limit')->getCallable(), array("limit", $this->getAttribute($this->getAttribute($this->getAttribute($context["dispute"], "replies", array()), "last", array()), "message", array()), 18)), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<footer>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"ConversationMolecule-receivedDateUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 88
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
                echo ": ";
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["dispute"], "resolved", array()) == 0)) ? ("Unsolved") : (((($this->getAttribute($context["dispute"], "winner", array()) == $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array()))) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_won"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_lost")))))), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</footer>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['dispute'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 96
            echo "\t\t\t\t\t\t\t\t";
        }
        // line 97
        echo "\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<a name=\"chat\"></a>
\t\t\t\t<div class=\"chatindividual part2\">
\t\t\t\t\t<div class=\"chatbox\">
\t\t\t\t\t\t<header>
\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-root\">
\t\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-titleUnit\">
\t\t\t\t\t\t\t\t\t<div class=\"ConversationTopicOrganism-backLinkUnit\">
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<h2 class=\"ConversationTopicOrganism-title\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/profile\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-profilePictureUnit\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"ProfilePictureAtom-root ProfilePictureAtomSizes-md\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>S</span>
\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"ConversationTopicOrganism-name\">";
        // line 117
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute_board")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</header>
\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t<div class=\"MessagesOrganism-root\">
\t\t\t\t\t\t\t\t<div class=\"MessagesOrganism-group\">
\t\t\t\t\t\t\t\t<ol class=\"MessagesOrganism-listRoot\">
\t\t\t\t\t\t\t\t\t\t<li class=\"MessagesOrganism-listItem MessagesOrganism-listItem_from_otherparticipant\">
\t\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-root MessageMolecule-root_from_otherparticipant MessageMolecule-tail\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 131
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute_title")), "html", null, true);
        echo "<br><br><ul>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li>";
        // line 132
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute_text_1")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li><br>";
        // line 133
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute_text_2"));
        echo "</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li>";
        // line 134
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute_text_3"));
        echo "</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li>";
        // line 136
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute_text_4")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li>";
        // line 138
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispute_text_5"));
        echo "</li>
\t\t\t\t\t\t\t\t\t\t\t\t\t</u>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"MessageMolecule-meta MessageMolecule-sender\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"color:red;font-weight:bold;\">";
        // line 141
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_moderator")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t</ol>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</article>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>

";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/disputes/dispute.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  288 => 141,  282 => 138,  277 => 136,  272 => 134,  268 => 133,  264 => 132,  260 => 131,  243 => 117,  221 => 97,  218 => 96,  202 => 88,  194 => 83,  187 => 81,  180 => 79,  171 => 73,  165 => 70,  159 => 67,  155 => 65,  150 => 64,  147 => 63,  131 => 55,  123 => 50,  116 => 48,  109 => 46,  100 => 40,  94 => 37,  88 => 34,  84 => 32,  79 => 31,  77 => 30,  65 => 21,  58 => 16,  55 => 15,  52 => 14,  50 => 13,  47 => 12,  44 => 11,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/disputes/dispute.twig", "");
    }
}
