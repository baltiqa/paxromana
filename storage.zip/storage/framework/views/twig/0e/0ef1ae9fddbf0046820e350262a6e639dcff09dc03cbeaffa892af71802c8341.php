<?php

/* auth.extra.twig */
class __TwigTemplate_d4c2f2aeeb45eb5ec72df9191c27ac3fc2db7cf5e1450b89ed47b2ff4e24265c extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo " <div style=\"display: block;\" class=\"useful-links\">
                <div class=\"snippet-list\">
                    <div class=\"handigeLinks ads\">
                        <h3 class=\"heading\">";
        // line 4
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_customer")), "html", null, true);
        echo "</h3>
                        <ul>
                            <li>
                                <span class=\"svg-icon-block mp-svg-handshake\"></span> 
                                <span  class=\"title\">";
        // line 8
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_customer_title_1")), "html", null, true);
        echo "</span>
                                <span class=\"sub_title\">";
        // line 9
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_customer_text_1")), "html", null, true);
        echo "</span>
                            </li>
                            <li>
                                <span class=\"svg-icon-block mp-svg-shoppingcart\"></span> 
                                <span class=\"title\">";
        // line 13
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_customer_title_2")), "html", null, true);
        echo "</span> 
                                <span class=\"sub_title\">";
        // line 14
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_customer_text_2")), "html", null, true);
        echo "</span>
                            </li>
                            <li>
                                <span class=\"svg-icon-block mp-svg-category-diensten\"></span> 
                                <span class=\"title\">";
        // line 18
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_customer_title_3")), "html", null, true);
        echo "</span>
                                <span class=\"sub_title\">";
        // line 19
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_customer_text_3")), "html", null, true);
        echo "</span>
                            </li>
                            <h3 class=\"heading\">";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_vendor")), "html", null, true);
        echo "</h3>
                            <li>
                                <span class=\"svg-icon-block mp-svg-save\"></span> 
                                <span class=\"title\">";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_vendor_title_1")), "html", null, true);
        echo "</span> 
                                <span class=\"sub_title\">";
        // line 25
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_vendor_text_1")), "html", null, true);
        echo "</span>
                            </li>
                            <li>
                                <span class=\"svg-icon-block mp-svg-results-list\"></span> 
                                <span class=\"title\">";
        // line 29
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_vendor_title_2")), "html", null, true);
        echo "</span> 
                                <span class=\"sub_title\">";
        // line 30
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_vendor_text_2")), "html", null, true);
        echo "</span>
                            </li>
                            <li>
                                <span class=\"svg-icon-block mp-svg-payable\"></span> 
                                <span class=\"title\">";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_vendor_title_3")), "html", null, true);
        echo "</span> 
                                <span class=\"sub_title\">";
        // line 35
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.feature_vendor_text_3")), "html", null, true);
        echo "</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>";
    }

    public function getTemplateName()
    {
        return "auth.extra.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 35,  90 => 34,  83 => 30,  79 => 29,  72 => 25,  68 => 24,  62 => 21,  57 => 19,  53 => 18,  46 => 14,  42 => 13,  35 => 9,  31 => 8,  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "auth.extra.twig", "");
    }
}
