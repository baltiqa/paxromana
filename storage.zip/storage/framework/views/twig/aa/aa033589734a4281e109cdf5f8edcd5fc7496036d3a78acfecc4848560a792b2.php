<?php

/* auth.flags.twig */
class __TwigTemplate_8d56161cb71d3a4e8f7331f9a0b35ff68bca2f0f676536884f417b9fe48a76d2 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<ul class=\"flags-language\">
\t<li>
\t\t<a href=\"/lang/en\" title=\"English\">
\t\t\t<img class=\"img-responsive ";
        // line 4
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "en")) ? ("flag-selected") : (""));
        echo "\" alt=\"English language\" class=\"img-responsive\" src=\"/web/images/flags_language/usa.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/fin\" title=\"Finnish\"><img alt=\"Finish\" class=\"img-responsive ";
        // line 8
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "fin")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/fin.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/swe\" title=\"Swedish\"><img alt=\"Swedish\" class=\"img-responsive ";
        // line 12
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "swe")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/swe.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/fr\" title=\"France\"><img alt=\"France\" class=\"img-responsive ";
        // line 16
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "fr")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/fr.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/it\" title=\"Italy\"><img alt=\"Italy\" class=\"img-responsive ";
        // line 20
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "it")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/it.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/sp\" title=\"Spain\"><img alt=\"Spain\" class=\"img-responsive ";
        // line 24
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "sp")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/sp.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/de\" title=\"Germany\"><img alt=\"Germany\" class=\"img-responsive ";
        // line 28
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "de")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/de.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/pr\" title=\"Portugese\"><img alt=\"Portugese\" class=\"img-responsive ";
        // line 32
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "pr")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/pr.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>

\t<li>
\t\t<a href=\"/lang/ru\" title=\"Russian\"><img alt=\"Russian\" class=\"img-responsive ";
        // line 37
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "ru")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/ru.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/pl\" title=\"Polish\"><img alt=\"Polish\" class=\"img-responsive ";
        // line 41
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "pl")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/po.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/chi\" title=\"Chinese\"><img alt=\"Chinese\" class=\"img-responsive ";
        // line 45
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "chi")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/chi.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
\t<li>
\t\t<a href=\"/lang/hi\" title=\"Hindi\"><img alt=\"Hindi\" class=\"img-responsive ";
        // line 49
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == "hi")) ? ("flag-selected") : (""));
        echo "\" src=\"/web/images/flags_language/hi.png\" width=\"30\" height=\"20\">
\t\t</a>
\t</li>
</ul>
";
    }

    public function getTemplateName()
    {
        return "auth.flags.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 49,  95 => 45,  88 => 41,  81 => 37,  73 => 32,  66 => 28,  59 => 24,  52 => 20,  45 => 16,  38 => 12,  31 => 8,  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "auth.flags.twig", "");
    }
}
