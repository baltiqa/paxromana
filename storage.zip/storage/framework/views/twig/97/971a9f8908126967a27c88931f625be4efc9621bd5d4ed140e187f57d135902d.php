<?php

/* /var/www/html/html/resources/themes/default/account/password.twig */
class __TwigTemplate_5a25c391386a3d454566e3d28c1ec46051083f4480c8643492aaa5a2bd353027 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/password.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/extra.css\" rel=\"stylesheet\">
\t<style>
\t.form-field {
\t\tmargin-bottom: 20px;
\t}

\t</style>
";
    }

    // line 12
    public function block_user_area($context, array $blocks = array())
    {
        // line 13
        echo "\t<section id=\"content\">
\t\t";
        // line 14
        $this->loadTemplate("account.head_normal_bar.twig", "/var/www/html/html/resources/themes/default/account/password.twig", 14)->display($context);
        // line 15
        echo "\t\t<div class=\"profile canvas\" id=\"edit-email-panel\">
\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t";
        // line 18
        if ($this->getAttribute(($context["errors"] ?? null), "any", array(), "method")) {
            // line 19
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["errors"] ?? null), "all", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 23
                echo "\t\t\t\t\t\t\t\t\t<li>";
                echo twig_escape_filter($this->env, $context["error"], "html", null, true);
                echo "</li>
\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 28
        echo "
\t\t\t\t\t";
        // line 29
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 30
            echo "\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 37
        echo "
\t\t\t\t\t";
        // line 38
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 39
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 46
        echo "
\t\t\t\t\t";
        // line 47
        echo call_user_func_array($this->env->getFunction('form_model')->getCallable(), array("model", ($context["user"] ?? null), array("url" => call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.change_settings.store")), "files" => false)));
        echo "

\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 52
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_password_1")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 54
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_password_1_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input type=\"password\" name=\"old_password\" id=\"old_password\" class=\"mp-Input ";
        // line 55
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "old_password"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 60
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_password_2")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 62
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_password_2_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input type=\"password\" name=\"password\" id=\"password\" class=\"mp-Input ";
        // line 63
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "password"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 68
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_password_3")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 70
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_password_3_text")), "html", null, true);
        echo ".</span>
\t\t\t\t\t\t\t<input type=\"password\" name=\"password_confirmation\" id=\"password_confirmation\" class=\"mp-Input ";
        // line 71
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "password_confirmation"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<hr>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 78
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_1")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 80
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_1_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input type=\"password\" name=\"pin_current\" id=\"pin_current\" class=\"mp-Input ";
        // line 81
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "pin_current"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\" maxlength=\"6\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 86
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_2")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 88
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_2_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input type=\"password\" name=\"pin\" id=\"pin\" class=\"mp-Input ";
        // line 89
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "pin"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\" maxlength=\"6\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 94
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_3")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 96
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_3_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input type=\"password\" name=\"pin_confirmation\" id=\"pin_confirmation\" class=\"mp-Input ";
        // line 97
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "pin_confirmation"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\" maxlength=\"6\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 102
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_4")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 104
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_4_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<div class=\"bg-info text-center\" style=\"padding: 15px;\">
\t\t\t\t\t\t\t\t<a href=\"/account/reset_withdrawpin\">";
        // line 106
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_4_text_sub")), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 112
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_viewing_1")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 114
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_viewing_1_text")), "html", null, true);
        echo ".</span>
\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t<select class=\"";
        // line 116
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "currency"), "method")) ? (" invalid") : (""));
        echo "\" name=\"currency\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option { auth_user().currency == 'usd' ? 'selected=\"selected\"' : ''}} value=\"usd\">USD</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 118
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "eur")) ? ("selected=\"selected\"") : (""));
        echo " value=\"eur\">EUR</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 119
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "gbp")) ? ("selected=\"selected\"") : (""));
        echo " value=\"gbp\">GBP</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 120
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "aud")) ? ("selected=\"selected\"") : (""));
        echo " value=\"aud\">AUD</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 121
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()) == "cad")) ? ("selected=\"selected\"") : (""));
        echo " value=\"cad\">CAD</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 127
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_viewing_2")), "html", null, true);
        echo " </b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 129
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_viewing_2_text")), "html", null, true);
        echo " <br>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_viewing_2_sub")), "html", null, true);
        echo " : <b>";
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(($context["app"] ?? null), "getLocale", array(), "method")), "html", null, true);
        echo "</b><br>Active Language : <b>";
        echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method") == null)) ? (twig_upper_filter($this->env, $this->getAttribute(($context["app"] ?? null), "getLocale", array(), "method"))) : (twig_upper_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "applocale"), "method")))), "html", null, true);
        echo "</b></span>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 130
        $this->loadTemplate("auth.flags.twig", "/var/www/html/html/resources/themes/default/account/password.twig", 130)->display($context);
        // line 131
        echo "\t\t\t\t\t\t</div>


\t\t\t\t\t\t<hr>

\t\t\t\t\t\t<a name=\"2fa\"></a>
\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 140
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_2fa_1")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 142
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_2fa_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t";
        // line 146
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "pgp_key", array()) != null)) {
            // line 147
            echo "\t\t\t\t\t\t\t\t\t\t<input name=\"otp\" value=\"1\" id=\"otp\" ";
            echo (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "otp", array())) ? ("checked=\"checked\"") : (""));
            echo " type=\"checkbox\">
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 149
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"bg-info text-center\" style=\"padding: 15px;\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/account/change_pgp\">";
            // line 150
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_2fa_text_add")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 153
        echo "\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<hr>


\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>Captcha</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 164
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_captcha_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<img style=\"margin:5px;\" src=\"/captcha.html\"/>
\t\t\t\t\t\t\t<input type=\"text\" name=\"captcha\" id=\"captcha\" class=\"mp-Input ";
        // line 166
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\">
\t\t\t\t\t\t</div>


\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<button id=\"confirm-profile\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t<span>";
        // line 172
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_save")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<a id=\"cancel-profile\" href=\"/account/edit_profile\" class=\"secondary medium mp-Button mp-Button--secondary\">
\t\t\t\t\t\t\t\t<span>";
        // line 175
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_cancel")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t";
        // line 179
        echo call_user_func_array($this->env->getFunction('form_close')->getCallable(), array("close"));
        echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/password.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  384 => 179,  377 => 175,  371 => 172,  362 => 166,  357 => 164,  344 => 153,  338 => 150,  335 => 149,  329 => 147,  327 => 146,  320 => 142,  315 => 140,  304 => 131,  302 => 130,  292 => 129,  287 => 127,  278 => 121,  274 => 120,  270 => 119,  266 => 118,  261 => 116,  256 => 114,  251 => 112,  242 => 106,  237 => 104,  232 => 102,  224 => 97,  220 => 96,  215 => 94,  207 => 89,  203 => 88,  198 => 86,  190 => 81,  186 => 80,  181 => 78,  171 => 71,  167 => 70,  162 => 68,  154 => 63,  150 => 62,  145 => 60,  137 => 55,  133 => 54,  128 => 52,  120 => 47,  117 => 46,  110 => 42,  105 => 39,  103 => 38,  100 => 37,  93 => 33,  88 => 30,  86 => 29,  83 => 28,  78 => 25,  69 => 23,  65 => 22,  60 => 19,  58 => 18,  53 => 15,  51 => 14,  48 => 13,  45 => 12,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/password.twig", "");
    }
}
