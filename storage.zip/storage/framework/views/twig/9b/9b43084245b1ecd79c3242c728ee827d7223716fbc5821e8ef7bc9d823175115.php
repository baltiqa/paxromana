<?php

/* /var/www/html/html/resources/themes/default/account/orders/shipped.twig */
class __TwigTemplate_6b5b871bfb980e48673c97ea2a8e504d2cbcedff0dc0ec35f15d61e97e76552d extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/orders/shipped.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "
\t<div id=\"content\">
\t\t<div id=\"seller-panel\">
\t\t\t<div style=\"background-color:white;\" class=\"canvas\">
\t\t\t\t";
        // line 11
        if (($this->getAttribute(($context["orders"] ?? null), "count", array()) == null)) {
            // line 12
            echo "\t\t\t\t\t";
            $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/orders/shipped.twig", 12)->display($context);
            // line 13
            echo "\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t";
            // line 17
            $this->loadTemplate("account.orders.sales.navbar.twig", "/var/www/html/html/resources/themes/default/account/orders/shipped.twig", 17)->display($context);
            // line 18
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t</div>
\t\t\t\t\t<div style=\"margin:0;\" class=\"mp-Alert mp-Alert--info-light\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t";
            // line 27
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_no_sales")), "html", null, true);
            echo "
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        } else {
            // line 32
            echo "\t\t\t\t\t<form method=\"get\" action=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/orders/state/";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "state"), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t<input class=\"mp-Input style-scope listing-search\" placeholder=\"";
            // line 33
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_search")), "html", null, true);
            echo "\" name=\"q\" type=\"text\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "q"), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t<button class=\"mp-Button mp-Button--secondary mp-Button--xs mp-SearchForm-search style-scope mp-Header\" type=\"submit\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-search style-scope mp-Header\"></span>
\t\t\t\t\t\t\t<span class=\"mp-show-md style-scope mp-Header\"></span>
\t\t\t\t\t\t</button>
\t\t\t\t\t</form>
\t\t\t\t\t";
            // line 39
            $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/orders/shipped.twig", 39)->display($context);
            // line 40
            echo "\t\t\t\t\t<div id=\"ad-listing-table\" class=\"table ad-listing-container seller\">
\t\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t<div class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t\t";
            // line 45
            $this->loadTemplate("account.orders.sales.navbar.twig", "/var/www/html/html/resources/themes/default/account/orders/shipped.twig", 45)->display($context);
            // line 46
            echo "\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t";
            // line 52
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? null));
            foreach ($context['_seq'] as $context["i"] => $context["item"]) {
                // line 53
                echo "\t\t\t\t\t\t\t<div id=\"ad-listing-table-body\" class=\"table-body\">
\t\t\t\t\t\t\t\t<div class=\"row ad-listing compact\">
\t\t\t\t\t\t\t\t\t<div class=\"cells\">
\t\t\t\t\t\t\t\t\t\t<div class=\"cell icon-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"check\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t\t\t<b>";
                // line 59
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order")), "html", null, true);
                echo " ID:
\t\t\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell thumbnail-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumbnail-wrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "url", array()), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                // line 67
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method") == null)) ? ("/web/images/noimage.png") : ($this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method"))), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"10\" cols=\"30\" style=\"resize: vertical;\" readonly=\"\" value=\"\">";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_address", array()), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"title\" href=\"";
                // line 75
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.orders.show", $context["item"]));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 76
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "product_title", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 79
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t#";
                // line 80
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "hash", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 83
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t<b>";
                // line 84
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["item"], "is_digital", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1")))), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 87
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")), "html", null, true);
                echo "</label><br><a href=\"/profile/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 90
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_shipping_method")), "html", null, true);
                echo "</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "shipping", array()), "name", array()), "html", null, true);
                echo "/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "shipping", array()), "days", array()), "html", null, true);
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                echo "/
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 91
                if (($this->getAttribute($context["item"], "currency", array()) == "BTC")) {
                    // line 92
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "BTC
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 93
$context["item"], "currency", array()) == "LTC")) {
                    // line 94
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "LTC
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 95
$context["item"], "currency", array()) == "XMR")) {
                    // line 96
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "XMR
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 98
                echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 100
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_purschased")), "html", null, true);
                echo ":</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "created_at", array()), "toFormattedDateString", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 103
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
                echo ":</label><br><b>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "amount", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 104
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell position-column features-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 109
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_auto_finalized")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--obp mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 111
                if ((twig_date_format_filter($this->env, $this->getAttribute($context["item"], "auto_final", array()), "Y-m-d H:i:s") < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                    // line 112
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t0 ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                    echo " / 0 ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                    echo " / 0 ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                    echo " - 0 ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 114
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, ($this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "days", array()) + ($this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "weeks", array()) * 7)), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 115
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 116
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 117
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 118
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 119
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 120
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 121
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 123
                echo "\t\t\t\t\t\t\t\t\t\t\t\t</button><br>
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 124
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item2")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"";
                // line 125
                echo ((($this->getAttribute($context["item"], "currency", array()) == "BTC")) ? ("btc20") : (((($this->getAttribute($context["item"], "currency", array()) == "XMR")) ? ("xmr20") : ("ltc20"))));
                echo "\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 126
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "payment_type", array()), "payment_name", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 129
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item3")), "html", null, true);
                echo " :</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 130
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "price", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 131
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "currency", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 134
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
                echo "</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"";
                // line 135
                echo ((($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) ? ("color:black") : (((($this->getAttribute($context["item"], "status", array()) == "shipped")) ? ("color:blue") : (((($this->getAttribute($context["item"], "status", array()) == "cancelled")) ? ("color:red;") : (((($this->getAttribute($context["item"], "status", array()) == "disputed")) ? ("color:red;") : ("color:green;"))))))));
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "status", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t<div class=\"cta\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 139
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.orders.show", $context["item"]));
                echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 140
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_details")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 148
            echo "\t\t\t\t\t\t";
            echo $this->getAttribute(($context["orders"] ?? null), "links", array(), "method");
            echo "
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 151
        echo "\t\t\t</div>
\t\t</div>
\t</div>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/orders/shipped.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  379 => 151,  372 => 148,  358 => 140,  354 => 139,  345 => 135,  341 => 134,  335 => 131,  331 => 130,  327 => 129,  321 => 126,  317 => 125,  313 => 124,  310 => 123,  305 => 121,  301 => 120,  297 => 119,  293 => 118,  289 => 117,  285 => 116,  281 => 115,  276 => 114,  264 => 112,  262 => 111,  257 => 109,  249 => 104,  243 => 103,  235 => 100,  231 => 98,  225 => 96,  223 => 95,  218 => 94,  216 => 93,  211 => 92,  209 => 91,  200 => 90,  190 => 87,  184 => 84,  180 => 83,  174 => 80,  170 => 79,  164 => 76,  160 => 75,  154 => 72,  146 => 67,  142 => 66,  134 => 61,  129 => 59,  121 => 53,  117 => 52,  109 => 46,  107 => 45,  100 => 40,  98 => 39,  87 => 33,  80 => 32,  72 => 27,  61 => 18,  59 => 17,  53 => 13,  50 => 12,  48 => 11,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/orders/shipped.twig", "");
    }
}
