<?php

/* /var/www/html/html/resources/themes/default/profile/store.twig */
class __TwigTemplate_01b8144b0e6203aec5253808bbea39aa5cdc57b8e21b8262b6e9940980421af5 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/profile/store.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"/web/css/own_profile_detail.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t\t";
        // line 10
        $this->loadTemplate("profile.head-profile.twig", "/var/www/html/html/resources/themes/default/profile/store.twig", 10)->display($context);
        // line 11
        echo "\t\t\t<div class=\"mp-Page-element mp-Page-element--full-width mp-Page-element--breadCrumbAndSaveSearch\">
\t\t\t\t<div class=\"mp-Nav-breadcrumb\">
\t\t\t\t\t<h1 class=\"mp-Nav-breadcrumb-item\">";
        // line 13
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_total")), "html", null, true);
        echo "
\t\t\t\t\t\t";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["profile"] ?? null), "listings", array()), "count", array(), "method"), "html", null, true);
        echo "
\t\t\t\t\t\t";
        // line 15
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("listings")), "html", null, true);
        echo "
\t\t\t\t\t\t";
        // line 16
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_products")), "html", null, true);
        echo "</h1>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<div class=\"l-main-left\" style=\"width:100%\">
\t\t\t\t<ul class=\"mp-Listings mp-Listings--gallery-view\">
\t\t\t\t\t";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["listings"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 23
            echo "\t\t\t\t\t\t<li class=\"mp-Listing mp-Listing--gallery-item \">
\t\t\t\t\t\t\t<a href=\"";
            // line 24
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["item"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["item"], "title", array()))))));
            echo "\">
\t\t\t\t\t\t\t\t<figure class=\"mp-Listing-image-container\"><img title=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
            echo "\" src=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "photo", array(), "method"), "html", null, true);
            echo "\"></figure>
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-content\">
\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t<h3 class=\"mp-Listing-title\">";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
            echo "</h3>                                 
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-price mp-text-price-label\">&nbsp;";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["item"], "price", array()), $this->getAttribute($context["item"], "currency", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-location\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-website-grey\"></span>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipped_from", array()), "html", null, true);
            echo "&#10230;";
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["item"], "countryNames", array(), "method"), 0, 36), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-date\">
                                        <span class=\"mp-Icon mp-svg-browse\"></span>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "orders", array()), "count", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
            echo "<br><span class=\"mp-Icon mp-svg-eye-open\"></span>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "views_count", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_views")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "\t\t\t\t</ul>
                <div class=\"mp-PaginationControls\">
\t\t\t\t\t\t";
        // line 44
        echo $this->getAttribute(($context["listings"] ?? null), "links", array());
        echo "
\t\t\t\t\t</div>
\t\t\t</div>

\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/profile/store.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 44,  129 => 42,  110 => 35,  103 => 33,  94 => 29,  90 => 28,  82 => 25,  78 => 24,  75 => 23,  71 => 22,  62 => 16,  58 => 15,  54 => 14,  50 => 13,  46 => 11,  44 => 10,  40 => 8,  37 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/profile/store.twig", "");
    }
}
