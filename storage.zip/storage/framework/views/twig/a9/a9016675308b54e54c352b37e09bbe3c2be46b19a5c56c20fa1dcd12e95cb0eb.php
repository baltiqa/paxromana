<?php

/* /var/www/html/html/resources/themes/default/account/orders/finalized.twig */
class __TwigTemplate_545b0eba67d4d7ab3eb156530afb0b82c44ee0ab20242796c422b869aad79a66 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/orders/finalized.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "
\t<div id=\"content\">
\t\t<div id=\"seller-panel\">
\t\t\t<div style=\"background-color:white;\" class=\"canvas\">
\t\t\t\t";
        // line 11
        if (($this->getAttribute(($context["orders"] ?? null), "count", array()) == null)) {
            // line 12
            echo "\t\t\t\t\t";
            $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/orders/finalized.twig", 12)->display($context);
            // line 13
            echo "\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t";
            // line 17
            $this->loadTemplate("account.orders.sales.navbar.twig", "/var/www/html/html/resources/themes/default/account/orders/finalized.twig", 17)->display($context);
            // line 18
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t</div>
\t\t\t\t\t<div style=\"margin:0;\" class=\"mp-Alert mp-Alert--info-light\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t";
            // line 27
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_no_sales")), "html", null, true);
            echo "
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t";
        } else {
            // line 33
            echo "\t\t\t\t\t\t<form method=\"get\" action=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/orders/state/";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "state"), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t<input class=\"mp-Input style-scope listing-search\" placeholder=\"";
            // line 34
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_search")), "html", null, true);
            echo "\" name=\"q\" type=\"text\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "q"), "method"), "html", null, true);
            echo "\">
\t\t\t\t\t\t<button class=\"mp-Button mp-Button--secondary mp-Button--xs mp-SearchForm-search style-scope mp-Header\" type=\"submit\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-search style-scope mp-Header\"></span>
\t\t\t\t\t\t\t<span class=\"mp-show-md style-scope mp-Header\"></span>
\t\t\t\t\t\t</button>
\t\t\t\t\t</form>
\t\t\t\t\t";
            // line 40
            $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/orders/finalized.twig", 40)->display($context);
            // line 41
            echo "\t\t\t\t\t<div id=\"ad-listing-table\" class=\"table ad-listing-container seller\">
\t\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t\t<div id=\"ad-listing-header\" class=\"table-head ad-listing compact\">
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t<div class=\"cell select-column\">
\t\t\t\t\t\t\t\t\t\t";
            // line 46
            $this->loadTemplate("account.orders.sales.navbar.twig", "/var/www/html/html/resources/themes/default/account/orders/finalized.twig", 46)->display($context);
            // line 47
            echo "\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            // line 52
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? null));
            foreach ($context['_seq'] as $context["i"] => $context["item"]) {
                // line 53
                echo "\t\t\t\t\t\t\t<div id=\"ad-listing-table-body\" class=\"table-body\">
\t\t\t\t\t\t\t\t<div class=\"row ad-listing compact\">
\t\t\t\t\t\t\t\t\t<div class=\"cells\">
\t\t\t\t\t\t\t\t\t\t<div class=\"cell icon-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"check\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t\t\t<b>";
                // line 59
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order")), "html", null, true);
                echo " ID:
\t\t\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell thumbnail-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumbnail-wrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "url", array()), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                // line 67
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method") == null)) ? ("/web/images/noimage.png") : ($this->getAttribute($this->getAttribute($context["item"], "listing", array()), "getPhoto", array(), "method"))), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell\">
\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"10\" cols=\"30\" style=\"resize: vertical;\" readonly=\"\" value=\"\">";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_address", array()), "html", null, true);
                echo "</textarea>
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"title\" href=\"";
                // line 76
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.orders.show", $context["item"]));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 77
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "product_title", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 80
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t#";
                // line 81
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "hash", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 84
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t<b>";
                // line 85
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["item"], "is_digital", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1")))), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 88
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")), "html", null, true);
                echo "</label><br><a href=\"/profile/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 91
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_shipping_method")), "html", null, true);
                echo "</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "shipping", array()), "name", array()), "html", null, true);
                echo "/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "shipping", array()), "days", array()), "html", null, true);
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                echo "/
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 92
                if (($this->getAttribute($context["item"], "currency", array()) == "BTC")) {
                    // line 93
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "BTC
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 94
$context["item"], "currency", array()) == "LTC")) {
                    // line 95
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "LTC
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 96
$context["item"], "currency", array()) == "XMR")) {
                    // line 97
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipping_fee", array()), "html", null, true);
                    echo "XMR
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 99
                echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 101
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_purschased")), "html", null, true);
                echo ":</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "created_at", array()), "toFormattedDateString", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 104
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
                echo ":</label><br><b>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "amount", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 105
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell position-column features-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--green mp-Button--xs\" disabled>";
                // line 110
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status3")), "html", null, true);
                echo " </button><br>
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 111
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item2")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"";
                // line 112
                echo ((($this->getAttribute($context["item"], "currency", array()) == "BTC")) ? ("btc20") : (((($this->getAttribute($context["item"], "currency", array()) == "XMR")) ? ("xmr20") : ("ltc20"))));
                echo "\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 113
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "payment_type", array()), "payment_name", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 116
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item3")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 117
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "price", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 118
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "currency", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 121
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
                echo "</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"";
                // line 122
                echo ((($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) ? ("color:black") : (((($this->getAttribute($context["item"], "status", array()) == "shipped")) ? ("color:blue") : (((($this->getAttribute($context["item"], "status", array()) == "cancelled")) ? ("color:red;") : (((($this->getAttribute($context["item"], "status", array()) == "disputed")) ? ("color:red;") : ("color:green;"))))))));
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "status", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t<div class=\"cta\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 126
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.orders.show", $context["item"]));
                echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 127
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_details")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 135
            echo "\t\t\t\t\t\t";
            echo $this->getAttribute(($context["orders"] ?? null), "links", array(), "method");
            echo "
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 138
        echo "\t\t\t</div>
\t\t</div>
\t</div>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/orders/finalized.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  328 => 138,  321 => 135,  307 => 127,  303 => 126,  294 => 122,  290 => 121,  284 => 118,  280 => 117,  276 => 116,  270 => 113,  266 => 112,  262 => 111,  258 => 110,  250 => 105,  244 => 104,  236 => 101,  232 => 99,  226 => 97,  224 => 96,  219 => 95,  217 => 94,  212 => 93,  210 => 92,  201 => 91,  191 => 88,  185 => 85,  181 => 84,  175 => 81,  171 => 80,  165 => 77,  161 => 76,  154 => 72,  146 => 67,  142 => 66,  134 => 61,  129 => 59,  121 => 53,  117 => 52,  110 => 47,  108 => 46,  101 => 41,  99 => 40,  88 => 34,  81 => 33,  72 => 27,  61 => 18,  59 => 17,  53 => 13,  50 => 12,  48 => 11,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/orders/finalized.twig", "");
    }
}
