<?php

/* layouts.app */
class __TwigTemplate_a8e98c91b4bec6f7d249592ca4d51749f2974a77737f0c20a4dd3dfabbaa48c9 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
    <meta charset=\"utf-8\">
    <title>≥ ";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "title"), "method"), "html", null, true);
        echo "</title>

    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/favicon.ico\" rel=\"shortcut icon\">
    <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/css/style.css\" rel=\"stylesheet\">

    ";
        // line 11
        $this->displayBlock('css', $context, $blocks);
        // line 12
        echo "
</head>
<body>

    ";
        // line 16
        $this->displayBlock('navbar', $context, $blocks);
        // line 21
        echo "
    ";
        // line 22
        $this->displayBlock('content', $context, $blocks);
        // line 23
        echo "
    ";
        // line 24
        $this->displayBlock('footer', $context, $blocks);
        // line 27
        echo "
</body>

</html>
";
    }

    // line 11
    public function block_css($context, array $blocks = array())
    {
    }

    // line 16
    public function block_navbar($context, array $blocks = array())
    {
        // line 17
        echo "
    ";
        // line 18
        $this->loadTemplate("layouts.navbar.twig", "layouts.app", 18)->display($context);
        // line 19
        echo "    
    ";
    }

    // line 22
    public function block_content($context, array $blocks = array())
    {
    }

    // line 24
    public function block_footer($context, array $blocks = array())
    {
        // line 25
        echo "    ";
        $this->loadTemplate("layouts.footer.twig", "layouts.app", 25)->display($context);
        // line 26
        echo "    ";
    }

    public function getTemplateName()
    {
        return "layouts.app";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  101 => 26,  98 => 25,  95 => 24,  90 => 22,  85 => 19,  83 => 18,  80 => 17,  77 => 16,  72 => 11,  64 => 27,  62 => 24,  59 => 23,  57 => 22,  54 => 21,  52 => 16,  46 => 12,  44 => 11,  39 => 9,  35 => 8,  30 => 6,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "layouts.app", "");
    }
}
