<?php

/* layouts.frontpage */
class __TwigTemplate_e3646540df0021c775aab71844f9c0302e4ad3ae8bca459c89da5dde716ad147 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html style=\"height: 100%; margin: 0;\">
<head>
    <meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
    <title>≥ ";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "title"), "method"), "html", null, true);
        echo "</title>

    <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/favicon.ico\" rel=\"shortcut icon\">
    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/css/style.css\" rel=\"stylesheet\">

    ";
        // line 10
        $this->displayBlock('css', $context, $blocks);
        // line 11
        echo "
</head>
<body style=\"height: 100%; margin: 0;\">

    ";
        // line 15
        $this->displayBlock('navbar', $context, $blocks);
        // line 17
        echo "
    ";
        // line 18
        $this->displayBlock('content', $context, $blocks);
        // line 19
        echo "
  

</body>

</html>
";
    }

    // line 10
    public function block_css($context, array $blocks = array())
    {
    }

    // line 15
    public function block_navbar($context, array $blocks = array())
    {
        // line 16
        echo "    ";
    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layouts.frontpage";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 18,  75 => 16,  72 => 15,  67 => 10,  57 => 19,  55 => 18,  52 => 17,  50 => 15,  44 => 11,  42 => 10,  37 => 8,  33 => 7,  28 => 5,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "layouts.frontpage", "");
    }
}
