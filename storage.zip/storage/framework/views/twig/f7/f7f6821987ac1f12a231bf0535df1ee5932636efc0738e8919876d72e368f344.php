<?php

/* /var/www/html/html/resources/themes/default/account/ads.twig */
class __TwigTemplate_90a89050cde1ade0ca0a7da09de7ffe7fb1931cc29cfae7b0167f909540deb4a extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/ads.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_email.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "\t<section style=\"margin-bottom: 800px;\" id=\"content\">
\t\t";
        // line 8
        $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/ads.twig", 8)->display($context);
        // line 9
        echo "\t\t<div class=\"profile canvas\" id=\"edit-email-panel\">
\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t<form method=\"POST\" action=\"";
        // line 12
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.ads.buyingads", ($context["listing"] ?? null)));
        echo "\">
\t\t\t\t\t\t";
        // line 13
        echo csrf_field();
        echo "
\t\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t\t\t";
        // line 15
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 16
            echo "\t\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        }
        // line 23
        echo "
\t\t\t\t\t\t\t";
        // line 24
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 25
            echo "\t\t\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        }
        // line 32
        echo "\t\t\t\t\t\t\tListing :
\t\t\t\t\t\t\t<a href=\"";
        // line 33
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t&nbsp;&nbsp; ";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_categories")), "html", null, true);
        echo " :
\t\t\t\t\t\t\t<a href=\"/category/";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "category", array()), "id", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "category", array()), "name", array()), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t\t\t<h1 class=\"heading\">";
        // line 37
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_purschase_a3")), "html", null, true);
        echo " </h1>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 40
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_purschase_a3_text"));
        echo "</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t";
        // line 43
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.currently_available")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t";
        // line 45
        echo twig_escape_filter($this->env, ($context["count"] ?? null), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t";
        // line 47
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.currently_available1")), "html", null, true);
        echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t<b>";
        // line 51
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.example")), "html", null, true);
        echo " Star A+++</b>
\t\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t\t<div class=\"mp-Card-trevor philips\">
\t\t\t\t\t\t\t\t\t<article style=\"height: 350px;width: 23%;\" class=\"mp-Listing-card feed-item\">
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-card-body\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"mp-Listing-card-clickable-container\" href=\"";
        // line 56
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<figure class=\"mp-Listing-card-image\" style=\"height: 250px;background-image: url('";
        // line 57
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "getPhoto", array(), "method"), "html", null, true);
        echo "')\"></figure>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-card-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"mp-Listing-card-title\">";
        // line 59
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-card-price\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"price-old\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute(($context["listing"] ?? null), "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array())), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 63
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-label\">";
        // line 65
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "orders", array()), "count", array()), "html", null, true);
        echo ")(5.0<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>)</p>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t<b>Ads Star A+++ ";
        // line 76
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
        echo " :</b>
\t\t\t\t\t\t\t\t\t";
        // line 77
        if ((twig_date_format_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "spotlight", array()), "Y-m-d H:i:s") > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
            // line 78
            echo "\t\t\t\t\t\t\t\t\t\t<span style=\"color:green;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.active")), "html", null, true);
            echo "</span><br>
\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
            // line 79
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_over")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--success mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t";
            // line 81
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "spotlight"), "method"), "days", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\tdays
\t\t\t\t\t\t\t\t\t\t\t";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "spotlight"), "method"), "hours", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\thours
\t\t\t\t\t\t\t\t\t\t\t";
            // line 85
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "spotlight"), "method"), "minutes", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\tmin
\t\t\t\t\t\t\t\t\t\t\t";
            // line 87
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "spotlight"), "method"), "seconds", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\tsec
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 91
            echo "\t\t\t\t\t\t\t\t\t\t<span style=\"color:red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.not_active")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t";
        }
        // line 93
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t";
        // line 95
        if (((($context["count"] ?? null) != 0) && ($this->getAttribute(($context["listing"] ?? null), "spotlight", array()) < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s")))) {
            // line 96
            echo "\t\t\t\t\t\t\t\t\t\t<button name=\"stara3\" value=\"xmr\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 97
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 98
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice(60, "USD", "yes"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\tXMR</span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t<button name=\"stara3\" value=\"btc\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 102
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 103
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice(60, "USD", "yes"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\tBTC</span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t<button name=\"stara3\" value=\"ltc\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 107
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 108
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice(60, "USD", "yes"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\tLTC</span>
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 112
            echo "\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--success mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t";
            // line 113
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_no")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t";
        }
        // line 116
        echo "\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<hr>
\t\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<form method=\"POST\" action=\"";
        // line 125
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.ads.buyingads", ($context["listing"] ?? null)));
        echo "\">
\t\t\t\t\t\t\t";
        // line 126
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t\t\t\t<h1 class=\"heading\">";
        // line 129
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_purschase_a2")), "html", null, true);
        echo "</h1>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 132
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_purschase_a2_text"));
        echo "</span>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t\t<b>";
        // line 137
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.example")), "html", null, true);
        echo " Star A++</b>
\t\t\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t\t\t<li style=\"background-color: #F7F7F6;\" class=\"mp-Listing mp-Listing--list-item\">
\t\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 140
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "\" class=\"mp-Listing-coverLink\">
\t\t\t\t\t\t\t\t\t\t\t<figure class=\"mp-Listing-image-container\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-image-item mp-Listing-image-item--main\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img title=\"Cloned ads1s\" src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "getPhoto", array(), "method"), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</figure>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--title-description-attributes\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<h3 class=\"mp-Listing-title\">";
        // line 148
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--price-date-feature\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-price mp-text-price-label\">";
        // line 151
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute(($context["listing"] ?? null), "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array())), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 152
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing--sellerInfo\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-seller-name\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
        // line 158
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "orders", array()), "count", array()), "html", null, true);
        echo ")(5.0<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t</span>)</a>
\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-location\">WW⟶ WW (";
        // line 162
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.example")), "html", null, true);
        echo ")
\t\t\t\t\t\t\t\t\t\t\t\t<br><b>Ads</b>
\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-seller-link\">
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 166
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
        echo ":
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 167
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "orders", array()), "count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t\t<b>Ads Star A++ ";
        // line 173
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
        echo " :</b>
\t\t\t\t\t\t\t\t\t\t";
        // line 174
        if ((twig_date_format_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "priority_until", array()), "Y-m-d H:i:s") > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
            // line 175
            echo "\t\t\t\t\t\t\t\t\t\t\t<span style=\"color:green;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.active")), "html", null, true);
            echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
            // line 176
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_over")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--success mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 178
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "priority_until"), "method"), "days", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\tdays
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 180
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "priority_until"), "method"), "hours", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\thours
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 182
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "priority_until"), "method"), "minutes", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\tmin
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 184
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "priority_until"), "method"), "seconds", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\tsec
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 188
            echo "\t\t\t\t\t\t\t\t\t\t\t<span style=\"color:red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.not_active")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 190
        echo "\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t";
        // line 193
        if ((twig_date_format_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "priority_until", array()), "Y-m-d H:i:s") < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
            // line 194
            echo "\t\t\t\t\t\t\t\t\t\t\t<button name=\"stara2\" value=\"xmr\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 195
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 196
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice(10, "USD", "yes"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tXMR</span>
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t<button name=\"stara2\" value=\"btc\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 200
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 201
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice(10, "USD", "yes"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tBTC</span>
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t<button name=\"stara2\" value=\"ltc\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t<span>";
            // line 205
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 206
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice(10, "USD", "yes"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tLTC</span>
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 210
            echo "\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--success mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 211
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.active")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 214
        echo "
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<hr>
\t\t\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t\t<form method=\"POST\" action=\"";
        // line 223
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.ads.buyingads", ($context["listing"] ?? null)));
        echo "\">
\t\t\t\t\t\t\t\t";
        // line 224
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t\t\t\t\t<h1 class=\"heading\">";
        // line 227
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_purschase_a1")), "html", null, true);
        echo "</h1>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 230
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_purschase_a1_text"));
        echo "</span>
\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t\t\t<b>";
        // line 235
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.example")), "html", null, true);
        echo " Star A+</b>
\t\t\t\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t\t\t\t<li style=\"background-color: #F7F7F6;\" class=\"mp-Listing mp-Listing--list-item\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 238
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "\" class=\"mp-Listing-coverLink\">
\t\t\t\t\t\t\t\t\t\t\t\t<figure class=\"mp-Listing-image-container\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-image-item mp-Listing-image-item--main\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img title=\"";
        // line 241
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "\" src=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "getPhoto", array(), "method"), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</figure>
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--title-description-attributes\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3 class=\"mp-Listing-title\">";
        // line 246
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--price-date-feature\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-price mp-text-price-label\">";
        // line 249
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute(($context["listing"] ?? null), "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array())), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 250
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing--sellerInfo\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-seller-name\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
        // line 256
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "orders", array()), "count", array()), "html", null, true);
        echo ")(5.0<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>)</a>
\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-location\">WW⟶ WW (";
        // line 260
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.example")), "html", null, true);
        echo ")
\t\t\t\t\t\t\t\t\t\t\t\t\t<br><b>Ads</b>
\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-seller-link\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 264
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
        echo ":
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 265
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "orders", array()), "count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li class=\"mp-Listing mp-Listing--other-seller\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--left mp-text-paragraph\">Also from this vendor</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--center\">
\t\t\t\t\t\t\t\t\t\t\t ";
        // line 271
        if (($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "childs", array()), "count", array()) != 0)) {
            // line 272
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "childs", array()), "slice", array(0 => 0, 1 => 3), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["adslisted"]) {
                // line 273
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["adslisted"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["adslisted"], "title", array()))))));
                echo "\" class=\"mp-Listing-other-seller-items ";
                echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "childs", array()), 0, array(), "array") == $context["adslisted"])) ? ("mp-Listing-other-seller-items--default") : (""));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-other-seller-image-container\"><img src=\"";
                // line 274
                echo twig_escape_filter($this->env, $this->getAttribute($context["adslisted"], "photo", array()), "html", null, true);
                echo "\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-other-seller-info-container\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3 class=\"mp-TextLink\">";
                // line 276
                echo twig_escape_filter($this->env, $this->getAttribute($context["adslisted"], "title", array()), "html", null, true);
                echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-text-price-label\">";
                // line 277
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["adslisted"], "price", array()), $this->getAttribute($context["adslisted"], "currency", array())), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 278
                echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['adslisted'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 282
            echo "\t\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 283
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_no_child")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 285
        echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--right\">
\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"mp-TextLink\" href=\"/profile/";
        // line 287
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_view_all")), "html", null, true);
        echo "<span class=\"mp-Icon mp-svg-arrow-right-blue\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t\t\t<b>Ads Star A+ ";
        // line 295
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
        echo " :</b>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 296
        if ((twig_date_format_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "bold_until", array()), "Y-m-d H:i:s") > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
            // line 297
            echo "\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"color:green;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.active")), "html", null, true);
            echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
            // line 298
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_over")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--success mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 300
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "bold_until"), "method"), "days", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tdays
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 302
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "bold_until"), "method"), "hours", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\thours
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 304
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "bold_until"), "method"), "minutes", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tmin
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 306
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "elapsed", array(0 => "bold_until"), "method"), "seconds", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tsec
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 310
            echo "\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"color:red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.not_active")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 312
        echo "\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t";
        // line 314
        if (($this->getAttribute(($context["listing"] ?? null), "parent_id", array()) == 0)) {
            // line 315
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            if (((twig_date_format_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "bold_until", array()), "Y-m-d H:i:s") < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s")) || ($this->getAttribute(($context["listing"] ?? null), "bold_until", array()) == null))) {
                // line 316
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<button name=\"stara1\" value=\"xmr\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 317
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 318
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice(5, "USD", "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\tXMR</span>
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t<button name=\"stara1\" value=\"btc\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 322
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 323
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice(5, "USD", "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\tBTC</span>
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t<button name=\"stara1\" value=\"ltc\" type=\"submit\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 327
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 328
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice(5, "USD", "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\tLTC</span>
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 332
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--success mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 333
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.active")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 336
            echo "\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 338
            echo "\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.ads_no_child")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 340
        echo "\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</section>


\t\t\t";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/ads.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  763 => 340,  757 => 338,  753 => 336,  747 => 333,  744 => 332,  737 => 328,  733 => 327,  726 => 323,  722 => 322,  715 => 318,  711 => 317,  708 => 316,  705 => 315,  703 => 314,  699 => 312,  693 => 310,  686 => 306,  681 => 304,  676 => 302,  671 => 300,  666 => 298,  661 => 297,  659 => 296,  655 => 295,  642 => 287,  638 => 285,  632 => 283,  629 => 282,  619 => 278,  615 => 277,  611 => 276,  606 => 274,  599 => 273,  594 => 272,  592 => 271,  583 => 265,  579 => 264,  572 => 260,  561 => 256,  552 => 250,  548 => 249,  542 => 246,  532 => 241,  526 => 238,  520 => 235,  512 => 230,  506 => 227,  500 => 224,  496 => 223,  485 => 214,  479 => 211,  476 => 210,  469 => 206,  465 => 205,  458 => 201,  454 => 200,  447 => 196,  443 => 195,  440 => 194,  438 => 193,  433 => 190,  427 => 188,  420 => 184,  415 => 182,  410 => 180,  405 => 178,  400 => 176,  395 => 175,  393 => 174,  389 => 173,  380 => 167,  376 => 166,  369 => 162,  358 => 158,  349 => 152,  345 => 151,  339 => 148,  331 => 143,  325 => 140,  319 => 137,  311 => 132,  305 => 129,  299 => 126,  295 => 125,  284 => 116,  278 => 113,  275 => 112,  268 => 108,  264 => 107,  257 => 103,  253 => 102,  246 => 98,  242 => 97,  239 => 96,  237 => 95,  233 => 93,  227 => 91,  220 => 87,  215 => 85,  210 => 83,  205 => 81,  200 => 79,  195 => 78,  193 => 77,  189 => 76,  173 => 65,  168 => 63,  164 => 62,  158 => 59,  153 => 57,  149 => 56,  141 => 51,  134 => 47,  129 => 45,  124 => 43,  118 => 40,  112 => 37,  105 => 35,  101 => 34,  95 => 33,  92 => 32,  85 => 28,  80 => 25,  78 => 24,  75 => 23,  68 => 19,  63 => 16,  61 => 15,  56 => 13,  52 => 12,  47 => 9,  45 => 8,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/ads.twig", "");
    }
}
