<?php

/* /var/www/html/html/resources/themes/default/account/vendor_settings.twig */
class __TwigTemplate_21d6eead3952f546779dd01dbb0a8271bb24b57438d1afc31264e310ac5b932b extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/vendor_settings.twig", 1);
        $this->blocks = array(
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_user_area($context, array $blocks = array())
    {
        // line 4
        echo "\t<div id=\"content\">
\t\t";
        // line 5
        $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/vendor_settings.twig", 5)->display($context);
        // line 6
        echo "\t\t<div style=\"margin-bottom: 50%;\" class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t<form method=\"POST\" action=\"";
        // line 8
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.update.store"));
        echo "\" accept-charset=\"UTF-8\" enctype=\"multipart/form-data\">
\t\t\t\t\t";
        // line 9
        echo csrf_field();
        echo "
\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t\t";
        // line 11
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 12
            echo "\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 19
        echo "
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 22
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_toc")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_1")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<textarea style=\"height:150px;\" class=\"mp-Textarea \" id=\"terms\" name=\"terms\">";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "terms_conditions", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 29
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_title_2")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 31
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_2")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<div class=\"mp-Select \">
\t\t\t\t\t\t\t\t<select class=\"\" name=\"holiday\">
\t\t\t\t\t\t\t\t\t<option value=\"0\" ";
        // line 34
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "on_vacation", array()) == 0)) ? ("selected=\"selected\"") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_no")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"1\" ";
        // line 35
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "on_vacation", array()) == 1)) ? ("selected=\"selected\"") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_yes")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 42
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_title_3")), "html", null, true);
        echo " Bitcoin</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 44
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_3")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<div class=\"mp-Select \">
\t\t\t\t\t\t\t\t<select class=\"\" name=\"bitcoin\">
\t\t\t\t\t\t\t\t\t<option value=\"0\" ";
        // line 47
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "support_bitcoin", array()) == 0)) ? ("selected=\"selected\"") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_no")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"1\" ";
        // line 48
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "support_bitcoin", array()) == 1)) ? ("selected=\"selected\"") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_yes")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 55
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_title_3")), "html", null, true);
        echo " Monero</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 57
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_4")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<div class=\"mp-Select \">
\t\t\t\t\t\t\t\t<select class=\"\" name=\"monero\">
\t\t\t\t\t\t\t\t\t<option value=\"0\" ";
        // line 60
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "support_monero", array()) == 0)) ? ("selected=\"selected\"") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_no")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"1\" ";
        // line 61
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "support_monero", array()) == 1)) ? ("selected=\"selected\"") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_yes")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 68
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_title_3")), "html", null, true);
        echo " Litecoin</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 70
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_5")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<div class=\"mp-Select \">
\t\t\t\t\t\t\t\t<select class=\"\" name=\"litecoin\">
\t\t\t\t\t\t\t\t\t<option value=\"0\" ";
        // line 73
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "support_litecoin", array()) == 0)) ? ("selected=\"selected\"") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_no")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"1\" ";
        // line 74
        echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "support_litecoin", array()) == 1)) ? ("selected=\"selected\"") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_yes")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 81
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_5")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 83
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_6")), "html", null, true);
        echo " </span>
\t\t\t\t\t\t\t<div style=\"padding: 15px;background-color: #d9edf7;text-align:center;\">
\t\t\t\t\t\t\t\t<a href=\"/account/multisig\">";
        // line 85
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_7")), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 91
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_9")), "html", null, true);
        echo " :
\t\t\t\t\t\t\t\t\t";
        // line 92
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "has_fe", array()) != 1)) {
            // line 93
            echo "\t\t\t\t\t\t\t\t\t\t<span style=\"color:red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_2")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 95
            echo "\t\t\t\t\t\t\t\t\t\t<span style=\"color:green;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_1")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t";
        }
        // line 97
        echo "\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t";
        // line 99
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "has_fe", array()) != 1)) {
            // line 100
            echo "\t\t\t\t\t\t\t<span class=\"help-block\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_8")), "html", null, true);
            echo "
\t\t\t\t\t\t\t  <a href=\"/account/create/ticket?t=vendor\">";
            // line 101
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_9")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t";
        } else {
            // line 104
            echo "\t\t\t\t\t\t\t<span class=\"help-block\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vendor_settings_text_10")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t";
        }
        // line 106
        echo "
\t\t\t\t\t\t\t
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<button id=\"confirm-profile\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t<span>";
        // line 112
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_save")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<a id=\"cancel-profile\" href=\"/account/edit_profile\" class=\"secondary medium mp-Button mp-Button--secondary\">
\t\t\t\t\t\t\t\t<span>";
        // line 115
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_cancel")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/vendor_settings.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  274 => 115,  268 => 112,  260 => 106,  254 => 104,  248 => 101,  243 => 100,  241 => 99,  237 => 97,  231 => 95,  225 => 93,  223 => 92,  219 => 91,  210 => 85,  205 => 83,  200 => 81,  188 => 74,  182 => 73,  176 => 70,  171 => 68,  159 => 61,  153 => 60,  147 => 57,  142 => 55,  130 => 48,  124 => 47,  118 => 44,  113 => 42,  101 => 35,  95 => 34,  89 => 31,  84 => 29,  77 => 25,  73 => 24,  68 => 22,  63 => 19,  56 => 15,  51 => 12,  49 => 11,  44 => 9,  40 => 8,  36 => 6,  34 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/vendor_settings.twig", "");
    }
}
