<?php

/* /var/www/html/html/resources/themes/default/account/tickets/index.twig */
class __TwigTemplate_1728480462defbc18331e2e41979f2972971c5ab85ec2bb7fbc403caca4fa6c6 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/tickets/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_support.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "\t<div id=\"content\">
\t\t";
        // line 8
        $this->loadTemplate("account.head_support.twig", "/var/www/html/html/resources/themes/default/account/tickets/index.twig", 8)->display($context);
        // line 9
        echo "\t\t<div style=\"margin-bottom: 50%;\" class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
            \t";
        // line 11
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 12
            echo "\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 19
        echo "            <div class=\"headcreate\">
            <a href=\"/account/create/ticket\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
            ";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_title")), "html", null, true);
        echo "
\t\t\t</a>
             <p>";
        // line 23
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_title_text")), "html", null, true);
        echo "</p>
            </div>
            <h2>";
        // line 25
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_ticket_list")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["tickets"] ?? null), "count", array()), "html", null, true);
        echo ")</h2>
\t\t\t\t<div class=\"head-table\">
\t\t\t\t\t<table style=\"width:100%;background-color:#FFFFFF;\">
\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t<tr>
                                <th scope=\"col\">Id</th>
                                <th scope=\"col\">";
        // line 31
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_table_1")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 32
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_subject")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 33
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_categories")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 35
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_news")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 36
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_action")), "html", null, true);
        echo "</th>
                            </tr>
\t\t\t\t\t\t</thead>
                        <tbody>
                        ";
        // line 40
        if (($this->getAttribute(($context["tickets"] ?? null), "count", array()) != null)) {
            // line 41
            echo "                        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["tickets"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["ticket"]) {
                // line 42
                echo "                        <tr>
                        <td>";
                // line 43
                echo twig_escape_filter($this->env, $this->getAttribute($context["ticket"], "id", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 44
                echo twig_escape_filter($this->env, $this->getAttribute($context["ticket"], "created_at", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 45
                echo twig_escape_filter($this->env, (twig_slice($this->env, $this->getAttribute($context["ticket"], "title", array()), 0, 10) . "..."), "html", null, true);
                echo "</td>
                        <td>";
                // line 46
                echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["ticket"], "category", array()), 0, 15), "html", null, true);
                echo "</td>
                        <td class=\"";
                // line 47
                echo ((($this->getAttribute($context["ticket"], "status", array()) == "Answered")) ? ("answered") : (((($this->getAttribute($context["ticket"], "status", array()) == "Unanswered")) ? ("unanswered") : ("closed"))));
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["ticket"], "status", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 48
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["ticket"], "updated_at", array()), "diffForHumans", array(), "method"), "html", null, true);
                echo "</td>
                        <td><a href=\"/account/ticket/";
                // line 49
                echo twig_escape_filter($this->env, $this->getAttribute($context["ticket"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_view")), "html", null, true);
                echo "</a></td>
                        </tr>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ticket'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 52
            echo "                        ";
        } else {
            // line 53
            echo "                        <td>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_none")), "html", null, true);
            echo "</td>
                        ";
        }
        // line 55
        echo "
                        </tbody>
\t\t\t\t\t</table>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/tickets/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 55,  167 => 53,  164 => 52,  153 => 49,  149 => 48,  143 => 47,  139 => 46,  135 => 45,  131 => 44,  127 => 43,  124 => 42,  119 => 41,  117 => 40,  110 => 36,  106 => 35,  102 => 34,  98 => 33,  94 => 32,  90 => 31,  79 => 25,  74 => 23,  69 => 21,  65 => 19,  58 => 15,  53 => 12,  51 => 11,  47 => 9,  45 => 8,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/tickets/index.twig", "");
    }
}
