<?php

/* /var/www/html/html/resources/themes/default/profile/messagecreate.twig */
class __TwigTemplate_a5bf246a60e4dc8b6c6f41f558df6f5a29bfd88f054cb1fcdb2e3017c072884d extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/profile/messagecreate.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/sent_message.css\" rel=\"stylesheet\">

\t<style>
\t\t.mp-FooterAlternative {
\t\t\tposition: absolute;
\t\t}
\t</style>


";
    }

    // line 16
    public function block_content($context, array $blocks = array())
    {
        // line 17
        echo "\t<div id=\"page-wrapper\">
\t\t<div class=\"l-page\">
\t\t\t<h1 class=\"page-header\">
\t\t\t\t";
        // line 20
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_title")), "html", null, true);
        echo "
\t\t\t\t";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "username", array()), "html", null, true);
        echo "
\t\t\t</h1>
\t\t\t<section id=\"content\">
\t\t\t\t<div class=\"mp-Card\">
\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t\t<form id=\"asq-form\" action=\"";
        // line 26
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("profile.sendmessage", $this->getAttribute(($context["profile"] ?? null), "username", array())));
        echo "\" method=\"post\">
\t\t\t\t\t\t    ";
        // line 27
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t<div class=\"tip mp-Card mp-Card-block mp-Card-block--highlight\">
\t\t\t\t\t\t\t\t<h6>
\t\t\t\t\t\t\t\t\t";
        // line 30
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_title1")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t</h6>
\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t<li>";
        // line 33
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_tips1")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t";
        // line 36
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_tips2"));
        echo "
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_tips3")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t";
        // line 42
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_message_tips4")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<h3>";
        // line 46
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_your_message")), "html", null, true);
        echo "</h3>

\t\t\t\t\t\t\t<div class=\"form-field form-textarea\">
\t\t\t\t\t\t\t\t<textarea class=\"mp-Textarea ";
        // line 49
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "message"), "method")) ? (" invalid") : (""));
        echo "\" id=\"message\" name=\"message\" maxlength=\"10000\" data-maxlength=\"10000\"></textarea>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t <div class=\"mp-Form-controlGroup\">
                                            <img src=\"/captcha.html\" />
                                            <label class=\"mp-Form-controlGroup-label optional-label\"
                                                for=\"captcha\">Captcha</label>
                                            <input style=\"width:50%;\" id=\"captcha\" type=\"text\" placeholder=\"captcha\" name=\"captcha\"
                                                class=\"mp-Input ";
        // line 57
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
        echo "\"
                                                tabindex=\"2\">
                                            ";
        // line 59
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) {
            // line 60
            echo "                                            <div
                                                class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
                                                ";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "captcha"), "method"), "html", null, true);
            echo "
                                            </div>
                                            ";
        }
        // line 65
        echo "                                </div>
\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"1\" name=\"encrypt\"/>";
        // line 66
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pgp")), "html", null, true);
        echo "


\t\t\t\t\t\t\t<div class=\"buttonbar\">
\t\t\t\t\t\t\t\t<input id=\"send-asq\" type=\"submit\" class=\"mp-Button mp-Button--primary\" value=\"";
        // line 70
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_sent")), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<h3>";
        // line 73
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pgp_key_of")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t";
        // line 74
        echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "username", array()), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t<pre style=\"word-wrap: break-word; white-space: pre-wrap; line-height: normal;\">";
        // line 75
        echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "pgp_key", array()), "html", null, true);
        echo "</pre>


\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<p class=\"asq-disclaimer\">
\t\t\t\t";
        // line 83
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_disclaimer")), "html", null, true);
        echo "
\t\t\t\t</p>

\t\t\t</section>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/profile/messagecreate.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 83,  166 => 75,  162 => 74,  158 => 73,  152 => 70,  145 => 66,  142 => 65,  136 => 62,  132 => 60,  130 => 59,  125 => 57,  114 => 49,  108 => 46,  101 => 42,  95 => 39,  89 => 36,  83 => 33,  77 => 30,  71 => 27,  67 => 26,  59 => 21,  55 => 20,  50 => 17,  47 => 16,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/profile/messagecreate.twig", "");
    }
}
