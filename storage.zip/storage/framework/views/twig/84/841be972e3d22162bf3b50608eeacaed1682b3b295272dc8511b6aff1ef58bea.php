<?php

/* components.star_rating */
class __TwigTemplate_88c4d3e32323f6a94900e423988b468a3df6b7ff4b12972cab50192273c6e3e8 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((($context["rating"] ?? null) == 5)) {
            // line 2
            echo "<i></i><i></i><i></i><i></i><i></i>
";
        } elseif ((        // line 3
($context["rating"] ?? null) == 4)) {
            // line 4
            echo "<i></i><i></i><i></i><i></i>
";
        } elseif ((        // line 5
($context["rating"] ?? null) == 3)) {
            // line 6
            echo "<i></i><i></i><i></i>
";
        } elseif ((        // line 7
($context["rating"] ?? null) == 2)) {
            // line 8
            echo "<i></i><i></i>
";
        } elseif ((        // line 9
($context["rating"] ?? null) == 1)) {
            // line 10
            echo "<i></i>
";
        }
        // line 12
        echo "
";
    }

    public function getTemplateName()
    {
        return "components.star_rating";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 12,  41 => 10,  39 => 9,  36 => 8,  34 => 7,  31 => 6,  29 => 5,  26 => 4,  24 => 3,  21 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "components.star_rating", "");
    }
}
