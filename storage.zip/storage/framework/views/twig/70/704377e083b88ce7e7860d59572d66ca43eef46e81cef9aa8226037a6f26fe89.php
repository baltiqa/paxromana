<?php

/* /var/www/html/html/resources/themes/default/account/purchase_history/index.twig */
class __TwigTemplate_987ee9a9269af158acfd504b7db75c2ce90892597ad949ac1b854fc75cfe8f0f extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/purchase_history/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "
\t<section id=\"content\">
\t\t<h2>My Orders</h2>
\t\t<div id=\"seller-panel\">
\t\t\t<div class=\"canvas\">
\t\t\t\t";
        // line 12
        if (($this->getAttribute(($context["orders"] ?? null), "count", array()) != 0)) {
            // line 13
            echo "\t\t\t\t\t<div id=\"ad-listing-table\" class=\"table ad-listing-container seller\">
\t\t\t\t\t\t<div id=\"table-head-stickies\" class=\"sticky\">
\t\t\t\t\t\t\t<div id=\"scroll-under-top-border\"></div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div id=\"ad-listing-table-body\" class=\"table-body\">
\t\t\t\t\t\t\t";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
                // line 19
                echo "\t\t\t\t\t\t\t\t<div class=\"row ad-listing compact\">
\t\t\t\t\t\t\t\t\t<div class=\"cells\">
\t\t\t\t\t\t\t\t\t\t<div class=\"cell icon-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"check\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t\t\t<b>ID:
\t\t\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "id", array()), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell thumbnail-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumbnail-wrapper\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 31
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.purchase-history.show", $context["order"]));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                // line 32
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute($context["order"], "listing", array()), "getPhoto", array(), "method") == null)) ? ("/web/images/noimage.png") : ($this->getAttribute($this->getAttribute($context["order"], "listing", array()), "getPhoto", array(), "method"))), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"title\" href=\"";
                // line 39
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.purchase-history.show", $context["order"]));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<span>";
                // line 40
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "product_title", array()), "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 43
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "</label>
\t\t\t\t\t\t\t\t\t\t\t\t#";
                // line 44
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "hash", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 47
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_seller")), "html", null, true);
                echo "</label><br><a href=\"/profile/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "seller", array()), "username", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "seller", array()), "username", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 50
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_shipping_method")), "html", null, true);
                echo "</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "shipping", array()), "name", array()), "html", null, true);
                echo "/";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "shipping", array()), "days", array()), "html", null, true);
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                echo "/
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 51
                if (($this->getAttribute($context["order"], "currency", array()) == "BTC")) {
                    // line 52
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "shipping_fee", array()), "html", null, true);
                    echo "BTC 
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 53
$context["order"], "currency", array()) == "LTC")) {
                    // line 54
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "shipping_fee", array()), "html", null, true);
                    echo "LTC
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 55
$context["order"], "currency", array()) == "XMR")) {
                    // line 56
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "shipping_fee", array()), "html", null, true);
                    echo "XMR
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 58
                echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell description-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 62
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_purschased")), "html", null, true);
                echo ":</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "created_at", array()), "toFormattedDateString", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 65
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_news")), "html", null, true);
                echo ":</label><br>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "updated_at", array()), "toFormattedDateString", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 68
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
                echo ":</label><br><b>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "amount", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 69
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
                echo "(s)</b>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"cell position-column features-column\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 74
                if (($this->getAttribute($context["order"], "status", array()) == "accepted")) {
                    // line 75
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_auto_cancelled")), "html", null, true);
                    echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 77
                    if ((twig_date_format_filter($this->env, $this->getAttribute($context["order"], "auto_final", array()), "Y-m-d H:i:s") < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                        // line 78
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                        echo " / 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                        echo " / 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                        echo " - 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 80
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "days", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 81
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 82
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 83
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 84
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 85
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 86
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 87
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 89
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t</button><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 91
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["order"], "status", array()) == "processing")) {
                    // line 92
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_auto_cancelled")), "html", null, true);
                    echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 94
                    if ((twig_date_format_filter($this->env, $this->getAttribute($context["order"], "auto_final", array()), "Y-m-d H:i:s") < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                        // line 95
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                        echo " / 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                        echo " / 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                        echo " - 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 97
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "days", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 98
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 99
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 100
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 101
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 102
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 103
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 104
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 106
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t</button><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 108
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 109
                if (($this->getAttribute($context["order"], "status", array()) == "shipped")) {
                    // line 110
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_auto_finalized")), "html", null, true);
                    echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 112
                    if ((twig_date_format_filter($this->env, $this->getAttribute($context["order"], "auto_final", array()), "Y-m-d H:i:s") < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                        // line 113
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                        echo " / 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                        echo " / 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                        echo " - 0 ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 115
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        echo twig_escape_filter($this->env, ($this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "days", array()) + ($this->getAttribute($this->getAttribute($context["order"], "until", array(0 => "auto_final"), "method"), "weeks", array()) * 7)), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 116
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 117
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 118
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 119
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 120
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 121
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 122
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 124
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t</button><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 126
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["order"], "status", array()) == "finalized")) {
                    // line 127
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--green mp-Button--xs\" disabled>";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status3")), "html", null, true);
                    echo "</button><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 129
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["order"], "status", array()) == "disputed")) {
                    // line 130
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs\" disabled>";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status4")), "html", null, true);
                    echo "</button><br>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 132
                echo "

\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 134
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item2")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"";
                // line 135
                echo ((($this->getAttribute($context["order"], "currency", array()) == "BTC")) ? ("btc20") : (((($this->getAttribute($context["order"], "currency", array()) == "XMR")) ? ("xmr20") : ("ltc20"))));
                echo "\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 136
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["order"], "payment_type", array()), "payment_name", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 139
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item3")), "html", null, true);
                echo ":</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 141
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "price", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "currency", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"item\">
\t\t\t\t\t\t\t\t\t\t\t\t<label>";
                // line 144
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_table_3")), "html", null, true);
                echo "</label><br>
\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"";
                // line 145
                echo ((($this->getAttribute($context["order"], "status", array()) == "processing")) ? ("color:black") : (((($this->getAttribute($context["order"], "status", array()) == "shipped")) ? ("color:blue;") : (((($this->getAttribute($context["order"], "status", array()) == "cancelled")) ? ("color:red;") : (((($this->getAttribute($context["order"], "status", array()) == "disputed")) ? ("color:red;") : ("color:green;"))))))));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 146
                echo twig_escape_filter($this->env, $this->getAttribute($context["order"], "status", array()), "html", null, true);
                echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div class=\"cta\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 149
                if (($this->getAttribute($context["order"], "status", array()) == "shipped")) {
                    // line 150
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<form action=\"";
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.dispute.create", $this->getAttribute($context["order"], "hash", array())));
                    echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 151
                    echo csrf_field();
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"mp-Button mp-Button--dangerous mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 153
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_create_dispute")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t\t\t\t<form action=\"";
                    // line 156
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.finalize.order", $this->getAttribute($context["order"], "hash", array())));
                    echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 157
                    echo csrf_field();
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"mp-Button mp-Button--green mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 159
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_finalize_order")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 163
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["order"], "status", array()) == "disputed")) {
                    // line 164
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.dispute.show", $this->getAttribute($this->getAttribute($context["order"], "dispute", array()), "id", array())));
                    echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 165
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_see_dispute")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 168
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 169
                if (($this->getAttribute($context["order"], "status", array()) == "cancelled")) {
                    // line 170
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"mp-Button mp-Button--dangerous mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 171
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status5")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 174
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 175
                if (($this->getAttribute($context["order"], "status", array()) == "finalized")) {
                    // line 176
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.purchase-history.feedback", $context["order"]));
                    echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 177
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_leave_feedback")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 180
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.purchase-history.show", $context["order"]));
                echo "\" class=\"mp-Button--xs mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 181
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_details")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 188
            echo "\t\t\t\t\t\t";
        } else {
            // line 189
            echo "\t\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--info-light\">
\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t\t";
            // line 193
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_no_orders")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t";
        }
        // line 199
        echo "
\t\t\t\t\t\t<div class=\"mp-PaginationControls\">
\t\t\t\t\t\t\t";
        // line 201
        echo $this->getAttribute(($context["orders"] ?? null), "links", array());
        echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/purchase_history/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  555 => 201,  551 => 199,  542 => 193,  536 => 189,  533 => 188,  520 => 181,  515 => 180,  509 => 177,  504 => 176,  502 => 175,  499 => 174,  493 => 171,  490 => 170,  488 => 169,  485 => 168,  479 => 165,  474 => 164,  471 => 163,  464 => 159,  459 => 157,  455 => 156,  449 => 153,  444 => 151,  439 => 150,  437 => 149,  431 => 146,  427 => 145,  423 => 144,  415 => 141,  410 => 139,  404 => 136,  400 => 135,  396 => 134,  392 => 132,  386 => 130,  383 => 129,  377 => 127,  374 => 126,  370 => 124,  365 => 122,  361 => 121,  357 => 120,  353 => 119,  349 => 118,  345 => 117,  341 => 116,  336 => 115,  324 => 113,  322 => 112,  316 => 110,  314 => 109,  311 => 108,  307 => 106,  302 => 104,  298 => 103,  294 => 102,  290 => 101,  286 => 100,  282 => 99,  278 => 98,  273 => 97,  261 => 95,  259 => 94,  253 => 92,  250 => 91,  246 => 89,  241 => 87,  237 => 86,  233 => 85,  229 => 84,  225 => 83,  221 => 82,  217 => 81,  212 => 80,  200 => 78,  198 => 77,  192 => 75,  190 => 74,  182 => 69,  176 => 68,  168 => 65,  160 => 62,  154 => 58,  148 => 56,  146 => 55,  141 => 54,  139 => 53,  134 => 52,  132 => 51,  123 => 50,  113 => 47,  107 => 44,  103 => 43,  97 => 40,  93 => 39,  83 => 32,  79 => 31,  71 => 26,  62 => 19,  58 => 18,  51 => 13,  49 => 12,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/purchase_history/index.twig", "");
    }
}
