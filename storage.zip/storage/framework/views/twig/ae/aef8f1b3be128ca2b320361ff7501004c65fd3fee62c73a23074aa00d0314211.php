<?php

/* /var/www/html/html/resources/themes/default/auth/register.twig */
class __TwigTemplate_239381ffce1800a00559e93a4cf76433a518a842ed9cacee915e66fb671b98dd extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.frontpage", "/var/www/html/html/resources/themes/default/auth/register.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.frontpage";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/css/index.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        // line 7
        echo "\t<header>
\t\t<div class=\"mp-Header-ribbonTop\"></div>
\t\t<div class=\"mp-Header-ribbonBottom\"></div>
\t</header>
";
    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        // line 14
        echo "<div id=\"page-wrapper\">
\t\t<div class=\"l-page pagelog\">
        <section class=\"l-main-right\">
           <a class=\"pagelogo \" href=\"/\" title=\"Pax Romana\"></a>
            ";
        // line 18
        $this->loadTemplate("auth.flags.twig", "/var/www/html/html/resources/themes/default/auth/register.twig", 18)->display($context);
        // line 19
        echo "             <div class=\"mp-Alert \" style=\"background-color:#D4EFFA;\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<li style=\"color:black;\">";
        // line 22
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.session_title")), "html", null, true);
        echo "</li>
\t\t\t\t\t\t\t</div>
\t\t\t</div>
            <div class=\"mp-Card mp-Card--rounded login\">
            <div class=\"mp-Card-block\">
                <div class=\"mp-Form mp-Form--aligned\">
                    <div class=\"mp-Form-body sdk-custom\">
                        <form id=\"account-login-form\" method=\"post\" class=\"new-design-form\" action=\"";
        // line 29
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("register"));
        echo twig_escape_filter($this->env, ($context["ref_link"] ?? null), "html", null, true);
        echo "\">
                            ";
        // line 30
        echo csrf_field();
        echo "
                            <div class=\"form-squeeze\">
                            <p>";
        // line 32
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.register_text"));
        echo "</p>
                                <div class=\"mp-Form-controlGroup\">
                                    <label class=\"optional-label\" for=\"username\">";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_username")), "html", null, true);
        echo "</label>
                                    <input name=\"username\" value=\"";
        // line 35
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("username")), "html", null, true);
        echo "\" placeholder=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_username")), "html", null, true);
        echo "\" id=\"username\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "username"), "method")) ? (" invalid") : (""));
        echo "\" type=\"text\"
                                        maxlength=\"30\" required>
                                        ";
        // line 37
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "username"), "method")) {
            // line 38
            echo "                                        <div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
                                            ";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "username"), "method"), "html", null, true);
            echo "
                                         </div>
                                        ";
        }
        // line 42
        echo "                                </div>
                                <div class=\"mp-Form-controlGroup\">
                                    <label class=\"optional-label\" for=\"password\">";
        // line 44
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_pasword")), "html", null, true);
        echo "</label>
                                    <input name=\"password\" id=\"password\" placeholder=\"";
        // line 45
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_pasword")), "html", null, true);
        echo "\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "password"), "method")) ? (" invalid") : (""));
        echo "\" type=\"password\" required>
                                    ";
        // line 46
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "password"), "method")) {
            // line 47
            echo "                                    <div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
                                        ";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "password"), "method"), "html", null, true);
            echo "
                                     </div>
                                    ";
        }
        // line 51
        echo "                                </div>
                                <div class=\"mp-Form-controlGroup\">
                                    <label class=\"optional-label\" for=\"password_confirmation\">";
        // line 53
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.register_retype_password")), "html", null, true);
        echo "</label>
                                    <input name=\"password_confirmation\" placeholder=\"";
        // line 54
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.register_retype_password")), "html", null, true);
        echo "\" id=\"password_confirmation\" class=\"mp-Input\" type=\"password\" required>
                                </div>
                                <div class=\"mp-Form-controlGroup\">
                                    <label class=\"optional-label\" for=\"withdrawpin\">";
        // line 57
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.register_withdraw_pin")), "html", null, true);
        echo "</label>
                                    <input name=\"withdrawpin\" placeholder=\"";
        // line 58
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.register_withdraw_pin_placeholder")), "html", null, true);
        echo "\" value=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("withdrawpin")), "html", null, true);
        echo "\" id=\"withdrawpin\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "withdrawpin"), "method")) ? (" invalid") : (""));
        echo "\" type=\"text\"
                                        maxlength=\"6\" required>
                                        ";
        // line 60
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "withdrawpin"), "method")) {
            // line 61
            echo "                                        <div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
                                            ";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "withdrawpin"), "method"), "html", null, true);
            echo "
                                         </div>
                                        ";
        }
        // line 65
        echo "                                </div>

                                <div class=\"mp-Form-controlGroup\">
                                    <img src=\"/captcha.html\" />
                                    <input name=\"captcha\" type=\"text\" placeholder=\"";
        // line 69
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_captcha_text")), "html", null, true);
        echo "\" name=\"captcha\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
        echo "\" tabindex=\"2\"required>
                                    ";
        // line 70
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) {
            // line 71
            echo "                                    <div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
                                        ";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "captcha"), "method"), "html", null, true);
            echo "
                                     </div>
                                    ";
        }
        // line 75
        echo "                                </div>

                                    <div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/\" class=\"mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 79
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.verify_return_back")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t</a>
                                            <input type=\"submit\"
                                                class=\"mp-Button mp-Button--register\"
                                                value=\"";
        // line 83
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.register_createaccount")), "html", null, true);
        echo "\">
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
\t<div class=\"index-log mp-FooterAlternative \">
\t\t\t\t\t\t<a  href=\"http://dreadditevelidot.onion/d/RomanRoad\">
\t\t\t\t\t\t\t<img width=\"30\" title=\"Pax Romana Forum\" src=\"/web/images/dread.png\"/>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<span class=\"footer-draw\"></span>
\t\t\t\t\t\t\t<a  href=\"http://raptortiabg7uyez.onion/\">
\t\t\t\t\t\t\t<img width=\"30\" title=\"Raptor Get your links safely\" src=\"/web/images/raptor.png\"/>
\t\t\t\t\t\t</a>
\t\t\t\t</div>
    </div>
</div>

";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/auth/register.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  215 => 83,  208 => 79,  202 => 75,  196 => 72,  193 => 71,  191 => 70,  185 => 69,  179 => 65,  173 => 62,  170 => 61,  168 => 60,  159 => 58,  155 => 57,  149 => 54,  145 => 53,  141 => 51,  135 => 48,  132 => 47,  130 => 46,  124 => 45,  120 => 44,  116 => 42,  110 => 39,  107 => 38,  105 => 37,  96 => 35,  92 => 34,  87 => 32,  82 => 30,  77 => 29,  67 => 22,  62 => 19,  60 => 18,  54 => 14,  51 => 13,  43 => 7,  40 => 6,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/auth/register.twig", "");
    }
}
