<?php

/* /var/www/html/html/resources/themes/default/auth/2fa.twig */
class __TwigTemplate_e1b08514397313fcb2b598a474bf42dcf934b2d7975ccb788a865c14b3e7b7f9 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/auth/2fa.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/index.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        // line 7
        echo "\t<header>
\t\t<div class=\"mp-Header-ribbonTop\"></div>
\t\t<div class=\"mp-Header-ribbonBottom\"></div>
\t</header>
";
    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        // line 14
        echo "<div id=\"page-wrapper\">
    <div id=\"content\" class=\"l-page\">
               <a class=\"pagelogo\" href=\"/\" title=\"Pax Romana\"></a>
               \t";
        // line 17
        $this->loadTemplate("auth.flags.twig", "/var/www/html/html/resources/themes/default/auth/2fa.twig", 17)->display($context);
        // line 18
        echo "        ";
        if ($this->getAttribute(($context["errors"] ?? null), "any", array(), "method")) {
            // line 19
            echo "        <div class=\"mp-Alert mp-Alert--error\">
            <span aria-hidden=\"true\" class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
            <div>
                <ul>
                        <li>";
            // line 23
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.2fa_error")), "html", null, true);
            echo "</li>
                </ul>
            </div>
          </div>
          ";
        }
        // line 28
        echo "        <div class=\"mp-Card mp-Card--rounded login\">
            <div class=\"mp-Card-block\">
                <div id=\"login-tabs\" class=\"mp-Tab-bar mp-Tab-bar--center sdk-custom\">
                    <h3>";
        // line 31
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.2fa_title")), "html", null, true);
        echo " </h3>
                </div>
            </div>
            <div class=\"mp-Card-block\">
                <div class=\"mp-Form mp-Form--aligned\">
                    <div class=\"mp-Form-body sdk-custom\">
                        <form id=\"account-login-form\" class=\"new-design-form\" method=\"post\"
                            action=\"";
        // line 38
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("2fa_factorcheck"));
        echo "\">
                            ";
        // line 39
        echo csrf_field();
        echo "

                            <p>";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.2fa_text")), "html", null, true);
        echo "</p>

                                <h4>";
        // line 43
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.2fa_pgptitle")), "html", null, true);
        echo "</h4>
                            <p>        
     <pre style=\"word-wrap: break-word; white-space: pre-wrap; line-height: normal;\">";
        // line 45
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "suckmynuts"), "method"), "html", null, true);
        echo "</pre>

                            <div class=\"mp-Form-controlGroup\">
                                    <label class=\"mp-Form-controlGroup-label optional-label\" for=\"code\">";
        // line 48
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.2fa_code")), "html", null, true);
        echo "</label>
                                    <input type=\"text\" name=\"code\" placeholder=\"";
        // line 49
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.2fa_pgp_placeholder")), "html", null, true);
        echo "\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "code"), "method")) ? (" invalid") : (""));
        echo "\"  value=\"\" tabindex=\"1\">
                            </div>

                                <div class=\"mp-Form-controlGroup centered-control-group last-control-group\">
                                    <button id=\"account-login-button\"
                                        class=\"l-stretchable-auto mp-Button mp-Button--primary\">
                                        <span>";
        // line 55
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.anti_phishing_submit")), "html", null, true);
        echo "</span>
                                    </button>
                                </div>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
";
    }

    // line 69
    public function block_footer($context, array $blocks = array())
    {
        // line 70
        echo "
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/auth/2fa.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 70,  150 => 69,  134 => 55,  123 => 49,  119 => 48,  113 => 45,  108 => 43,  103 => 41,  98 => 39,  94 => 38,  84 => 31,  79 => 28,  71 => 23,  65 => 19,  62 => 18,  60 => 17,  55 => 14,  52 => 13,  44 => 7,  41 => 6,  34 => 4,  31 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/auth/2fa.twig", "");
    }
}
