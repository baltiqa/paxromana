<?php

/* /var/www/html/html/resources/themes/default/account/reports/index.twig */
class __TwigTemplate_1b51a383f4ad20cba8a9e4bc176504304bc74baa78d8be48debd71c5a8d98eec extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/reports/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_support.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "\t<div id=\"content\">
\t\t";
        // line 8
        $this->loadTemplate("account.head_support.twig", "/var/www/html/html/resources/themes/default/account/reports/index.twig", 8)->display($context);
        // line 9
        echo "\t\t<div style=\"margin-bottom: 50%;\" class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
            \t";
        // line 11
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 12
            echo "\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 19
        echo "            <div class=\"headcreate\">
             <p>";
        // line 20
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_title_text")), "html", null, true);
        echo "</p>
            </div>
            <h2>";
        // line 22
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_report_list")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["reports"] ?? null), "count", array()), "html", null, true);
        echo ")</h2>
\t\t\t\t<div class=\"head-table\">
\t\t\t\t\t<table style=\"width:100%;background-color:#FFFFFF;\">
\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t<tr>
                                <th scope=\"col\">Id</th>
                                <th scope=\"col\">";
        // line 28
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_table_1")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 29
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_reason")), "html", null, true);
        echo "</th >
                                <th scope=\"col\">";
        // line 30
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_notes")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 31
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_reported_user")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 32
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 33
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_news")), "html", null, true);
        echo "</th>
                                <th scope=\"col\">";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_action")), "html", null, true);
        echo "</th>
                            </tr>
\t\t\t\t\t\t</thead>
                        <tbody>
                        ";
        // line 38
        if (($this->getAttribute(($context["reports"] ?? null), "count", array()) != null)) {
            // line 39
            echo "                        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["reports"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["report"]) {
                // line 40
                echo "                        <tr>
                        <td>";
                // line 41
                echo twig_escape_filter($this->env, $this->getAttribute($context["report"], "id", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 42
                echo twig_escape_filter($this->env, $this->getAttribute($context["report"], "created_at", array()), "html", null, true);
                echo "</td>
                        <td>";
                // line 43
                echo twig_escape_filter($this->env, (twig_slice($this->env, $this->getAttribute($context["report"], "reason", array()), 0, 10) . "..."), "html", null, true);
                echo "</td>
                        <td>";
                // line 44
                echo twig_escape_filter($this->env, (twig_slice($this->env, $this->getAttribute($context["report"], "notes", array()), 0, 15) . "..."), "html", null, true);
                echo "</td>
                        <td>";
                // line 45
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["report"], "reportedUser", array()), "username", array()), "html", null, true);
                echo "</td>
                        <td class=\"";
                // line 46
                echo ((($this->getAttribute($context["report"], "active", array()) == "1")) ? ("unanswered") : ("answered"));
                echo "\">";
                echo twig_escape_filter($this->env, ((($this->getAttribute($context["report"], "active", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_unsolved"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_solved")))), "html", null, true);
                echo "</td>
                        <td>";
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["report"], "updated_at", array()), "diffForHumans", array(), "method"), "html", null, true);
                echo "</td>
                        <td><a href=\"/account/report/";
                // line 48
                echo twig_escape_filter($this->env, $this->getAttribute($context["report"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_date")), "html", null, true);
                echo "</a></td>
                        </tr>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['report'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 51
            echo "                        ";
        } else {
            // line 52
            echo "                        <td>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_none")), "html", null, true);
            echo "</td>
                        ";
        }
        // line 54
        echo "
                        </tbody>
\t\t\t\t\t</table>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/reports/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 54,  169 => 52,  166 => 51,  155 => 48,  151 => 47,  145 => 46,  141 => 45,  137 => 44,  133 => 43,  129 => 42,  125 => 41,  122 => 40,  117 => 39,  115 => 38,  108 => 34,  104 => 33,  100 => 32,  96 => 31,  92 => 30,  88 => 29,  84 => 28,  73 => 22,  68 => 20,  65 => 19,  58 => 15,  53 => 12,  51 => 11,  47 => 9,  45 => 8,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/reports/index.twig", "");
    }
}
