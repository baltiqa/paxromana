<?php

/* layouts.navbar.twig */
class __TwigTemplate_5176e78e273e46a4af86e97ec9bda3b8338a34ed55f8cc98baf0d90c1f96dddc extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<header>
\t<div class=\"mp-Header-ribbonTop\"></div>
\t<div class=\"mp-Header-navBar\">
\t\t<div class=\"mp-Header-maxWidth\">
\t\t\t<a class=\"mp-Header-logo\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "\" title=\"Pax Romana\">Pax Romana</a>
\t\t\t<ul class=\"mp-Header-links\">
\t\t\t\t<li>
\t\t\t\t\t<a class=\"mp-Button--flat\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/wiki\"  target=\"_blank\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_help")), "html", null, true);
        echo "</a>
\t\t\t\t</li>
\t\t\t\t<li>
\t\t\t\t\t<a class=\"mp-Button--flat\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/pgp.txt\"  target=\"_blank\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.tips_5")), "html", null, true);
        echo "</a>
\t\t\t\t</li>
\t\t\t\t";
        // line 13
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "trader_type", array()) != "individual")) {
            // line 14
            echo "                <li>
\t\t\t\t\t<a class=\"mp-Button--flat\" href=\"";
            // line 15
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/apply_vendor\"  target=\"_blank\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_apply")), "html", null, true);
            echo "</a>
\t\t\t\t</li>
                ";
        }
        // line 18
        echo "\t\t\t</ul>
\t\t\t<ul class=\"mp-Header-links mp-pull-right\">
\t\t\t\t<li id=\"loggedin-user-setting\">
\t\t\t\t\t\t<div class=\"mp-hide-lte-md mp-Nav-dropdown style-scope mp-header\">
\t\t\t\t\t\t\t<span class=\"mp-Button mp-Button--flat mp-Button--xs mp-Nav-dropdown-toggle style-scope mp-header\">
\t\t\t\t\t\t\t\t<span class=\"style-scope mp-header\"><img src=\"";
        // line 23
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/";
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()), "html", null, true);
        echo ".png\"></span>
\t\t\t\t\t\t\t\t<span class=\"mp-hide-lte-md style-scope mp-header\">";
        // line 24
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--right mp-svg-arrow-down style-scope mp-header\"></span>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t<ul  style=\"min-width: 10%;\" class=\"mp-Nav-dropdown-menu style-scope mp-header\">
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 29
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "usd")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/usd.png\"> USD Dollar</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 32
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "eur")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/eur.png\"> Euro</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 35
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "gbp")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/gbp.png\"> British Pound</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 38
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "aud")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/aud.png\"> Australian Dollar</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 41
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "cad")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/cad.png\"> Canadian Dollar</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 44
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "brl")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/brl.png\"> Brazilian Real</a>
\t\t\t\t\t\t\t\t</li>\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 47
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "dkk")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/dkk.png\"> Danish Krone</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 50
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "sek")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/sek.png\"> Swedish Krona</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 53
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "nok")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/nok.png\"> Norwegian Krone</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 56
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "try")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/try.png\"> Turkish Lira</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 59
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "cny")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/cny.png\"> Chinese Yuan</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 62
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "hkd")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/hkd.png\"> Hong Kong dollar</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 65
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "rub")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/rub.png\"> Russian Roebel</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 68
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "inr")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/inr.png\"> Indian rupee</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 71
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("currency.update", array("currency" => "jpy")));
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/images/flags/jpy.png\"> Japanese yen</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</li>
\t\t\t\t<li class=\"mp-hide-custom--messages style-scope mp-Header\">
\t\t\t\t\t<a class=\"mp-Button--flat\" href=\"";
        // line 77
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/inbox#chat\" title=\"Messages\">
\t\t\t\t\t\t<div class=\"mp-Button-badge style-scope mp-Header\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-messages style-scope mp-Header\"></span>
\t\t\t\t\t\t\t<i class=\"mp-Badge mp-Badge--callToAction style-scope mp-badge\">";
        // line 80
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "unread_messages", array()), "html", null, true);
        echo "</i>
\t\t\t\t\t\t\t<span class=\"mp-hide-lte-md style-scope mp-Header\">";
        // line 81
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_messages")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"style-scope mp-Header\">
\t\t\t\t\t<a class=\"mp-Button--flat\" href=\"";
        // line 86
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/notifications\" title=\"Meldingen\">
\t\t\t\t\t\t<div class=\"mp-Button-badge style-scope mp-Header\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-notification style-scope mp-Header\"></span>
\t\t\t\t\t\t\t<i class=\"mp-Badge mp-Badge--callToAction style-scope mp-badge\">";
        // line 89
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "unreadNotifications", array()), "count", array()), "html", null, true);
        echo "</i>
\t\t\t\t\t\t\t<span class=\"mp-hide-lte-md style-scope mp-Header\">";
        // line 90
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_notifications")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t</a>
\t\t\t\t</li>
\t\t\t\t";
        // line 94
        if (call_user_func_array($this->env->getFunction('auth_guest')->getCallable(), array())) {
            // line 95
            echo "\t\t\t\t\t<li class=\"style-scope mp-Header\">
\t\t\t\t\t\t<a class=\"mp-Button--flat\" href=\"";
            // line 96
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/login\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-profile style-scope mp-Header\"></span>
\t\t\t\t\t\t\t<span class=\"mp-hide-lte-md style-scope mp-Header\">Login</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t";
        } else {
            // line 102
            echo "\t\t\t\t\t<li id=\"loggedin-user-setting\" class=\"style-scope mp-header\">
\t\t\t\t\t\t<div class=\"mp-Nav-dropdown style-scope mp-header\">
\t\t\t\t\t\t\t<a href=\"";
            // line 104
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/profile/";
            echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
            echo "\" class=\"mp-Button mp-Button--flat mp-Button--xs mp-Nav-dropdown-toggle style-scope mp-header\">
\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-profile style-scope mp-header\"></span>
\t\t\t\t\t\t\t\t<span class=\"mp-hide-lte-md style-scope mp-header\">";
            // line 106
            echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-Icon--right mp-svg-arrow-down style-scope mp-header\"></span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<ul class=\"mp-Nav-dropdown-menu style-scope mp-header\">
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header mp-label\">
\t\t\t\t\t\t\t\t\t";
            // line 111
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_account")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
            // line 114
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/profile/";
            echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_profile")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
            // line 117
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/edit_profile\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_account")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
            // line 119
            if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "trader_type", array()) == "individual")) {
                // line 120
                echo "\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header mp-label\">
\t\t\t\t\t\t\t\t\t";
                // line 121
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_v_panel")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
                // line 124
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
                echo "/account/listings\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_listing")), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
                // line 127
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
                echo "/account/orders\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_sales")), "html", null, true);
                echo "<span style=\"color:red;\">(";
                echo twig_escape_filter($this->env, ($context["processing"] ?? null), "html", null, true);
                echo ")</span></a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
            }
            // line 130
            echo "\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header mp-label\">
\t\t\t\t\t\t\t\t\t";
            // line 131
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_support")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
            // line 134
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/disputes#chat\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_disputes")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
            // line 137
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/tickets\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_tickets")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header mp-label\">
\t\t\t\t\t\t\t\t\t";
            // line 140
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_c_panel")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
            // line 143
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/purchase-history\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_orders")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
            // line 146
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/wallet\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_wallet")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
            // line 149
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
            echo "/account/favorites\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_favorites")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"/account/referrals\">";
            // line 152
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_reff")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"style-scope mp-header\">
\t\t\t\t\t\t\t\t\t<a class=\"style-scope mp-header\" href=\"";
            // line 155
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("logout"));
            echo "\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_logout")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</li>

\t\t\t\t

\t\t\t\t\t<li class=\"style-scope mp-Header\">
\t\t\t\t\t\t<a style=\"background-color: #116db4; color: white;\" class=\"mp-button--callToAction\" href=\"";
            // line 164
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.creat"));
            echo "\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-pin-callToAction-foreground style-scope mp-Header\"></span>
\t\t\t\t\t\t\t<span class=\"mp-hide-lte-md style-scope mp-Header\">";
            // line 166
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_place_listing")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>

\t\t\t\t";
        }
        // line 171
        echo "
\t\t\t</ul>
\t\t</div>
\t</div>
\t<div class=\"mp-Header-searchBar style-scope mp-Header\">
\t\t<div class=\"mp-Header-maxWidth style-scope mp-Header\">

\t\t\t<form style=\"display: contents;\" action=\"";
        // line 178
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/category/2\" method=\"get\" accept-charset=\"utf-8\">
\t\t\t\t<button class=\"mp-Button mp-Button--secondary mp-Button--xs mp-SearchForm-search searchnew\" type=\"submit\">
\t\t\t\t\t<span class=\"mp-Icon mp-svg-search style-scope mp-Header\"></span>
\t\t\t\t\t<span class=\"mp-show-md style-scope mp-Header\"></span>
\t\t\t\t</button>
\t\t\t\t<div class=\"mp-SearchFieldset-standard style-scope mp-Header\">
\t\t\t\t\t<div class=\"mp-SearchForm-query style-scope mp-Header\">
\t\t\t\t\t\t<input class=\"mp-Input style-scope newinput \" placeholder=\"";
        // line 185
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_search")), "html", null, true);
        echo "..\"  name=\"title\" type=\"text\">
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</form>
\t\t\t<ul class=\"mp-Header-links mp-pull-right cryptocurrency\">
\t\t\t\t<li></li>
\t\t\t\t<li><a href=\"/account/wallet/btc\">BTC<br><span class=\"btc20\"></span>";
        // line 191
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "btc_balance", array()), 4), "html", null, true);
        echo "<small class=\"mp-hide-lte-md\">(";
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "btc_balance", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo ")</small></a><li>
\t\t\t\t<li><a href=\"/account/wallet/xmr\">XMR<br><span class=\"xmr20\"></span>";
        // line 192
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "xmr_balance", array()), 4), "html", null, true);
        echo "<small class=\"mp-hide-lte-md\">(";
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "xmr_balance", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo ")</small></a><li>
\t\t\t\t<li><a href=\"/account/wallet/ltc\">LTC<br><span class=\"ltc20\"></span>";
        // line 193
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "ltc_balance", array()), 4), "html", null, true);
        echo "<small class=\"mp-hide-lte-md\">(";
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "ltc_balance", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo ")</small></a><li>
\t\t\t\t</ul>

\t\t\t<div style=\"margin:0\" class=\"header-illu mp-Alert mp-Alert--info-light\"><span class=\"mp-Alert-icon mp-svg-info\"></span>
                <div><span> <a href=\"";
        // line 197
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/wiki/36\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.tips_4")), "html", null, true);
        echo "</a> </span></div>
            </div>
\t\t</div>
\t</div>

</header>

";
    }

    public function getTemplateName()
    {
        return "layouts.navbar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  463 => 197,  453 => 193,  446 => 192,  439 => 191,  430 => 185,  420 => 178,  411 => 171,  403 => 166,  398 => 164,  384 => 155,  378 => 152,  370 => 149,  362 => 146,  354 => 143,  348 => 140,  340 => 137,  332 => 134,  326 => 131,  323 => 130,  313 => 127,  305 => 124,  299 => 121,  296 => 120,  294 => 119,  287 => 117,  277 => 114,  271 => 111,  263 => 106,  256 => 104,  252 => 102,  243 => 96,  240 => 95,  238 => 94,  231 => 90,  227 => 89,  221 => 86,  213 => 81,  209 => 80,  203 => 77,  192 => 71,  184 => 68,  176 => 65,  168 => 62,  160 => 59,  152 => 56,  144 => 53,  136 => 50,  128 => 47,  120 => 44,  112 => 41,  104 => 38,  96 => 35,  88 => 32,  80 => 29,  72 => 24,  66 => 23,  59 => 18,  51 => 15,  48 => 14,  46 => 13,  39 => 11,  31 => 8,  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "layouts.navbar.twig", "");
    }
}
