<?php

/* /var/www/html/html/resources/themes/default/account/multisig.twig */
class __TwigTemplate_331d9f9c20ab691bbd6ed2d966d38a1a2c278e28893ae1408063ca9a704ab878 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/multisig.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_email.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "\t<section style=\"margin-bottom: 800px;\" id=\"content\">
\t\t\t";
        // line 8
        $this->loadTemplate("account.head_normal_bar.twig", "/var/www/html/html/resources/themes/default/account/multisig.twig", 8)->display($context);
        // line 9
        echo "\t\t<div class=\"profile canvas\" id=\"edit-email-panel\">
\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t<form method=\"POST\" action=\"\" accept-charset=\"UTF-8\">
\t\t\t\t\t";
        // line 13
        echo csrf_field();
        echo "
\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t\t";
        // line 15
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 16
            echo "\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 23
        echo "
\t\t\t\t\t";
        // line 24
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 25
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 32
        echo "\t\t\t\t\t<div class=\"mp-Alert \" style=\"background-color:#F1F1E8;\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<li style=\"color:black;\">
\t\t\t\t\t\t\t\t";
        // line 36
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_multisig_no_seg32"));
        echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 42
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_multisig_1")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 44
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_multisig_1_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<textarea style=\"height:50px;\" class=\"mp-Textarea ";
        // line 45
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "btcmultisig"), "method")) ? (" invalid") : (""));
        echo "\" id=\"btcmultisig\" name=\"btcmultisig\">";
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "multisig_key_pub", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t";
        // line 48
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "trader_type", array()) == "individual")) {
            // line 49
            echo "\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
            // line 51
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_multisig_2")), "html", null, true);
            echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
            // line 53
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_multisig_2_text"));
            echo "</span>
\t\t\t\t\t\t\t<input class=\"mp-Input ";
            // line 54
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "btcsales"), "method")) ? (" invalid") : (""));
            echo "\" name=\"btcsales\" type=\"text\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "address_sales", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 57
        echo "

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 61
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_multisig_3")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 63
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_multisig_3_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input class=\"mp-Input ";
        // line 64
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "btcrefund"), "method")) ? (" invalid") : (""));
        echo "\" name=\"btcrefund\" type=\"text\" value=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "address_refunds", array()), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 65
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_multisig_3_not_deposit"));
        echo "</span>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<button id=\"confirm-profile\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t<span>";
        // line 72
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_save")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<a id=\"cancel-profile\" href=\"/account/edit_profile\" class=\"secondary medium mp-Button mp-Button--secondary\">
\t\t\t\t\t\t\t\t<span>";
        // line 75
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_cancel")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/multisig.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 75,  175 => 72,  165 => 65,  159 => 64,  155 => 63,  150 => 61,  144 => 57,  136 => 54,  132 => 53,  127 => 51,  123 => 49,  121 => 48,  113 => 45,  109 => 44,  104 => 42,  95 => 36,  89 => 32,  82 => 28,  77 => 25,  75 => 24,  72 => 23,  65 => 19,  60 => 16,  58 => 15,  53 => 13,  47 => 9,  45 => 8,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/multisig.twig", "");
    }
}
