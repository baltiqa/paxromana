<?php

/* /var/www/html/html/resources/themes/default/auth/passwords/email.twig */
class __TwigTemplate_cde986e4363875e9aa02d8b31506c5fee590a71bc64968d4f9cd87a4a0e56e08 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/auth/passwords/email.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/index.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        // line 7
        echo "\t<header>
\t\t<div class=\"mp-Header-ribbonTop\"></div>
\t\t<div class=\"mp-Header-ribbonBottom\"></div>
\t</header>
";
    }

    // line 14
    public function block_content($context, array $blocks = array())
    {
        // line 15
        echo "\t<div id=\"page-wrapper\">
    <div id=\"content\" class=\"l-page\">
\t\t<a class=\"pagelogo\" href=\"/\" title=\"Pax Romana\"></a>
\t\t     ";
        // line 18
        $this->loadTemplate("auth.flags.twig", "/var/www/html/html/resources/themes/default/auth/passwords/email.twig", 18)->display($context);
        // line 19
        echo "\t\t\t <div class=\"mp-Alert \" style=\"background-color:#D4EFFA;\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t<li style=\"color:black;\">";
        // line 22
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.session_title")), "html", null, true);
        echo "
\t\t\t\t\t\t</li>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t<section id=\"content\">
\t\t\t\t<div class=\"forgot-password-block mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block \">
                <div id=\"login-tabs\" class=\"mp-Tab-bar mp-Tab-bar--center sdk-custom\">
                    <h3>";
        // line 30
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.reset_password_title")), "html", null, true);
        echo "</h3>
             \t   </div>
            \t</div>
\t\t\t\t\t<div class=\"mp-Card-block message-block\">
\t\t\t\t\t\t";
        // line 34
        if (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "username"), "method") || $this->getAttribute(($context["errors"] ?? null), "has", array(0 => "password"), "method"))) {
            // line 35
            echo "\t\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t<li>";
            // line 39
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.reset_password_error")), "html", null, true);
            echo "</li>
\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 44
        echo "\t\t\t\t\t\t<div class=\"mp-Form login\">
\t\t\t\t\t\t\t<p>";
        // line 45
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.reset_password_text"));
        echo "</p>
\t\t\t\t\t\t\t<div class=\"mp-Form-body sdk-custom\">
\t\t\t\t\t\t\t\t<form id=\"forgot-password-form\" method=\"post\" action=\"";
        // line 47
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("verify_password"));
        echo "\">
                                      ";
        // line 48
        echo csrf_field();
        echo "
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t\t<label class=\"optional-label\" for=\"new-password\">";
        // line 50
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_username")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t\t<input id=\"new-password\" type=\"text\" name=\"username\" class=\"mp-Input ";
        // line 51
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "username"), "method")) ? (" invalid") : (""));
        echo "\" tabindex=\"1\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t\t<label class=\"optional-label\" for=\"new-password\">";
        // line 54
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_mnemonic")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t\t<input id=\"new-password\" type=\"text\" name=\"mnemonic\" class=\"mp-Input ";
        // line 55
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "mnemonic"), "method")) ? (" invalid") : (""));
        echo "\" tabindex=\"1\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div id=\"mp-Form-controlGroup\">
\t\t\t\t\t\t\t\t\t\t<img src=\"/captcha.html\"/>
\t\t\t\t\t\t\t\t\t\t<label class=\"optional-label\" for=\"captcha\">";
        // line 59
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_captcha")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<input id=\"captcha\" type=\"text\" placeholder=\"";
        // line 60
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_captcha_text")), "html", null, true);
        echo "\" name=\"captcha\" class=\"mp-Input ";
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
        echo "\" tabindex=\"2\">
\t\t\t\t\t\t\t\t\t\t";
        // line 61
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) {
            // line 62
            echo "\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "captcha"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 66
        echo "\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup\">
                                            <button class=\"mp-Button mp-Button--register\">
                                                <span>";
        // line 71
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.reset_password_continue")), "html", null, true);
        echo "</span>
                                            </button>
                                              <a href=\"/\" class=\"mp-Button mp-Button--primary\">
                                                <span>";
        // line 74
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.verify_return_back")), "html", null, true);
        echo "</span>
                                             </a>
                               </div>
\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t</div>
</div>
";
    }

    // line 86
    public function block_footer($context, array $blocks = array())
    {
        // line 87
        echo "
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/auth/passwords/email.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  192 => 87,  189 => 86,  173 => 74,  167 => 71,  160 => 66,  154 => 63,  151 => 62,  149 => 61,  143 => 60,  139 => 59,  132 => 55,  128 => 54,  122 => 51,  118 => 50,  113 => 48,  109 => 47,  104 => 45,  101 => 44,  93 => 39,  87 => 35,  85 => 34,  78 => 30,  67 => 22,  62 => 19,  60 => 18,  55 => 15,  52 => 14,  44 => 7,  41 => 6,  34 => 4,  31 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/auth/passwords/email.twig", "");
    }
}
