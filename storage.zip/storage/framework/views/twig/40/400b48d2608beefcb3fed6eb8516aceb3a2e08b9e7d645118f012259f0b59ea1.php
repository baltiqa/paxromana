<?php

/* layouts.footer.twig */
class __TwigTemplate_4a7aab7fc308538786b08e6fca2f52ece9c90c79eff81d8925e6ce3bf1166d64 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<footer class=\"mp-FooterAlternative\">
\t<div>
\t\t<a class=\"mp-TextLink mp-show-md\" href=\"/wiki/4\">
\t\t\t<span>";
        // line 4
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.about_pr")), "html", null, true);
        echo "</span>
\t\t</a>
\t\t<a class=\"mp-TextLink mp-show-md\" href=\"/wiki/29\">
\t\t\t<span>";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.tips_1")), "html", null, true);
        echo "</span>
\t\t</a>
\t\t<a class=\"mp-TextLink mp-show-sm\" href=\"/account/create/ticket\">
\t\t\t<span>";
        // line 10
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.tips_2")), "html", null, true);
        echo "</span>
\t\t</a>
\t\t<a class=\"mp-TextLink\" href=\"http://dreadditevelidot.onion/d/PaxRomana\">
\t\t\t<span>Pax Romana Forum</span>
\t\t</a>
\t\t";
        // line 15
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "trader_type", array()) == "buyer")) {
            // line 16
            echo "         <a class=\"mp-TextLink\" href=\"/account/apply_vendor\">
\t\t\t<span>";
            // line 17
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.tips_3")), "html", null, true);
            echo "</span>
\t\t</a>
\t\t";
        }
        // line 20
        echo "\t\t<a class=\"mp-TextLink\" href=\"/wiki/36\">
\t\t\t<span>";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.tips_4")), "html", null, true);
        echo "</span>
\t\t</a>
        <a class=\"mp-TextLink\" href=\"/pgp.txt\">
\t\t\t<span>";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.tips_5")), "html", null, true);
        echo "</span>
\t\t</a>
\t</div>
\t<hr>
\t<div class=\"mp-footertext\">
\t\t<span>Copyright © 2019-2020 Pax Romana</span>
\t\t<span>Server Time:
\t\t\t";
        // line 31
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "d-m-Y H:i"), "html", null, true);
        echo "</span>
\t</div>

</footer>
";
    }

    public function getTemplateName()
    {
        return "layouts.footer.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 31,  64 => 24,  58 => 21,  55 => 20,  49 => 17,  46 => 16,  44 => 15,  36 => 10,  30 => 7,  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "layouts.footer.twig", "");
    }
}
