<?php

/* /var/www/html/html/resources/themes/default/wallet/sign/ltc.twig */
class __TwigTemplate_23bd0425d46a062ace34ab1c5208c1c7d3a31c942fbd4c4575ba2ca5b2b831bb extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/wallet/sign/ltc.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_wallet.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_user_area($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t\t";
        // line 10
        $this->loadTemplate("account.head_wallet.twig", "/var/www/html/html/resources/themes/default/wallet/sign/ltc.twig", 10)->display($context);
        // line 11
        echo "
\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t<div class=\"mp-Alert \" style=\"background-color:#F1F1E8;\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<li style=\"color:black;\">
\t\t\t\t\t\t\t\t";
        // line 19
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.how_to_work"));
        echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\" style=\"text-align:center;background-color: #EDECED;\">
                            <h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t\t\t\t<b>";
        // line 25
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.signed_proof_address")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t<textarea style=\"word-wrap: break-word;background-color: #EDECED; white-space: pre-wrap; line-height: normal; height:500px;width:500px;\"  readonly=readonly>
";
        // line 28
        echo twig_escape_filter($this->env, ($context["message"] ?? null), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t</textarea>
                                            <div class=\"mp-Alert \"
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<li style=\"color:black;\">“Veni, vidi, vici.”</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/wallet/sign/ltc.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 28,  67 => 25,  58 => 19,  48 => 11,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/wallet/sign/ltc.twig", "");
    }
}
