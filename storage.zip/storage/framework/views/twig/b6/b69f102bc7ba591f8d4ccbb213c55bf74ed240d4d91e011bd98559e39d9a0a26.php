<?php

/* /var/www/html/html/resources/themes/default/category/index.twig */
class __TwigTemplate_82e4e3cfd8d9133b2bb49aa122db24cba6c62cf04d73cd09bf652bc5e1ea250a extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/category/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/products.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "\t<div class=\"mp-Page-content\">
\t\t<div class=\"mp-Page-element mp-Page-element--full-width mp-Page-element--breadCrumbAndSaveSearch\">
\t\t\t<div class=\"mp-Nav-breadcrumb\">
\t\t\t\t<a class=\"mp-TextLink mp-Nav-breadcrumb-item\" href=\"/\">
\t\t\t\t\t";
        // line 12
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_home")), "html", null, true);
        echo "
\t\t\t\t</a>
\t\t\t\t";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["breadcrumbs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["breadcrumb"]) {
            // line 15
            echo "\t\t\t\t<a class=\"mp-TextLink mp-Nav-breadcrumb-item\" href=\"/category/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["breadcrumb"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["breadcrumb"], "name", array()), "html", null, true);
            echo "</a>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['breadcrumb'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "\t\t\t\t<a class=\"mp-TextLink mp-Nav-breadcrumb-item\" href=\"/category/";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["category_choosed"] ?? null), "id", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["category_choosed"] ?? null), "name", array()), "html", null, true);
        echo "</a>
\t\t\t\t<h1 class=\"mp-Nav-breadcrumb-item\">";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listings"] ?? null), "total", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_results")), "html", null, true);
        echo "</h1>
\t\t\t\t<h1 class=\"exchangerate upper\"><span class=\"btc20\"> </span>";
        // line 19
        echo twig_escape_filter($this->env, ($context["btc_rate"] ?? null), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo "</h1>
\t\t\t\t<h1 class=\"exchangerate upper\"><span class=\"ltc20\"> </span>";
        // line 20
        echo twig_escape_filter($this->env, ($context["ltc_rate"] ?? null), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo "</h1>
\t\t\t\t<h1 class=\"exchangerate upper\"><span class=\"xmr20\"> </span>";
        // line 21
        echo twig_escape_filter($this->env, ($context["xmr_rate"] ?? null), "html", null, true);
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo "</h1>
\t\t\t</div>
\t\t</div>
\t\t<aside class=\"mp-Page-element mp-Page-element--aside\">
\t\t\t<div class=\"mp-Card\" id=\"navigation\">
\t\t\t\t<div class=\"mp-Filter\">
\t\t\t\t\t<h3 class=\"heading linetext\">
\t\t\t\t\t\t\t\t<span class=\"main-label\">";
        // line 28
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_category")), "html", null, true);
        echo "</span>
\t\t\t\t\t</h3>
\t\t\t\t\t<ul class=\"mp-Tree-list\">
\t\t\t\t\t\t<div class=\"mp-Tree-list-item\">
\t\t\t\t\t\t\t";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["categories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 33
            echo "\t\t\t\t\t\t\t\t";
            if (($this->getAttribute($context["category"], "parent_id", array()) == 0)) {
                // line 34
                echo "\t\t\t\t\t\t\t\t<li class=\"mp-Level-one mp-Level-one--open\">
\t\t\t\t\t\t\t\t\t<a class=\"mp-TextLink category-name\" href=\"/category/";
                // line 35
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
                echo "<span class=\"mp-Filter-counter\">(";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "total_listings", array()), "html", null, true);
                echo ")</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
                // line 38
                if (((($this->getAttribute(($context["category_choosed"] ?? null), "id", array()) == $this->getAttribute($context["category"], "id", array())) || ($this->getAttribute(($context["category_choosed"] ?? null), "parent_id", array()) == $this->getAttribute($context["category"], "id", array()))) || ($this->getAttribute($this->getAttribute($this->getAttribute(($context["category_choosed"] ?? null), "parent", array()), "child", array()), "id", array()) == $this->getAttribute($context["category"], "id", array())))) {
                    // line 39
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["category"], "children", array()));
                    foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                        // line 40
                        echo "\t\t\t\t\t\t\t\t\t\t<li class=\"mp-Level-two ";
                        echo ((($this->getAttribute(($context["category_choosed"] ?? null), "id", array()) == $this->getAttribute($context["child"], "id", array()))) ? ("mp-Level-two--open") : (((($this->getAttribute($this->getAttribute(($context["category_choosed"] ?? null), "parent", array()), "id", array()) == $this->getAttribute($context["child"], "id", array()))) ? ("mp-Level-two--open") : (""))));
                        echo "\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"mp-TextLink category-name\" href=\"/category/";
                        // line 41
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "id", array()), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "name", array()), "html", null, true);
                        echo "</a><span class=\"mp-Filter-counter\">(";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "total_listings", array()), "html", null, true);
                        echo ")</span>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t";
                        // line 43
                        if (((($this->getAttribute(($context["category_choosed"] ?? null), "id", array()) == $this->getAttribute($context["child"], "id", array())) || ($this->getAttribute(($context["category_choosed"] ?? null), "parent_id", array()) == $this->getAttribute($context["child"], "id", array()))) || ($this->getAttribute($this->getAttribute(($context["category_choosed"] ?? null), "parent", array()), "id", array()) == $this->getAttribute($context["child"], "id", array())))) {
                            // line 44
                            echo "\t\t\t\t\t\t\t\t\t\t\t";
                            $context['_parent'] = $context;
                            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["child"], "children", array()));
                            foreach ($context['_seq'] as $context["_key"] => $context["child2"]) {
                                // line 45
                                echo "\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"mp-Level-three\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"mp-TextLink category-name\" href=\"/category/";
                                // line 46
                                echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "id", array()), "html", null, true);
                                echo "\">";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "name", array()), "html", null, true);
                                echo "</a><span class=\"mp-Filter-counter\">(";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "total_listings", array()), "html", null, true);
                                echo ")</span>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t";
                            }
                            $_parent = $context['_parent'];
                            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child2'], $context['_parent'], $context['loop']);
                            $context = array_intersect_key($context, $_parent) + $_parent;
                            // line 49
                            echo "\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 50
                        echo "\t\t\t\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 51
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 52
                echo "\t\t\t\t\t\t\t\t";
            }
            // line 53
            echo "\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</ul>
\t\t\t\t</div>
\t\t\t</div>
\t\t</aside>
\t
\t\t<div class=\"mp-Page-element mp-Page-element--main\">
\t\t <form action=\"/category/";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute(($context["category_choosed"] ?? null), "id", array()), "html", null, true);
        echo "\" method=\"get\" accept-charset=\"utf-8\">
\t\t   \t \t<fieldset class=\"filters\">
\t\t\t\t<legend>";
        // line 63
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.cats_filter")), "html", null, true);
        echo "</legend>
\t\t\t\t<div class=\"mp-ViewControl\">
\t\t\t\t\t<div class=\"mp-ViewControl-group\">
\t\t\t\t\t\t<div class=\"mp-Select\">
\t\t\t\t\t\t\t<label>";
        // line 67
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_origin_country")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t<select class=\"mp-Select-input\" name=\"OriginCountry\">\t\t
\t\t\t\t\t\t\t\t\t<option></option>\t\t\t\t\t\t  
\t\t\t\t\t\t\t\t\t<optgroup label=\"Continents\">
\t\t\t\t\t\t\t\t\t\t";
        // line 71
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["countries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 72
            echo "\t\t\t\t\t\t\t\t\t\t   ";
            if (($this->getAttribute($context["country"], "is_continent", array()) == 1)) {
                // line 73
                echo "\t\t\t\t\t\t\t\t\t\t\t<option ";
                echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("OriginCountry")) == $this->getAttribute($context["country"], "country_short_name", array()))) ? ("selected=\"selected\"") : (""));
                echo "  value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_short_name", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_name", array()), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t  ";
            }
            // line 75
            echo "\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 76
        echo "\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t\t<optgroup label=\"Countries\">
\t\t\t\t\t\t\t\t\t";
        // line 78
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["countries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 79
            echo "\t\t\t\t\t\t\t\t\t\t   ";
            if (($this->getAttribute($context["country"], "is_continent", array()) == 0)) {
                // line 80
                echo "\t\t\t\t\t\t\t\t\t\t\t<option ";
                echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("OriginCountry")) == $this->getAttribute($context["country"], "country_short_name", array()))) ? ("selected=\"selected\"") : (""));
                echo " value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_short_name", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_name", array()), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t  ";
            }
            // line 82
            echo "\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"mp-Select\">
\t\t\t\t\t\t\t<label>";
        // line 87
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_to")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<select class=\"mp-Select-input\" name=\"ShipsTo\">
\t\t\t\t\t\t\t\t\t<option></option>
\t\t\t\t\t\t\t\t\t<optgroup label=\"Continents\">
\t\t\t\t\t\t\t\t\t\t";
        // line 91
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["countries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 92
            echo "\t\t\t\t\t\t\t\t\t\t   ";
            if (($this->getAttribute($context["country"], "is_continent", array()) == 1)) {
                // line 93
                echo "\t\t\t\t\t\t\t\t\t\t\t<option ";
                echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("ShipsTo")) == $this->getAttribute($context["country"], "id", array()))) ? ("selected=\"selected\"") : (""));
                echo " value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_name", array()), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t  ";
            }
            // line 95
            echo "\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 96
        echo "\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t\t<optgroup label=\"Countries\">
\t\t\t\t\t\t\t\t\t";
        // line 98
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["countries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 99
            echo "\t\t\t\t\t\t\t\t\t\t   ";
            if (($this->getAttribute($context["country"], "is_continent", array()) == 0)) {
                // line 100
                echo "\t\t\t\t\t\t\t\t\t\t\t<option ";
                echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("ShipsTo")) == $this->getAttribute($context["country"], "id", array()))) ? ("selected=\"selected\"") : (""));
                echo " value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_name", array()), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t  ";
            }
            // line 102
            echo "\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"mp-Select\">
\t\t\t\t\t\t\t<label>Escrow</label>
\t\t\t\t\t\t\t<select class=\"mp-Select-input\" name=\"escrow\">
\t\t\t\t\t\t\t\t<option></option>
\t\t\t\t\t\t\t\t<option ";
        // line 110
        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("escrow")) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_yes")), "html", null, true);
        echo "&nbsp;</option>
\t\t\t\t\t\t\t\t<option ";
        // line 111
        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("escrow")) == 2)) ? ("selected=\"selected\"") : (""));
        echo "  value=\"2\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_no")), "html", null, true);
        echo " &nbsp;</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"mp-Select\">
\t\t\t\t\t\t\t<label>";
        // line 115
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.cats_categories")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<select class=\"mp-Select-input\" name=\"category\">
\t\t\t\t\t\t\t\t\t\t\t<option></option>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 118
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["categories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 119
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            if ((twig_length_filter($this->env, $this->getAttribute($context["category"], "child", array())) != null)) {
                // line 120
                echo "\t\t\t\t\t\t\t\t\t\t\t<optgroup class=\"optstyle\" label=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 121
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["category"], "child", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 122
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t ";
                    if ((twig_length_filter($this->env, $this->getAttribute($context["child"], "child", array())) != null)) {
                        // line 123
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<optgroup class=\"optstyle\" label=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "name", array()), "html", null, true);
                        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 124
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["child"], "child", array()));
                        foreach ($context['_seq'] as $context["_key"] => $context["child2"]) {
                            // line 125
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "id", array()), "html", null, true);
                            echo "\" ";
                            echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("category")) == $this->getAttribute($context["child2"], "id", array()))) ? ("selected=\"selected\"") : (""));
                            echo ">";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "name", array()), "html", null, true);
                            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child2'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 127
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 129
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "id", array()), "html", null, true);
                        echo "\" ";
                        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("category")) == $this->getAttribute($context["child"], "id", array()))) ? ("selected=\"selected\"") : (""));
                        echo ">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "name", array()), "html", null, true);
                        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 131
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 132
                echo "\t\t\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 134
                echo "\t\t\t\t\t\t\t\t\t\t\t<option class=\"optstyle\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
                echo "\" ";
                echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("category")) == $this->getAttribute($context["category"], "id", array()))) ? ("selected=\"selected\"") : (""));
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 136
            echo "\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 137
        echo "\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t\t<div class=\"mp-ViewControl\">
\t\t\t\t\t<div class=\"mp-ViewControl-group\">
\t\t\t\t\t\t<div style=\"position: relative; right: -8px; width: 30%;\" class=\"mp-Filter-fields\">
\t\t\t\t\t\t<label>";
        // line 144
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_filter_text")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<input name=\"title\" class=\"mp-Input\" placeholder=\"";
        // line 145
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_filter_text")), "html", null, true);
        echo "\" type=\"text\" value=\"";
        echo twig_escape_filter($this->env, (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("title")) != null)) ? (call_user_func_array($this->env->getFunction('request')->getCallable(), array("title"))) : ("")), "html", null, true);
        echo "\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"mp-Select\">
\t\t\t\t\t\t\t<label>";
        // line 148
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<select class=\"mp-Select-input\" name=\"ListingClass\">
\t\t\t\t\t\t\t\t<option></option>\t\t\t\t\t\t  
\t\t\t\t\t\t\t\t<option ";
        // line 151
        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("ListingClass")) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t<option ";
        // line 152
        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("ListingClass")) == 2)) ? ("selected=\"selected\"") : (""));
        echo " value=\"2\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"mp-Select\">
\t\t\t\t\t\t\t<label>";
        // line 156
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.cats_sort_by")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<select class=\"mp-Select-input\" name=\"order\">
\t\t\t\t\t\t\t\t<option></option>\t\t\t\t\t\t  
\t\t\t\t\t\t\t\t<option ";
        // line 159
        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("order")) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_filter_1")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t<option ";
        // line 160
        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("order")) == 2)) ? ("selected=\"selected\"") : (""));
        echo " value=\"2\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_filter_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t<option ";
        // line 161
        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("order")) == 3)) ? ("selected=\"selected\"") : (""));
        echo " value=\"3\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_filter_3")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t<option ";
        // line 162
        echo (((call_user_func_array($this->env->getFunction('request')->getCallable(), array("order")) == 4)) ? ("selected=\"selected\"") : (""));
        echo " value=\"4\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_filter_4")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<button type=\"submit\" style=\"position: relative; margin-left: 10px; top: 11px;\" class=\"mp-Button mp-Button--secondary\">
\t\t\t\t\t\t\t";
        // line 166
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.cats_apply_filter")), "html", null, true);
        echo "
\t\t\t\t\t\t</button>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t</fieldset>
\t\t\t</form>
\t\t\t
\t\t\t<ul class=\"mp-Listings mp-Listings--list-view\">
\t\t\t    ";
        // line 174
        if (($this->getAttribute(($context["listings"] ?? null), "count", array()) != 0)) {
            // line 175
            echo "\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["listings"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
                // line 176
                echo "\t\t\t\t";
                if ($this->getAttribute($context["product"], "getAdsListing", array(), "method")) {
                    // line 177
                    echo "\t\t\t\t\t<li style=\"background-color: #F7F7F6;\" class=\"mp-Listing mp-Listing--list-item\">
\t\t\t\t\t\t<a href=\"";
                    // line 178
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["product"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["product"], "title", array()))))));
                    echo "\" class=\"mp-Listing-coverLink\">
\t\t\t\t\t\t\t<figure class=\"mp-Listing-image-container\">
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-image-item mp-Listing-image-item--main\">
\t\t\t\t\t\t\t\t\t<img title=\"";
                    // line 181
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array()), "html", null, true);
                    echo "\" src=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "getPhoto", array(), "method"), "html", null, true);
                    echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                    // line 183
                    if (($this->getAttribute($context["product"], "payment_type_id", array()) == "1")) {
                        echo " <p class=\"card-escrow\">Escrow</p> ";
                    } elseif (($this->getAttribute($context["product"], "payment_type_id", array()) == 4)) {
                        echo " <p class=\"card-escrow\">Multisig 2/3</p>";
                    } elseif (($this->getAttribute($context["product"], "payment_type_id", array()) == 2)) {
                        echo " <p class=\"card-fe\">";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_no_escrow")), "html", null, true);
                        echo "</p> ";
                    }
                    // line 184
                    echo "\t\t\t\t\t\t\t</figure>
\t\t\t\t\t\t\t<div class=\"mp-Listing-group\">
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--title-description-attributes\">
\t\t\t\t\t\t\t\t\t<h3 class=\"mp-Listing-title\">";
                    // line 187
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array()), "html", null, true);
                    echo "</h3>
\t\t\t\t\t\t\t\t\t<p class=\"mp-Listing-description mp-text-paragraph\">";
                    // line 188
                    echo twig_escape_filter($this->env, (twig_slice($this->env, $this->getAttribute($context["product"], "description", array()), 0, 120) . nl2br(strip_tags(call_user_func_array($this->env->getFilter('xss_clean')->getCallable(), array(call_user_func_array($this->env->getFilter('bbc2html')->getCallable(), array(twig_convert_encoding("...", "UTF-8", "HTML-ENTITIES"))))), "<b>,<i>,<u>,<ul>,<li>,<span>,<h1>,<p><h2></h3>"))), "html", null, true);
                    echo "</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--price-date-feature\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-price mp-text-price-label\">";
                    // line 191
                    echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["product"], "price", array()), $this->getAttribute($context["product"], "currency", array())), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-date mp-Listing-date--desktop\">";
                    // line 192
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "created_at", array()), "format", array(0 => "d-m-Y"), "method"), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--mobile-bottom-row\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-location\">";
                    // line 195
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "shipped_from", array()), "html", null, true);
                    echo "&#10230;";
                    echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["product"], "countryNames", array(), "method"), 0, 24), "html", null, true);
                    echo "<br></span>
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-date mp-bottom-right\">";
                    // line 197
                    echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["product"], "price", array()), $this->getAttribute($context["product"], "currency", array())), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                    echo ",";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "created_at", array()), "format", array(0 => "d-m-Y"), "method"), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t <div class=\"mp-Listing--sellerInfo\">
                                <span class=\"mp-Listing-seller-name\"><a href=\"/profile/";
                    // line 202
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "user", array()), "username", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "user", array()), "username", array()), "html", null, true);
                    echo "</br>(";
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ((($this->getAttribute($this->getAttribute($context["product"], "user", array()), "averageRate", array(), "method") == 0)) ? ("5.0") : ($this->getAttribute($this->getAttribute($context["product"], "user", array()), "averageRate", array(), "method"))), 2), "html", null, true);
                    echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5 products\"><i></i></span>)</a></span>
                                <span class=\"mp-Listing-location\">";
                    // line 203
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "shipped_from", array()), "html", null, true);
                    echo "&#10230;";
                    echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["product"], "countryNames", array(), "method"), 0, 24), "html", null, true);
                    echo "<br>";
                    echo ((($this->getAttribute($context["product"], "priority_until", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) ? ("<b>Ads</b>") : (""));
                    echo "</span>
                                <span class=\"mp-Listing-seller-link\">";
                    // line 204
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_views")), "html", null, true);
                    echo ": ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "views_count", array()), "html", null, true);
                    echo "<br>";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
                    echo ": ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "orders", array()), "count", array()), "html", null, true);
                    echo "</span>
                        </div>
\t\t\t\t\t</li>
\t\t\t\t\t";
                    // line 207
                    if (($this->getAttribute($context["product"], "bold_until", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                        // line 208
                        echo "\t\t\t\t\t<li class=\"mp-Listing mp-Listing--other-seller\">
                                <div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--left mp-text-paragraph\">";
                        // line 209
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_also_from")), "html", null, true);
                        echo "</div>
                                <div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--center\">
\t\t\t\t\t\t\t\t  ";
                        // line 211
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute($context["product"], "user", array()), "listings", array()), "slice", array(0 => 0, 1 => 3), "method"));
                        foreach ($context['_seq'] as $context["_key"] => $context["adslisted"]) {
                            // line 212
                            echo "                                    <a href=\"";
                            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["adslisted"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["adslisted"], "title", array()))))));
                            echo "\" class=\"mp-Listing-other-seller-items ";
                            echo ((($this->getAttribute($this->getAttribute($this->getAttribute($context["product"], "user", array()), "listings", array()), 0, array(), "array") == $context["adslisted"])) ? ("mp-Listing-other-seller-items--default") : (""));
                            echo "\">
                                        <div class=\"mp-Listing-other-seller-image-container\"><img src=\"";
                            // line 213
                            echo twig_escape_filter($this->env, $this->getAttribute($context["adslisted"], "photo", array()), "html", null, true);
                            echo "\"></div>
                                        <div class=\"mp-Listing-other-seller-info-container\">
                                            <h3 class=\"mp-TextLink\">";
                            // line 215
                            echo twig_escape_filter($this->env, $this->getAttribute($context["adslisted"], "title", array()), "html", null, true);
                            echo "</h3>
                                            <div class=\"mp-text-price-label\">";
                            // line 216
                            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["adslisted"], "price", array()), $this->getAttribute($context["adslisted"], "currency", array())), "html", null, true);
                            echo " ";
                            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                            echo "</div>
                                        </div>
                                    </a>
\t\t\t\t\t\t\t\t  ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['adslisted'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 220
                        echo "                                </div>
                                <div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--right\">
\t\t\t\t\t\t\t\t<a class=\"mp-TextLink\"  href=\"/profile/";
                        // line 222
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "user", array()), "username", array()), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_view_all")), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["product"], "user", array()), "listings", array()), "count", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_listings")), "html", null, true);
                        echo "<span class=\"mp-Icon mp-svg-arrow-right-blue\"></span>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
                    </li>\t
\t\t\t\t\t";
                    }
                    // line 226
                    echo "\t
\t\t\t\t\t";
                }
                // line 228
                echo "\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 229
            echo "\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_shuffle_filter(($context["listings"] ?? null)));
            foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
                // line 230
                echo "\t\t\t\t";
                if ( !$this->getAttribute($context["product"], "getAdsListing", array(), "method")) {
                    // line 231
                    echo "\t\t\t\t\t<li class=\"mp-Listing mp-Listing--list-item\">
\t\t\t\t\t\t<a href=\"";
                    // line 232
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["product"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["product"], "title", array()))))));
                    echo "\" class=\"mp-Listing-coverLink\">
\t\t\t\t\t\t\t<figure class=\"mp-Listing-image-container\">
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-image-item mp-Listing-image-item--main\">
\t\t\t\t\t\t\t\t\t<img title=\"";
                    // line 235
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array()), "html", null, true);
                    echo "\" src=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "getPhoto", array(), "method"), "html", null, true);
                    echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
                    // line 237
                    if (($this->getAttribute($context["product"], "payment_type_id", array()) == "1")) {
                        echo " <p class=\"card-escrow\">Escrow</p> ";
                    } elseif (($this->getAttribute($context["product"], "payment_type_id", array()) == 4)) {
                        echo " <p class=\"card-escrow\">Multisig 2/3</p>";
                    } elseif (($this->getAttribute($context["product"], "payment_type_id", array()) == 2)) {
                        echo " <p class=\"card-fe\">";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_no_escrow")), "html", null, true);
                        echo "</p> ";
                    }
                    // line 238
                    echo "\t\t\t\t\t\t\t</figure>
\t\t\t\t\t\t\t<div class=\"mp-Listing-group\">
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--title-description-attributes\">
\t\t\t\t\t\t\t\t\t<h3 class=\"mp-Listing-title\">";
                    // line 241
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array()), "html", null, true);
                    echo "</h3>
\t\t\t\t\t\t\t\t\t<p class=\"mp-Listing-description mp-text-paragraph\">";
                    // line 242
                    echo twig_escape_filter($this->env, (twig_slice($this->env, $this->getAttribute($context["product"], "description", array()), 0, 120) . nl2br(strip_tags(call_user_func_array($this->env->getFilter('xss_clean')->getCallable(), array(call_user_func_array($this->env->getFilter('bbc2html')->getCallable(), array(twig_convert_encoding("...", "UTF-8", "HTML-ENTITIES"))))), "<b>,<i>,<u>,<ul>,<li>,<span>,<h1>,<p><h2><h3>"))), "html", null, true);
                    echo "</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--price-date-feature\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-price mp-text-price-label\">";
                    // line 245
                    echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["product"], "price", array()), $this->getAttribute($context["product"], "currency", array())), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-date mp-Listing-date--desktop\">";
                    // line 246
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "created_at", array()), "format", array(0 => "d-m-Y"), "method"), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"mp-Listing-group--mobile-bottom-row\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-location\">";
                    // line 249
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "shipped_from", array()), "html", null, true);
                    echo "&#10230;";
                    echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["product"], "countryNames", array(), "method"), 0, 24), "html", null, true);
                    echo "<br></span>
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-date mp-bottom-right\">";
                    // line 251
                    echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["product"], "price", array()), $this->getAttribute($context["product"], "currency", array())), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                    echo ",";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "created_at", array()), "format", array(0 => "d-m-Y"), "method"), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t <div class=\"mp-Listing--sellerInfo\">
                                <span class=\"mp-Listing-seller-name\"><a href=\"/profile/";
                    // line 256
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "user", array()), "username", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "user", array()), "username", array()), "html", null, true);
                    echo "</br>(";
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ((($this->getAttribute($this->getAttribute($context["product"], "user", array()), "averageRate", array(), "method") == 0)) ? ("5.0") : ($this->getAttribute($this->getAttribute($context["product"], "user", array()), "averageRate", array(), "method"))), 2), "html", null, true);
                    echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5 products\"><i></i></span>)</a></span>
                                <span class=\"mp-Listing-location\">";
                    // line 257
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "shipped_from", array()), "html", null, true);
                    echo "&#10230;";
                    echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["product"], "countryNames", array(), "method"), 0, 24), "html", null, true);
                    echo "<br></span>
                                <span class=\"mp-Listing-seller-link\">";
                    // line 258
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_views")), "html", null, true);
                    echo ": ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "views_count", array()), "html", null, true);
                    echo "<br>";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
                    echo ": ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "orders", array()), "count", array()), "html", null, true);
                    echo "</span>
                        </div>
\t\t\t\t\t</li>
\t\t\t\t\t";
                    // line 261
                    if (($this->getAttribute($context["product"], "bold_until", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                        // line 262
                        echo "\t\t\t\t\t<li class=\"mp-Listing mp-Listing--other-seller\">
                                <div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--left mp-text-paragraph\">";
                        // line 263
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_also_from")), "html", null, true);
                        echo "</div>
                                <div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--center\">
\t\t\t\t\t\t\t\t  ";
                        // line 265
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($context["product"], "childs", array()), "slice", array(0 => 0, 1 => 3), "method"));
                        foreach ($context['_seq'] as $context["_key"] => $context["adslisted"]) {
                            // line 266
                            echo "                                    <a href=\"";
                            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["adslisted"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["adslisted"], "title", array()))))));
                            echo "\" class=\"mp-Listing-other-seller-items ";
                            echo ((($this->getAttribute($this->getAttribute($this->getAttribute($context["product"], "childs", array()), "listings", array()), 0, array(), "array") == $context["adslisted"])) ? ("mp-Listing-other-seller-items--default") : (""));
                            echo "\">
                                        <div class=\"mp-Listing-other-seller-image-container\"><img src=\"";
                            // line 267
                            echo twig_escape_filter($this->env, $this->getAttribute($context["adslisted"], "photo", array()), "html", null, true);
                            echo "\"></div>
                                        <div class=\"mp-Listing-other-seller-info-container\">
                                            <h3 class=\"mp-TextLink\">";
                            // line 269
                            echo twig_escape_filter($this->env, $this->getAttribute($context["adslisted"], "title", array()), "html", null, true);
                            echo "</h3>
                                            <div class=\"mp-text-price-label\">";
                            // line 270
                            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["adslisted"], "price", array()), $this->getAttribute($context["adslisted"], "currency", array())), "html", null, true);
                            echo " ";
                            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                            echo "</div>
                                        </div>
                                    </a>
\t\t\t\t\t\t\t\t  ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['adslisted'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 274
                        echo "                                </div>
                                <div class=\"mp-Listing-other-seller-content mp-Listing-other-seller-content--right\">
\t\t\t\t\t\t\t\t<a class=\"mp-TextLink\"  href=\"/profile/";
                        // line 276
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["product"], "user", array()), "username", array()), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_view_all")), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["product"], "user", array()), "listings", array()), "count", array()), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_listings")), "html", null, true);
                        echo "<span class=\"mp-Icon mp-svg-arrow-right-blue\"></span>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
                    </li>\t
\t\t\t\t\t";
                    }
                    // line 280
                    echo "\t
\t\t\t\t";
                }
                // line 281
                echo "\t
\t\t\t  ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 283
            echo "\t\t\t\t";
        } else {
            // line 284
            echo "\t\t\t\t\t<p>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.carts_no_products")), "html", null, true);
            echo "</p>
\t\t\t\t";
        }
        // line 286
        echo "\t\t\t</ul>
\t\t<div class=\"mp-PaginationControls\">
                    ";
        // line 288
        echo $this->getAttribute($this->getAttribute(($context["listings"] ?? null), "appends", array(0 => $this->getAttribute(call_user_func_array($this->env->getFunction('app')->getCallable(), array("request")), "except", array(0 => "product"), "method")), "method"), "links", array());
        echo "
        </div>
\t\t</div>
\t</div>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/category/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  902 => 288,  898 => 286,  892 => 284,  889 => 283,  882 => 281,  878 => 280,  864 => 276,  860 => 274,  848 => 270,  844 => 269,  839 => 267,  832 => 266,  828 => 265,  823 => 263,  820 => 262,  818 => 261,  806 => 258,  800 => 257,  792 => 256,  780 => 251,  773 => 249,  767 => 246,  761 => 245,  755 => 242,  751 => 241,  746 => 238,  736 => 237,  729 => 235,  723 => 232,  720 => 231,  717 => 230,  712 => 229,  706 => 228,  702 => 226,  688 => 222,  684 => 220,  672 => 216,  668 => 215,  663 => 213,  656 => 212,  652 => 211,  647 => 209,  644 => 208,  642 => 207,  630 => 204,  622 => 203,  614 => 202,  602 => 197,  595 => 195,  589 => 192,  583 => 191,  577 => 188,  573 => 187,  568 => 184,  558 => 183,  551 => 181,  545 => 178,  542 => 177,  539 => 176,  534 => 175,  532 => 174,  521 => 166,  512 => 162,  506 => 161,  500 => 160,  494 => 159,  488 => 156,  479 => 152,  473 => 151,  467 => 148,  459 => 145,  455 => 144,  446 => 137,  440 => 136,  430 => 134,  426 => 132,  420 => 131,  410 => 129,  406 => 127,  393 => 125,  389 => 124,  384 => 123,  381 => 122,  377 => 121,  372 => 120,  369 => 119,  365 => 118,  359 => 115,  350 => 111,  344 => 110,  335 => 103,  329 => 102,  319 => 100,  316 => 99,  312 => 98,  308 => 96,  302 => 95,  292 => 93,  289 => 92,  285 => 91,  278 => 87,  272 => 83,  266 => 82,  256 => 80,  253 => 79,  249 => 78,  245 => 76,  239 => 75,  229 => 73,  226 => 72,  222 => 71,  215 => 67,  208 => 63,  203 => 61,  194 => 54,  188 => 53,  185 => 52,  182 => 51,  176 => 50,  173 => 49,  160 => 46,  157 => 45,  152 => 44,  150 => 43,  141 => 41,  136 => 40,  131 => 39,  129 => 38,  119 => 35,  116 => 34,  113 => 33,  109 => 32,  102 => 28,  91 => 21,  86 => 20,  81 => 19,  75 => 18,  68 => 17,  57 => 15,  53 => 14,  48 => 12,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/category/index.twig", "");
    }
}
