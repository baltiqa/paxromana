<?php

/* profile.head-profile.twig */
class __TwigTemplate_7ac3fec6e1841c6035a642c571ba6a7cc92735d7cf578d8572c0a050d565c33c extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<section class=\"l-main-top\">
\t\t\t\t<div class=\"profile-head mp-Card\">
\t\t\t\t\t<div class=\"profile-head-backdrop mp-Card-block mp-Card-block--padded-no\" style=\"padding-bottom: 36.73469387755102%\">
\t\t\t\t\t\t<div class=\"profile-head-backdrop-stretchy\" style=\"background-image: url('";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "getAvatarBackground", array(), "method"), "html", null, true);
        echo "');\">
\t\t\t\t\t\t\t<div class=\"profile-head-image\">
\t\t\t\t\t\t\t\t<img src=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "getAvatar", array(), "method"), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"profile-head-title\">
\t\t\t\t\t\t\t\t";
        // line 9
        if (($this->getAttribute(($context["profile"] ?? null), "is_admin", array()) == 1)) {
            // line 10
            echo "\t\t\t\t\t\t\t\t\t<button class=\"profile-head-title-name mp-Button mp-Button--black mp-Button--sm \" title=\"";
            echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "display_name", array()) != null)) ? ($this->getAttribute(($context["profile"] ?? null), "display_name", array())) : ($this->getAttribute(($context["profile"] ?? null), "username", array()))), "html", null, true);
            echo "\" disabled>";
            if ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "is_admin", array()) == 1) && ($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()) == $this->getAttribute(($context["profile"] ?? null), "username", array())))) {
                echo " <a style=\"text-decoration: none;color:white;\" href=\"/panel\">";
                echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "display_name", array()) != null)) ? ($this->getAttribute(($context["profile"] ?? null), "display_name", array())) : ($this->getAttribute(($context["profile"] ?? null), "username", array()))), "html", null, true);
                echo "</a>  ";
            } else {
                echo " ";
                echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "display_name", array()) != null)) ? ($this->getAttribute(($context["profile"] ?? null), "display_name", array())) : ($this->getAttribute(($context["profile"] ?? null), "username", array()))), "html", null, true);
                echo " ";
            }
            echo "</button><br>
\t\t\t\t\t\t\t\t\t\t<button class=\"button mp-Button mp-Button--dangerous mp-Button--sm\" title=\"";
            // line 11
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rank1")), "html", null, true);
            echo " - Pax Romana\" disabled>
\t\t\t\t\t\t\t\t\t\t\tRoman ";
            // line 12
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rank1")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 14
($context["profile"] ?? null), "is_mod", array()) == 1)) {
            // line 15
            echo "\t\t\t\t\t\t\t\t\t<button class=\"profile-head-title-name mp-Button mp-Button--black mp-Button--sm \" title=\"";
            echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "display_name", array()) != null)) ? ($this->getAttribute(($context["profile"] ?? null), "display_name", array())) : ($this->getAttribute(($context["profile"] ?? null), "username", array()))), "html", null, true);
            echo "\" disabled>";
            if ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "is_mod", array()) == 1) && ($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()) == $this->getAttribute(($context["profile"] ?? null), "username", array())))) {
                echo " <a style=\"text-decoration: none;color:white;\" href=\"/panel\">";
                echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "display_name", array()) != null)) ? ($this->getAttribute(($context["profile"] ?? null), "display_name", array())) : ($this->getAttribute(($context["profile"] ?? null), "username", array()))), "html", null, true);
                echo "</a>  ";
            } else {
                echo " ";
                echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "display_name", array()) != null)) ? ($this->getAttribute(($context["profile"] ?? null), "display_name", array())) : ($this->getAttribute(($context["profile"] ?? null), "username", array()))), "html", null, true);
                echo " ";
            }
            echo "</button><br>
\t\t\t\t\t\t\t\t\t\t<button class=\"button mp-Button mp-Button--mod mp-Button--sm\" title=\"";
            // line 16
            echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "is_headmod", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rank2"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rank3")))), "html", null, true);
            echo " - Pax Romana\" disabled>
\t\t\t\t\t\t\t\t\t\t\t";
            // line 17
            echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "is_headmod", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rank2"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rank3")))), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t";
        } else {
            // line 20
            echo "\t\t\t\t\t\t\t\t\t<button class=\"profile-head-title-name mp-Button mp-Button--black mp-Button--sm\" title=\"";
            echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "display_name", array()) != null)) ? ($this->getAttribute(($context["profile"] ?? null), "display_name", array())) : ($this->getAttribute(($context["profile"] ?? null), "username", array()))), "html", null, true);
            echo "\" disabled>";
            echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "display_name", array()) != null)) ? ($this->getAttribute(($context["profile"] ?? null), "display_name", array())) : ($this->getAttribute(($context["profile"] ?? null), "username", array()))), "html", null, true);
            echo " (";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["profile"] ?? null), "orders", array()), "count", array()), "html", null, true);
            echo ") ";
            if (($this->getAttribute(($context["profile"] ?? null), "trader_type", array()) == "individual")) {
                echo "(";
                echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "averageRate", array(), "method") == 0)) ? ("5.00") : (twig_number_format_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "averageRate", array(), "method"), 2))), "html", null, true);
                echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\"><i></i></span>)";
            }
            echo "</button><br>
\t\t\t\t\t\t\t\t\t\t";
            // line 21
            if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array()) != $this->getAttribute(($context["profile"] ?? null), "id", array()))) {
                // line 22
                echo "\t\t\t\t\t\t\t\t\t\t\t<button id=\"report-seller-button\" class=\"button mp-Button mp-Button--secondary mp-Button--sm\" title=\"";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_seller")), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"#report\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-alert-blue\"></span>";
                // line 24
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report")), "html", null, true);
                echo "  ";
                echo twig_escape_filter($this->env, ((($this->getAttribute(($context["profile"] ?? null), "trader_type", array()) == "individual")) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_seller"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")))), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
                // line 26
                if ($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "isBlocked", array(0 => ($context["profile"] ?? null)), "method")) {
                    // line 27
                    echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("profile.unblock", $this->getAttribute(($context["profile"] ?? null), "username", array())));
                    echo "\" class=\"button mp-Button mp-Button--secondary mp-Button--sm\" title=\"";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block")), "html", null, true);
                    echo "\">
\t\t\t\t\t\t\t\t\t\t";
                    // line 28
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 31
                    echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("profile.block", $this->getAttribute(($context["profile"] ?? null), "username", array())));
                    echo "\" class=\"button mp-Button mp-Button--secondary mp-Button--sm\" title=\"";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_unblock")), "html", null, true);
                    echo "\">
\t\t\t\t\t\t\t\t\t\t";
                    // line 32
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_unblock")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 35
                echo "\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 37
            echo "\t\t\t\t\t\t\t\t\t\t";
            if (($this->getAttribute(($context["profile"] ?? null), "trader_type", array()) == "individual")) {
                // line 38
                echo "\t\t\t\t\t\t\t\t\t\t<button style=\"background-color:#eda566\" class=\"button mp-Button mp-Button--primary mp-Button--sm\" title=\"";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_seller")), "html", null, true);
                echo " \" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 39
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_seller")), "html", null, true);
                echo " 
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
                // line 41
                if ($this->getAttribute(($context["profile"] ?? null), "has_fe", array())) {
                    // line 42
                    echo "\t\t\t\t\t\t\t\t\t\t\t<button style=\"color:black;background-color:orange;\" class=\"button mp-Button mp-Button--primary mp-Button--sm\" title=\"100% FE Rights\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t100% FE Rights
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 46
                    echo "\t\t\t\t\t\t\t\t\t\t\t<button style=\"color:black;\" class=\"button mp-Button mp-Button--primary mp-Button--sm\" title=\"100% Escrow Rights\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t100% Escrow Rights
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 50
                echo "\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t";
                // line 51
                if (($this->getAttribute(($context["profile"] ?? null), "on_vacation", array()) == 1)) {
                    // line 52
                    echo "\t\t\t\t\t\t\t\t\t\t\t<button style=\"background-color:#eda566\" class=\"button mp-Button mp-Button--primary mp-Button--sm\" title=\"";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vacation")), "html", null, true);
                    echo " \" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 53
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vacation")), "html", null, true);
                    echo " 
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 56
                echo "\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 57
                echo "\t\t\t\t\t\t\t\t\t\t<button style=\"background-color:#eda566\" class=\"button mp-Button mp-Button--primary mp-Button--sm\" title=\"";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")), "html", null, true);
                echo " \" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 58
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")), "html", null, true);
                echo " 
\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 61
            echo "

\t\t\t\t\t\t\t\t\t\t";
            // line 63
            if (($this->getAttribute(($context["profile"] ?? null), "banned_at", array()) != null)) {
                // line 64
                echo "\t\t\t\t\t\t\t\t\t\t\t<button class=\"button mp-Button mp-Button--dangerous mp-Button--sm\" title=\"";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_banned")), "html", null, true);
                echo "\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 65
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_banned")), "html", null, true);
                echo " 
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 68
            echo "\t\t\t\t\t\t\t\t";
        }
        // line 69
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"profile-head-info mp-Card-block mp-Card-block--custom-padleft\">
\t\t\t\t\t\t<div class=\"user-reviews-placeholder hidden\"></div>
\t\t\t\t\t\t<div class=\"profile-head-info-item\">
\t\t\t\t\t\t\t<b>";
        // line 75
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["profile"] ?? null), "created_at", array()), "diffForHumans", array(0 => null, 1 => true), "method"), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t";
        // line 76
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_activelong")), "html", null, true);
        echo " Romana&nbsp;&nbsp;&nbsp;&nbsp; 
\t\t\t\t\t\t\t";
        // line 77
        if ((($this->getAttribute(($context["profile"] ?? null), "is_admin", array()) == 1) || ($this->getAttribute(($context["profile"] ?? null), "is_mod", array()) == 1))) {
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_lastactive")), "html", null, true);
            echo " 
\t\t\t\t\t\t\t\t<b>N/A</b>
\t\t\t\t\t\t\t\t";
        } else {
            // line 79
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_lastactive")), "html", null, true);
            echo " 
\t\t\t\t\t\t\t\t<b>";
            // line 80
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "last_login_at", array()), "d M Y"), "html", null, true);
            echo "</b>
\t\t\t\t\t\t\t";
        }
        // line 82
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        // line 83
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array()) != $this->getAttribute(($context["profile"] ?? null), "id", array()))) {
            // line 84
            echo "\t\t\t\t\t\t<div class=\"save-seller-button\">
\t\t\t\t\t\t\t<div id=\"save-seller\">
\t\t\t\t\t\t\t\t<form id=\"save-seller-form\" action=\"";
            // line 86
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("profile.follow", $this->getAttribute(($context["profile"] ?? null), "username", array())));
            echo "\">
\t\t\t\t\t\t\t\t\t<button id=\"save-seller-button\" class=\"button mp-Button mp-Button--secondary mp-Button--sm\" title=\"";
            // line 87
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_follow")), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t";
            // line 88
            if ($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "getIsFollowed", array(0 => ($context["profile"] ?? null)), "method")) {
                // line 89
                echo "\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon mp-svg-following\"></span>&nbsp;&nbsp;&nbsp;";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_unfollow")), "html", null, true);
                echo " 
\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 91
                echo "\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon mp-svg-follow\"></span>&nbsp;&nbsp;&nbsp;";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_follow")), "html", null, true);
                echo " 
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 93
            echo "\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 98
        echo "


\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"mp-Card-block mp-Card-block--custom-padtop\">
\t\t\t\t\t\t<div class=\"mp-Tab-bar profile-head-tab\">
\t\t\t\t\t\t\t<a class=\"mp-Tab ";
        // line 104
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 1)) ? ("mp-Tab--selected") : (""));
        echo "\" href=\"/profile/";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "username", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab1")), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t";
        // line 105
        if (((($this->getAttribute(($context["profile"] ?? null), "is_admin", array()) != 1) && ($this->getAttribute(($context["profile"] ?? null), "is_mod", array()) != 1)) && ($this->getAttribute(($context["profile"] ?? null), "trader_type", array()) == "individual"))) {
            // line 106
            echo "\t\t\t\t\t\t\t\t<a class=\"mp-Tab ";
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 2)) ? ("mp-Tab--selected") : (""));
            echo "\" href=\"/profile/";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "username", array()), "html", null, true);
            echo "/store\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab2")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t<a class=\"mp-Tab ";
            // line 107
            echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "sub_id"), "method") == 3)) ? ("mp-Tab--selected") : (""));
            echo "\" href=\"/profile/";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "username", array()), "html", null, true);
            echo "/ratings\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab3")), "html", null, true);
            echo "(";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "count_reviews", array(), "method"), "html", null, true);
            echo ")</a>
\t\t\t\t\t\t\t";
        }
        // line 109
        echo "\t\t\t\t\t\t\t";
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array()) != $this->getAttribute(($context["profile"] ?? null), "id", array()))) {
            // line 110
            echo "\t\t\t\t\t\t\t\t<a class=\"mp-Tab \" href=\"/profile/";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["profile"] ?? null), "username", array()), "html", null, true);
            echo "/sendmessage\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab4")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t";
        }
        // line 112
        echo "\t\t\t\t\t\t\t";
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array()) == $this->getAttribute(($context["profile"] ?? null), "id", array()))) {
            // line 113
            echo "\t\t\t\t\t\t\t\t<a class=\"mp-Tab\" href=\"/account/edit_profile/me\"><span class=\"mp-Icon mp-svg-pencil\"></span>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab5")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t";
        }
        // line 115
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</section>
\t\t\t";
        // line 119
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 120
            echo "\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t<div>
\t\t\t\t";
            // line 123
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method");
            echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t\t";
        }
        // line 127
        echo "
\t\t\t<div id=\"report\" class=\"message\">
\t\t\t\t\t\t<div class=\"popup\">
\t\t\t\t\t\t\t<div class=\"message-box-header\">
\t\t\t\t\t\t\t";
        // line 131
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_title")), "html", null, true);
        echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<a class=\"close\" href=\"#\">&times;</a>
\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t\t";
        // line 135
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 136
            echo "\t\t\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t";
            // line 139
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
        }
        // line 143
        echo "\t\t\t\t\t\t\t\t";
        if ( !$this->getAttribute(($context["profile"] ?? null), "ifReportIsDone", array(0 => call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array())), "method")) {
            // line 144
            echo "\t\t\t\t\t\t\t\t\t<p>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_text")), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t\t<form action=\"";
            // line 145
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("profile.report", array(0 => $this->getAttribute(($context["profile"] ?? null), "username", array()))));
            echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t";
            // line 146
            echo csrf_field();
            echo "

\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<label>";
            // line 149
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_reason")), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t\t\t\t\t<input style=\"width:100%;height:80px;\" id=\"reason\" type=\"text\" placeholder=\"";
            // line 150
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_reason")), "html", null, true);
            echo "\" name=\"reason\" class=\"mp-Input ";
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "reason"), "method")) ? (" invalid") : (""));
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<label>";
            // line 154
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_extra")), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t\t\t\t\t<input style=\"width:100%;height:80px;\" id=\"notes\" type=\"text\" placeholder=\"";
            // line 155
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_notes")), "html", null, true);
            echo "\" name=\"notes\" class=\"mp-Input ";
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "notes"), "method")) ? (" invalid") : (""));
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<img src=\"/captcha.html\"/>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"mp-Form-controlGroup-label optional-label\" for=\"captcha\">Captcha</label>
\t\t\t\t\t\t\t\t\t\t\t<input style=\"width:50%;\" id=\"captcha\" type=\"text\" placeholder=\"captcha\" name=\"captcha\" class=\"mp-Input ";
            // line 161
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
            echo "\" tabindex=\"2\">
\t\t\t\t\t\t\t\t\t\t\t";
            // line 162
            if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) {
                // line 163
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 164
                echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "captcha"), "method"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 167
            echo "\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"content-footer\">
\t\t\t\t\t\t\t\t\t\t<div class=\"buttonbar\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"submit\" class=\"mp-Button mp-Button--primary\" value=\"";
            // line 170
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_sent")), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t";
        } else {
            // line 175
            echo "\t\t\t\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t";
            // line 178
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_report_received")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
        }
        // line 182
        echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
";
    }

    public function getTemplateName()
    {
        return "profile.head-profile.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  488 => 182,  481 => 178,  476 => 175,  468 => 170,  463 => 167,  457 => 164,  454 => 163,  452 => 162,  448 => 161,  437 => 155,  433 => 154,  424 => 150,  420 => 149,  414 => 146,  410 => 145,  405 => 144,  402 => 143,  395 => 139,  390 => 136,  388 => 135,  381 => 131,  375 => 127,  368 => 123,  363 => 120,  361 => 119,  355 => 115,  349 => 113,  346 => 112,  338 => 110,  335 => 109,  324 => 107,  315 => 106,  313 => 105,  305 => 104,  297 => 98,  290 => 93,  284 => 91,  278 => 89,  276 => 88,  272 => 87,  268 => 86,  264 => 84,  262 => 83,  259 => 82,  254 => 80,  250 => 79,  243 => 77,  239 => 76,  235 => 75,  227 => 69,  224 => 68,  218 => 65,  213 => 64,  211 => 63,  207 => 61,  201 => 58,  196 => 57,  193 => 56,  187 => 53,  182 => 52,  180 => 51,  177 => 50,  171 => 46,  165 => 42,  163 => 41,  158 => 39,  153 => 38,  150 => 37,  146 => 35,  140 => 32,  133 => 31,  127 => 28,  120 => 27,  118 => 26,  111 => 24,  105 => 22,  103 => 21,  88 => 20,  82 => 17,  78 => 16,  63 => 15,  61 => 14,  56 => 12,  52 => 11,  37 => 10,  35 => 9,  29 => 6,  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "profile.head-profile.twig", "");
    }
}
