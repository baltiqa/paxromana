<?php

/* /var/www/html/html/resources/themes/default/create/edit.twig */
class __TwigTemplate_61218ec5f9f2e6f88440f2295fae39cc667b96e7c365a5bf671e6d844245d867 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/create/edit.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/place_ads.css\" rel=\"stylesheet\">
\t<link href=\"/web/css/extra.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div class=\"l-page\" style=\"padding-top: 50px;\">
\t\t\t<section>
\t\t\t\t<h1 class=\"pull-left page-header\">";
        // line 11
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_edit_title")), "html", null, true);
        echo " #";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "id", array()), "html", null, true);
        echo "</h1>
\t\t\t\t<h2 class=\"pull-right\">
\t\t\t\t\t<a class=\"text-info\" href=\"";
        // line 13
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.listings.index"));
        echo "\">
\t\t\t\t\t\t<strong>← ";
        // line 14
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_back_to_overview")), "html", null, true);
        echo "</strong>
\t\t\t\t\t</a>
\t\t\t\t</h2>
\t\t\t\t<div class=\"clearboth\"></div>
\t\t\t\t";
        // line 18
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 19
            echo "\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t";
            // line 22
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method");
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 26
        echo "\t\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 27
            echo "\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t";
            // line 30
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method");
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 34
        echo "\t\t\t\t<form id=\"syi-form\" method=\"post\" action=\"";
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.update", ($context["listing"] ?? null)));
        echo "\" accept-charset=\"UTF-8\" enctype=\"multipart/form-data\">
\t\t\t\t\t";
        // line 35
        echo csrf_field();
        echo "
\t\t\t\t\t<div class=\"box box-stacked\">
\t\t\t\t\t\t<div class=\"box-content\">

\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_parent")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 42
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_parent_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t";
        // line 45
        if (($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "childs", array()), "count", array(), "method") == 0)) {
            // line 46
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t\t<select class=\"form-control ";
            // line 47
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "parent"), "method")) ? (" invalid") : (""));
            echo "\" id=\"parent\" name=\"parent\">
\t\t\t\t\t\t\t\t\t\t\t<option value=\"nope\">";
            // line 48
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_parent_no")), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 49
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["own_listing"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["own"]) {
                // line 50
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["own"], "id", array()), "html", null, true);
                echo "\" ";
                echo ((($this->getAttribute($context["own"], "id", array()) == $this->getAttribute(($context["listing"] ?? null), "parent_id", array()))) ? ("selected=selected") : (""));
                echo ">";
                echo ((($this->getAttribute($context["own"], "id", array()) == $this->getAttribute(($context["listing"] ?? null), "parent_id", array()))) ? ("[PARENT]") : (""));
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t#";
                // line 51
                echo twig_escape_filter($this->env, $this->getAttribute($context["own"], "id", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 52
                echo twig_escape_filter($this->env, $this->getAttribute($context["own"], "title", array()), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['own'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 54
            echo "\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 57
            echo "\t\t\t\t\t\t\t\t\t\t<b>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_parent_has_child", array("childcount" => $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "childs", array()), "count", array())))), "html", null, true);
            echo "</b>
\t\t\t\t\t\t\t\t\t";
        }
        // line 59
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 64
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_title")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 65
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_title_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"title\" id=\"title\" class=\"mp-Input ";
        // line 68
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "title"), "method")) ? (" invalid") : (""));
        echo "\" value=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 73
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_description")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 74
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_description_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<textarea class=\"mp-Textarea ";
        // line 77
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "description"), "method")) ? (" invalid") : (""));
        echo "\" id=\"description\" name=\"description\" maxlength=\"\" data-maxlength=\"\" placeholder=\"\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "description", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t\t\t\t<input id=\"message-box\" type=\"checkbox\">
\t\t\t\t\t\t\t\t</br>
\t\t\t\t\t\t\t</br>
\t\t\t\t\t\t\t<label for=\"message-box\" class=\"mp-Button mp-Button--primary mp-Button--xs \">Romana ";
        // line 81
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<div class=\"message\">
\t\t\t\t\t\t\t\t<div class=\"popup\">
\t\t\t\t\t\t\t\t\t<div class=\"message-box-header\">
\t\t\t\t\t\t\t\t\t\tRomana ";
        // line 85
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t<label for=\"message-box\" class=\"close\">
\t\t\t\t\t\t\t\t\t\t\t<span>×</span>
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<table style=\"width:100%;\">
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>";
        // line 94
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes1")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th></th>
\t\t\t\t\t\t\t\t\t\t\t\t\t<th>";
        // line 96
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes2")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[h1]Romana[/h1]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><h1>Romana</h1></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[h2]Romana[/h2]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><h2>Romana</h2></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[h3]Romana[/h3]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><h3>Romana</h3></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[b]Romana[/b]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><b>Romana</b></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[i]Romana[/i]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><i>Romana</i></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[u]Romana[/u]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><u>Romana</u></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[li]Romana[/li]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><li style=\"list-style: square;\">Romana</li></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[color=red]Romana[/color]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><span style=\"color:red;\">Romana</spanspan></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[color=white]Romana[/color]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><span style=\"color:white;\">Romana</spanspan></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td>[color=blue]Romana[/color]</td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t\t\t\t\t\t\t\t<td><span style=\"color:blue;\">Romana</spanspan></td>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t</table><br>
\t\t\t\t\t\t\t\t\t\t\t<b>";
        // line 149
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes_request")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"content-footer\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<label for=\"message-box\" class=\"mp-Button mp-Button--primary mp-Button--xs\">";
        // line 154
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_bbcodes_close")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>


\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<label for=\"title\">";
        // line 165
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_tags")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 166
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_tags_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<textarea class=\"mp-Textarea ";
        // line 169
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "tags"), "method")) ? (" invalid") : (""));
        echo "\" id=\"tags\" name=\"tags\" maxlength=\"\" placeholder=\"\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "tags", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<label for=\"title\">";
        // line 175
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_categories")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 176
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_categories_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t<select class=\"form-control ";
        // line 180
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "category"), "method")) ? (" invalid") : (""));
        echo "\" id=\"category\" name=\"category\">
\t\t\t\t\t\t\t\t\t";
        // line 181
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["categories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 182
            echo "\t\t\t\t\t\t\t\t\t\t";
            if ((twig_length_filter($this->env, $this->getAttribute($context["category"], "child", array())) != null)) {
                // line 183
                echo "\t\t\t\t\t\t\t\t\t\t\t<optgroup class=\"optstyle\" label=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 184
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["category"], "child", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 185
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    if ((twig_length_filter($this->env, $this->getAttribute($context["child"], "child", array())) != null)) {
                        // line 186
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<optgroup class=\"optstyle\" label=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "name", array()), "html", null, true);
                        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 187
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["child"], "child", array()));
                        foreach ($context['_seq'] as $context["_key"] => $context["child2"]) {
                            // line 188
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "id", array()), "html", null, true);
                            echo "\" ";
                            echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "category", array()), "id", array()) == $this->getAttribute($context["child2"], "id", array()))) ? ("selected=\"selected\"") : (""));
                            echo ">";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["child2"], "name", array()), "html", null, true);
                            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child2'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 190
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    } else {
                        // line 192
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "id", array()), "html", null, true);
                        echo "\" ";
                        echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "category", array()), "id", array()) == $this->getAttribute($context["child"], "id", array()))) ? ("selected=\"selected\"") : (""));
                        echo ">";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["child"], "name", array()), "html", null, true);
                        echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 194
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 195
                echo "\t\t\t\t\t\t\t\t\t\t\t</optgroup>
\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 197
                echo "\t\t\t\t\t\t\t\t\t\t\t<option class=\"optstyle\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
                echo "\" ";
                echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "category", array()), "id", array()) == $this->getAttribute($context["category"], "id", array()))) ? ("selected=\"selected\"") : (""));
                echo ">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
                echo "</option>
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 199
            echo "\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 200
        echo "\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>


\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<label for=\"title\">";
        // line 208
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 209
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t<select class=\"";
        // line 213
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "listingclass"), "method")) ? (" invalid") : (""));
        echo "\" name=\"listingclass\">
\t\t\t\t\t\t\t\t\t<option ";
        // line 214
        echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "listing_class", array()), "id", array()) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option ";
        // line 215
        echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "listing_class", array()), "id", array()) == 2)) ? ("selected=\"selected\"") : (""));
        echo " value=\"2\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<label for=\"title\">";
        // line 223
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 224
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t<select class=\"";
        // line 228
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "status"), "method")) ? (" invalid") : (""));
        echo "\" name=\"status\">
\t\t\t\t\t\t\t\t\t<option ";
        // line 229
        echo ((($this->getAttribute(($context["listing"] ?? null), "is_published", array()) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_1")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option ";
        // line 230
        echo ((($this->getAttribute(($context["listing"] ?? null), "is_published", array()) == 0)) ? ("selected=\"selected\"") : (""));
        echo " value=\"2\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<label for=\"title\">";
        // line 237
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 238
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t<select class=\"";
        // line 242
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "escrow"), "method")) ? (" invalid") : (""));
        echo "\" name=\"escrow\">
\t\t\t\t\t\t\t\t\t";
        // line 243
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "has_fe", array()) == 1)) {
            // line 244
            echo "\t\t\t\t\t\t\t\t\t\t<option ";
            echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "payment_type", array()), "id", array()) == 2)) ? ("selected=\"selected\"") : (""));
            echo " value=\"2\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow_1")), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t";
        }
        // line 246
        echo "\t\t\t\t\t\t\t\t\t<option ";
        echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "payment_type", array()), "id", array()) == 1)) ? ("selected=\"selected\"") : (""));
        echo " value=\"1\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option ";
        // line 247
        echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "payment_type", array()), "id", array()) == 4)) ? ("selected=\"selected\"") : (""));
        echo " value=\"4\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_escrow_3")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"box box-stacked\">
\t\t\t\t<div class=\"box-header\">
\t\t\t\t\t<h2 class=\"heading-2\">";
        // line 256
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_details")), "html", null, true);
        echo "</h2>
\t\t\t\t</div>
\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t<div class=\"section-content\">
\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t<label for=\"price\">";
        // line 262
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_price")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 263
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_price_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t<div class=\"col-md-4 form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t\t\t<select class=\"";
        // line 269
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "currency"), "method")) ? (" invalid") : (""));
        echo "\" name=\"currency\">
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 270
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "usd")) ? ("selected=\"selected\"") : (""));
        echo " value=\"usd\">USD</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 271
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "eur")) ? ("selected=\"selected\"") : (""));
        echo " value=\"eur\">EUR</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 272
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "gbp")) ? ("selected=\"selected\"") : (""));
        echo " value=\"gbp\">GBP</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 273
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "aud")) ? ("selected=\"selected\"") : (""));
        echo " value=\"aud\">AUD</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 274
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "cad")) ? ("selected=\"selected\"") : (""));
        echo " value=\"cad\">CAD</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 275
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "brl")) ? ("selected=\"selected\"") : (""));
        echo " value=\"brl\">BRL</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 276
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "dkk")) ? ("selected=\"selected\"") : (""));
        echo " value=\"dkk\">DKK</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 277
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "sek")) ? ("selected=\"selected\"") : (""));
        echo " value=\"sek\">SEK</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 278
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "nok")) ? ("selected=\"selected\"") : (""));
        echo " value=\"nok\">NOK</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 279
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "try")) ? ("selected=\"selected\"") : (""));
        echo " value=\"try\">TRY</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 280
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "cny")) ? ("selected=\"selected\"") : (""));
        echo " value=\"cny\">CNY</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 281
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "hkd")) ? ("selected=\"selected\"") : (""));
        echo " value=\"hkd\">HKD</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 282
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "rub")) ? ("selected=\"selected\"") : (""));
        echo " value=\"rub\">RUB</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 283
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "inr")) ? ("selected=\"selected\"") : (""));
        echo " value=\"inr\">INR</option>
\t\t\t\t\t\t\t\t\t\t\t\t<option ";
        // line 284
        echo ((($this->getAttribute(($context["listing"] ?? null), "currency", array()) == "jpy")) ? ("selected=\"selected\"") : (""));
        echo " value=\"jpy\">JPY</option>
\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"col-md-8 form-group \">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"price\" id=\"price\" class=\"mp-Input ";
        // line 289
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "price"), "method")) ? (" invalid") : (""));
        echo "\" value=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "price", array()), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 296
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 297
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity_d"));
        echo "</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<input type=\"text\" name=\"quantity\" id=\"quantity\" class=\"mp-Input ";
        // line 300
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "quantity"), "method")) ? (" invalid") : (""));
        echo "\" value=\"";
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["listing"] ?? null), "quantity", array()) == "-1")) ? ("-1") : ($this->getAttribute(($context["listing"] ?? null), "quantity", array()))), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<label for=\"title\">";
        // line 305
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_from")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 306
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_from_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t\t<select class=\"";
        // line 310
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "shipped_from"), "method")) ? (" invalid") : (""));
        echo "\" name=\"shipped_from\">
\t\t\t\t\t\t\t\t\t\t";
        // line 311
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["countries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 312
            echo "\t\t\t\t\t\t\t\t\t\t\t<option ";
            echo ((($this->getAttribute($context["country"], "country_short_name", array()) == $this->getAttribute(($context["listing"] ?? null), "shipped_from", array()))) ? ("selected=\"selected\"") : (""));
            echo " value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_short_name", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_name", array()), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 314
        echo "\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"row form-group \">
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t\t<label for=\"ships_to\">";
        // line 321
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_to")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 322
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_to_d")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-6 \">
\t\t\t\t\t\t\t\t<div class=\"mp-Select country\">
\t\t\t\t\t\t\t\t\t<select class=\"";
        // line 326
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "ships_to"), "method")) ? (" invalid") : (""));
        echo "\" style=\"height:200px;\" name=\"ships_to[]\" multiple=\"\">
\t\t\t\t\t\t\t\t\t\t";
        // line 327
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["countries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 328
            echo "\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_short_name", array()), "html", null, true);
            echo "\" ";
            if (twig_in_filter($this->getAttribute($context["country"], "country_short_name", array()), ($context["own_countries"] ?? null))) {
                echo " selected=\"selected\" ";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["country"], "country_name", array()), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 330
        echo "\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"box box-stacked\">
\t\t\t\t<div class=\"box-header\">
\t\t\t\t\t<h2 class=\"heading-2\">";
        // line 339
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image")), "html", null, true);
        echo "
\t\t\t\t\t</h2>
\t\t\t\t</div>
\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t<div class=\"section-content\">
\t\t\t\t\t\t<p style=\"color: #656d78;margin-bottom: 20px;\">";
        // line 344
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image_d"));
        echo "</p>
\t\t\t\t\t\t<div class=\"row form-group \">
\t\t\t\t\t\t\t";
        // line 346
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "image_1"), "method")) {
            // line 347
            echo "\t\t\t\t\t\t\t\t<p style=\"color: red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_invalid_img")), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t";
        }
        // line 349
        echo "\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t<b>";
        // line 351
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image1")), "html", null, true);
        echo "</b>(";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_optional")), "html", null, true);
        echo ")</p>
\t\t\t\t\t\t\t\t<a class=\"thumbnail\" href=\"";
        // line 352
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo", array()), "html", null, true);
        echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t\t<img src=\"";
        // line 353
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo", array()), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<input name=\"image_1\" id=\"image_1\" type=\"file\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t";
        // line 360
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "image_2"), "method")) {
            // line 361
            echo "\t\t\t\t\t\t\t\t\t<p style=\"color: red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_invalid_img")), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t";
        }
        // line 363
        echo "\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t<b>";
        // line 364
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image1")), "html", null, true);
        echo " 2</b>(";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_optional")), "html", null, true);
        echo ")</p>
\t\t\t\t\t\t\t\t";
        // line 365
        if ($this->getAttribute(($context["listing"] ?? null), "photo2", array())) {
            // line 366
            echo "\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs remove\">X</button>
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"photo2\" value=\"remove2\">
\t\t\t\t\t\t\t\t\t<a class=\"thumbnail\" href=\"";
            // line 368
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo2", array()), "html", null, true);
            echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 369
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo2", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t";
        }
        // line 372
        echo "\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<input name=\"image_2\" id=\"image_2\" type=\"file\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-sm-4\">
\t\t\t\t\t\t\t\t";
        // line 377
        if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "image_3"), "method")) {
            // line 378
            echo "\t\t\t\t\t\t\t\t\t<p style=\"color: red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_invalid_img")), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t";
        }
        // line 380
        echo "\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t<b>";
        // line 381
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_image1")), "html", null, true);
        echo " 3</b>(";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_optional")), "html", null, true);
        echo ")</p>
\t\t\t\t\t\t\t\t";
        // line 382
        if ($this->getAttribute(($context["listing"] ?? null), "photo3", array())) {
            // line 383
            echo "\t\t\t\t\t\t\t\t\t<button class=\"mp-Button mp-Button--dangerous mp-Button--xs remove\">X</button>
\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"photo3\" value=\"remove2\">
\t\t\t\t\t\t\t\t\t<a class=\"thumbnail\" href=\"";
            // line 385
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo3", array()), "html", null, true);
            echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 386
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo3", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t";
        }
        // line 389
        echo "\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<input name=\"image_3\" id=\"image_3\" type=\"file\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>


\t\t\t<div class=\"box box-stacked\">
\t\t\t\t<div class=\"box-header\">
\t\t\t\t\t<h2 class=\"heading-2\">
\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t";
        // line 403
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage")), "html", null, true);
        echo "
\t\t\t\t\t\t</span>
\t\t\t\t\t</h2>
\t\t\t\t\t\t\t<p style=\"color: #656d78;margin-bottom: 20px;\">";
        // line 406
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_d")), "html", null, true);
        echo "</p>
\t\t\t\t</div>
\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t<div class=\"clear-fix\">
\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t<label for=\"postage_option\">";
        // line 412
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_1")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t\t\t<label for=\"postage_shipping\">";
        // line 415
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_2")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t\t\t<label for=\"postage_price\">";
        // line 418
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_3")), "html", null, true);
        echo "</label>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        // line 421
        $context["countPostage"] = 0;
        // line 422
        echo "
\t\t\t\t\t\t";
        // line 423
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["listing"] ?? null), "shipping_options", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["shipping"]) {
            // line 424
            echo "\t\t\t\t\t\t\t";
            $context["countPostage"] = (($context["countPostage"] ?? null) + 1);
            // line 425
            echo "\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t";
            // line 426
            if (($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "shipping_options", array()), "first", array()) != $context["shipping"])) {
                // line 427
                echo "\t\t\t\t\t\t\t\t\t<div class=\"col-md-1 \">
\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 428
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("shipping.remove", array("listing" => ($context["listing"] ?? null), "id" => $context["shipping"])));
                echo "\" class=\"mp-Button mp-Button--primary mp-Button--xs\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-delete-white\"></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            }
            // line 433
            echo "\t\t\t\t\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" name=\"postage_option_id_";
            // line 434
            echo twig_escape_filter($this->env, $this->getAttribute($context["shipping"], "id", array()), "html", null, true);
            echo "\" id=\"title_postage\" class=\"mp-Input ";
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => $this->getAttribute($this->getAttribute("postage_option_id_", "shipping", array()), "id", array())), "method")) ? (" invalid") : (""));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["shipping"], "name", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-2 \">
\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" name=\"postage_shipping_id_";
            // line 437
            echo twig_escape_filter($this->env, $this->getAttribute($context["shipping"], "id", array()), "html", null, true);
            echo "\" id=\"days\" class=\"mp-Input ";
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => $this->getAttribute($this->getAttribute("postage_shipping_id_", "shipping", array()), "id", array())), "method")) ? (" invalid") : (""));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["shipping"], "days", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" name=\"postage_price_id_";
            // line 440
            echo twig_escape_filter($this->env, $this->getAttribute($context["shipping"], "id", array()), "html", null, true);
            echo "\" id=\"price\" class=\"mp-Input ";
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => $this->getAttribute($this->getAttribute("postage_price_id_", "shipping", array()), "id", array())), "method")) ? (" invalid") : (""));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["shipping"], "price", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['shipping'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 444
        echo "
\t\t\t\t\t\t";
        // line 445
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range((($context["countPostage"] ?? null) + 1), 4));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 446
            $context["postage_option"] = $this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "shipping_options", array()), ($context["i"] - 1), array(), "array"), "name", array(), "array");
            // line 447
            echo "\t\t\t\t\t\t\t";
            $context["postage_shipping"] = $this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "shipping_options", array()), ($context["i"] - 1), array(), "array"), "days", array(), "array");
            // line 448
            echo "\t\t\t\t\t\t\t";
            $context["postage_price"] = $this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "shipping_options", array()), ($context["i"] - 1), array(), "array"), "price", array(), "array");
            // line 449
            echo "
\t\t\t\t\t\t\t<div class=\"row form-group\">
\t\t\t\t\t\t\t\t<div class=\"col-md-6 \">
\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" placeholder=\"";
            // line 452
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_1")), "html", null, true);
            echo "\" name=\"postage_option_";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "\" id=\"title_postage\" class=\"mp-Input ";
            echo ((($context["i"] == 1)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_1"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 2)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_2"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 3)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_3"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 4)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_4"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 5)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_5"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 6)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_6"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 7)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_7"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 8)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_option_8"), "method")) ? (" invalid") : (""))) : (""))))))))))))))));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, ((($context["i"] == 1)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_1"))) : (((($context["i"] == 2)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_2"))) : (((($context["i"] == 3)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_3"))) : (((($context["i"] == 4)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_4"))) : (((($context["i"] == 5)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_5"))) : (((($context["i"] == 6)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_6"))) : (((($context["i"] == 7)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_7"))) : (((($context["i"] == 8)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_option_8"))) : ("")))))))))))))))), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-2 \">
\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" placeholder=\"";
            // line 455
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_2")), "html", null, true);
            echo "\" name=\"postage_shipping_";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "\" id=\"days\" class=\"mp-Input ";
            echo ((($context["i"] == 1)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_1"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 2)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_2"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 3)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_3"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 4)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_4"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 5)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_5"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 6)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_6"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 7)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_7"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 8)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_shipping_8"), "method")) ? (" invalid") : (""))) : (""))))))))))))))));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, ((($context["i"] == 1)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_1"))) : (((($context["i"] == 2)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_2"))) : (((($context["i"] == 3)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_3"))) : (((($context["i"] == 4)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_4"))) : (((($context["i"] == 5)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_5"))) : (((($context["i"] == 6)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_6"))) : (((($context["i"] == 7)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_7"))) : (((($context["i"] == 8)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_shipping_8"))) : ("")))))))))))))))), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t\t\t\t<input style=\"width:100%;\" type=\"text\" placeholder=\"";
            // line 458
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_postage_3")), "html", null, true);
            echo "\" name=\"postage_price_";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "\" id=\"price\" class=\"mp-Input ";
            echo ((($context["i"] == 1)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_1"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 2)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_2"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 3)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_3"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 4)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_4"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 5)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_5"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 6)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_6"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 7)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_7"), "method")) ? (" invalid") : (""))) : (((($context["i"] == 8)) ? ((($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "postage_price_8"), "method")) ? (" invalid") : (""))) : (""))))))))))))))));
            echo "\" value=\"";
            echo twig_escape_filter($this->env, ((($context["i"] == 1)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_1"))) : (((($context["i"] == 2)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_2"))) : (((($context["i"] == 3)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_3"))) : (((($context["i"] == 4)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_4"))) : (((($context["i"] == 5)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_5"))) : (((($context["i"] == 6)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_6"))) : (((($context["i"] == 7)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_7"))) : (((($context["i"] == 8)) ? (call_user_func_array($this->env->getFunction('old')->getCallable(), array("postage_price_8"))) : ("")))))))))))))))), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 463
        echo "\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"box box-stacked\">
\t\t\t\t<div class=\"box-header\">
\t\t\t\t\t<h2 class=\"heading-2\">
\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t";
        // line 470
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_dispatch_notes")), "html", null, true);
        echo "
\t\t\t\t\t\t</span>
\t\t\t\t\t</h2>
\t\t\t\t\t<p style=\"color: #656d78;margin-bottom: 20px;\">";
        // line 473
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_dispatch_notes_d")), "html", null, true);
        echo " </p>
\t\t\t\t</div>
\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t<textarea class=\"mp-Textarea ";
        // line 476
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "autodispatch"), "method")) ? (" invalid") : (""));
        echo "\" id=\"autodispatch\" name=\"autodispatch\" style=\"height:150px;\" placeholder=\"\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "autodispatch", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"box box-stacked\" id=\"place-advertisement\">
\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t<button type=\"submit\" id=\"syi-place-ad-button\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t<span>";
        // line 482
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_save")), "html", null, true);
        echo "</span>
\t\t\t\t\t</button>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</section>
</div></div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/create/edit.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1089 => 482,  1078 => 476,  1072 => 473,  1066 => 470,  1057 => 463,  1040 => 458,  1028 => 455,  1016 => 452,  1011 => 449,  1008 => 448,  1005 => 447,  1003 => 446,  999 => 445,  996 => 444,  982 => 440,  972 => 437,  962 => 434,  959 => 433,  951 => 428,  948 => 427,  946 => 426,  943 => 425,  940 => 424,  936 => 423,  933 => 422,  931 => 421,  925 => 418,  919 => 415,  913 => 412,  904 => 406,  898 => 403,  882 => 389,  876 => 386,  872 => 385,  868 => 383,  866 => 382,  860 => 381,  857 => 380,  851 => 378,  849 => 377,  842 => 372,  836 => 369,  832 => 368,  828 => 366,  826 => 365,  820 => 364,  817 => 363,  811 => 361,  809 => 360,  799 => 353,  795 => 352,  789 => 351,  785 => 349,  779 => 347,  777 => 346,  772 => 344,  764 => 339,  753 => 330,  738 => 328,  734 => 327,  730 => 326,  723 => 322,  719 => 321,  710 => 314,  697 => 312,  693 => 311,  689 => 310,  682 => 306,  678 => 305,  668 => 300,  662 => 297,  658 => 296,  646 => 289,  638 => 284,  634 => 283,  630 => 282,  626 => 281,  622 => 280,  618 => 279,  614 => 278,  610 => 277,  606 => 276,  602 => 275,  598 => 274,  594 => 273,  590 => 272,  586 => 271,  582 => 270,  578 => 269,  569 => 263,  565 => 262,  556 => 256,  542 => 247,  535 => 246,  527 => 244,  525 => 243,  521 => 242,  514 => 238,  510 => 237,  498 => 230,  492 => 229,  488 => 228,  481 => 224,  477 => 223,  464 => 215,  458 => 214,  454 => 213,  447 => 209,  443 => 208,  433 => 200,  427 => 199,  417 => 197,  413 => 195,  407 => 194,  397 => 192,  393 => 190,  380 => 188,  376 => 187,  371 => 186,  368 => 185,  364 => 184,  359 => 183,  356 => 182,  352 => 181,  348 => 180,  341 => 176,  337 => 175,  326 => 169,  320 => 166,  316 => 165,  302 => 154,  294 => 149,  238 => 96,  233 => 94,  221 => 85,  214 => 81,  205 => 77,  199 => 74,  195 => 73,  185 => 68,  179 => 65,  175 => 64,  168 => 59,  162 => 57,  157 => 54,  149 => 52,  145 => 51,  136 => 50,  132 => 49,  128 => 48,  124 => 47,  121 => 46,  119 => 45,  113 => 42,  109 => 41,  100 => 35,  95 => 34,  88 => 30,  83 => 27,  80 => 26,  73 => 22,  68 => 19,  66 => 18,  59 => 14,  55 => 13,  48 => 11,  43 => 8,  40 => 7,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/create/edit.twig", "");
    }
}
