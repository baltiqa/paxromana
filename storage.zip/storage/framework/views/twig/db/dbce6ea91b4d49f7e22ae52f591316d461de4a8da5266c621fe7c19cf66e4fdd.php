<?php

/* /var/www/html/html/resources/themes/default/page.twig */
class __TwigTemplate_bff68ce124950d5958ef3a3d1e3b116700a974d4c9e67b4c8d85cc26a47571ba extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
\t<head>
\t\t<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
\t\t<title>Pax Romana Wiki</title>

\t\t<link href=\"/web/css/wiki.css\" rel=\"stylesheet\">
\t\t<link href=\"/web/images/favicon.ico\" rel=\"shortcut icon\">

\t<style>
\t.highlight {
\tbackground-color:yellow;
\t}
\t</style>
\t</head>
\t<body class=\"mediawiki\">
\t\t<div id=\"globalWrapper\">
\t\t\t<div id=\"column-content\">
\t\t\t\t<div class=\"mw-body\" id=\"content\" role=\"main\">
\t\t\t\t\t<a id=\"top\"></a>
\t\t\t\t\t<div class=\"mw-indicators mw-body-content\"></div>
\t\t\t\t\t";
        // line 22
        if ( !$this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "search"), "method")) {
            // line 23
            echo "\t\t\t\t\t<h1 class=\"firstHeading\" id=\"firstHeading\">Main Page</h1>
\t\t\t\t\t<div class=\"mw-body-content\" id=\"bodyContent\">
\t\t\t\t\t\t<div class=\"mw-content-ltr\"id=\"mw-content-text\">
\t\t\t\t\t\t\t<blockquote style=\"background-color: #E6E8F8; border: solid thin grey;\">
\t\t\t\t\t\t\t\t<center>
\t\t\t\t\t\t\t\t\t<b>Welcome to
\t\t\t\t\t\t\t\t\t\t<a class=\"external text\" href=\"Main_Page.html\" rel=\"nofollow noreferrer noopener\" target=\"_blank\">The Roman Wiki</a>
\t\t\t\t\t\t\t\t\t\t- Get your information how to use the marketplace Pax Romana!</b>
\t\t\t\t\t\t\t\t</center>
\t\t\t\t\t\t\t</blockquote>
\t\t\t\t\t\t\t<h1>
\t\t\t\t\t\t\t\t<span class=\"mw-headline\">Welcome to Pax Romana Wiki</span>
\t\t\t\t\t\t\t</h1>
\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\tOur goal is very simple, our website must be as simple as possible for both buyers and sellers. In addition, we offer excellent information on how you should be able to act so safely.</p>
\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t<label class=\"titlec\">What can you expect from our Roman wiki page?</label>
\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t<li>News concerns the marketplace.</li>
\t\t\t\t\t\t\t\t<li>Information how you can use the marketplace.</li>
\t\t\t\t\t\t\t\t<li>Account security</li>
\t\t\t\t\t\t\t\t<li>How to use PGP</li>
\t\t\t\t\t\t\t\t<li>How you can act safely without being scammed.</li>
\t\t\t\t\t\t\t\t<li>Many more informations available!</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t<b>We recommend to our users to safe our Roman PGP Key to verify our messages. You can find it <a href=\"";
            // line 48
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
            echo "/pgp.txt\">here</a>.</b>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t<p>If you have any questions, don't hestitate to sent us a message.</p>
\t\t\t\t\t\t\tYours Sincerely,<br>
\t\t\t\t\t\t\tPax Romana Emperor
\t\t\t\t\t\t\t<hr>
\t\t\t\t\t\t\t";
        } else {
            // line 55
            echo "\t\t\t\t\t\t\t<h1 class=\"firstHeading\" id=\"firstHeading\">Search results (";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["newssearches"] ?? null), "count", array(), "method"), "html", null, true);
            echo ")</h1>
\t\t\t\t\t\t<div class=\"mw-body-content\" id=\"bodyContent\">
\t\t\t\t\t\t<div class=\"mw-content-ltr\"id=\"mw-content-text\">
\t\t\t\t\t\t\t<blockquote style=\"background-color: #E6E8F8; border: solid thin grey;\">
\t\t\t\t\t\t\t\t<center>
\t\t\t\t\t\t\t\t\t<b>Welcome to
\t\t\t\t\t\t\t\t\t\t<a class=\"external text\" href=\"Main_Page.html\" rel=\"nofollow noreferrer noopener\" target=\"_blank\">The Roman Wiki</a>
\t\t\t\t\t\t\t\t\t\t- Get your information how to use the marketplace Pax Romana!</b>
\t\t\t\t\t\t\t\t</center>
\t\t\t\t\t\t\t</blockquote>
\t\t\t\t\t\t\t";
            // line 65
            if (($this->getAttribute(($context["newssearches"] ?? null), "count", array()) != 0)) {
                // line 66
                echo "\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["newssearches"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["search"]) {
                    // line 67
                    echo "\t\t\t\t\t\t\t<hr>
\t\t\t\t\t\t\t<div class=\"news\">
\t\t\t\t\t\t\t<a href=\"";
                    // line 69
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("page.single", $this->getAttribute($context["search"], "id", array())));
                    echo "\"><label class=\"titlec\">";
                    echo call_user_func_array($this->env->getFilter('highlight')->getCallable(), array($this->getAttribute($context["search"], "title", array()), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "get", array(0 => ("search" . ($context["twig_var_name"] ?? null))), "method")));
                    echo "</label><small style=\"float:right\">Read More</small>
\t\t\t\t\t\t\t";
                    // line 70
                    echo call_user_func_array($this->env->getFilter('highlight')->getCallable(), array(strip_tags($this->getAttribute($context["search"], "body", array())), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "get", array(0 => ("search" . ($context["twig_var_name"] ?? null))), "method")));
                    echo "
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['search'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 74
                echo "\t\t\t\t\t\t\t";
            } else {
                // line 75
                echo "\t\t\t\t\t\t\t<p>Oops.. couldn't find what you want.</p>
\t\t\t\t\t\t\t<hr>
\t\t\t\t\t\t\t";
            }
            // line 78
            echo "\t\t\t\t\t\t\t";
        }
        // line 79
        echo "\t\t\t\t\t\t\t<h1><span class=\"mw-headline\">Latest News</span></h1>
\t\t\t\t\t\t\t";
        // line 80
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["news"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["featured"]) {
            // line 81
            echo "\t\t\t\t\t\t\t<a name=\"featured-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["featured"], "id", array()), "html", null, true);
            echo "\"></a>
\t\t\t\t\t\t\t<div class=\"news\">
\t\t\t\t\t\t\t<label class=\"titlec\">";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute($context["featured"], "title", array()), "html", null, true);
            echo "</label>
\t\t\t\t\t\t\t<small><b>Posted ";
            // line 84
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["featured"], "created_at", array()), "diffForHumans", array(0 => null, 1 => true), "method"), "html", null, true);
            echo " ago</b></small><br>
\t\t\t\t\t\t\t";
            // line 85
            echo $this->getAttribute($context["featured"], "body", array());
            echo "
\t\t\t\t\t\t\t\t<div class=\"article-feedback\">
\t\t\t\t\t\t\t\t\t<div id=\"feedback-button\" style=\"display:inline\">
\t\t\t\t\t\t\t\t\t\t<hr class=\"article-hr\">What do you think about it?
\t\t\t\t\t\t\t\t\t\t<div class=\"btn-group feedback-radio-group\">
\t\t\t\t\t\t\t\t\t\t\t<a  href=\"/wiki/";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute($context["featured"], "id", array()), "html", null, true);
            echo "/voteup\"><label style=\"background-color:#F0F0F0;\" class=\"btn btn-secondary radio-btn\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["featured"], "vote_up", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"height: 21px; width: 21px;\" src=\"/web/images/thumbs-up-solid.png\">
\t\t\t\t\t\t\t\t\t\t\t</label></a>
\t\t\t\t\t\t\t\t\t\t\t<a  href=\"/wiki/";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["featured"], "id", array()), "html", null, true);
            echo "/votedown\"><label style=\"background-color:#F0F0F0\" class=\"btn btn-secondary radio-btn\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["featured"], "vote_down", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"height: 21px; width: 21px;\" src=\"/web/images/thumbs-down-solid.png\">
\t\t\t\t\t\t\t\t\t\t\t</label></a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['featured'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 101
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div id=\"column-one\">
\t\t\t\t<div class=\"portlet\" id=\"p-logo\" role=\"banner\">
\t\t\t\t\t<a class=\"mw-wiki-logo\" href=\"/wiki\" title=\"Visit the main page\"></a>
\t\t\t\t</div>
\t\t\t\t<div class=\"portlet\" id=\"p-search\" role=\"search\">
\t\t\t\t\t<h3>
\t\t\t\t\t\t<label for=\"searchInput\">Search</label>
\t\t\t\t\t</h3>
\t\t\t\t\t<div class=\"pBody\" id=\"searchBody\">
\t\t\t\t\t\t<form action=\"";
        // line 114
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("page"));
        echo "\" id=\"searchform\" name=\"searchform\" method=\"GET\">
\t\t\t\t\t\t\t<input id=\"searchInput\" name=\"search\" placeholder=\"Search The Wiki\" title=\"Search The Wiki\" text=\"search\">
\t\t\t\t\t\t\t<button class=\"searchButton\" id=\"mw-searchButton\" title=\"Search the pages for this text\" type=\"submit\" value=\"Search\">Search</button>
\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<label>contents</label>
\t\t\t\t<div>
\t\t\t\t\t<div class=\"toc\" id=\"toc\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t ";
        // line 124
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["newscat"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["cat"]) {
            // line 125
            echo "\t\t\t\t\t\t\t<li class=\"toclevel-1\">
\t\t\t\t\t\t\t\t<a href=\"";
            // line 126
            echo ((($this->getAttribute($context["cat"], "disabled", array()) == 0)) ? (call_user_func_array($this->env->getFunction('route')->getCallable(), array("page.single", $this->getAttribute($context["cat"], "id", array())))) : ("#"));
            echo "\">
\t\t\t\t\t\t\t\t\t<span class=\"tocnumber\">";
            // line 127
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"toctext\">";
            // line 128
            echo twig_escape_filter($this->env, $this->getAttribute($context["cat"], "title", array()), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t";
            // line 130
            if (($this->getAttribute($this->getAttribute($context["cat"], "newsc", array(), "method"), "count", array()) != 0)) {
                // line 131
                echo "\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t ";
                // line 132
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["cat"], "newsc", array(), "method"));
                foreach ($context['_seq'] as $context["childkey"] => $context["newschild"]) {
                    // line 133
                    echo "\t\t\t\t\t\t\t\t\t<li class=\"toclevel-2\">
\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    // line 134
                    echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("page.single", $this->getAttribute($context["newschild"], "id", array())));
                    echo "\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"tocnumber\">";
                    // line 135
                    echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
                    echo ".";
                    echo twig_escape_filter($this->env, ($context["childkey"] + 1), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"toctext\">";
                    // line 136
                    echo twig_escape_filter($this->env, $this->getAttribute($context["newschild"], "title", array()), "html", null, true);
                    echo "</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t  ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['childkey'], $context['newschild'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 140
                echo "\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t";
            }
            // line 142
            echo "\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['cat'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 144
        echo "\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<h2>Navigation menu</h2>
\t\t\t\t<div class=\"portlet\" id=\"p-cactions\" role=\"navigation\">
\t\t\t\t\t<h3>Views</h3>
\t\t\t\t\t<div class=\"pBody\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li class=\"selected\" id=\"ca-nstab-main\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 153
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("page"));
        echo "\" title=\"Home\">Home Wiki</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li id=\"ca-viewsource\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 156
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/account/create/ticket\" title=\"View the content page [c]\">Create Ticket</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li id=\"ca-talk\">
\t\t\t\t\t\t\t\t<a href=\"/d/RomanRoad\" title=\"View the content page [c]\">Pax Romana Forum</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li id=\"ca-history\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 162
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/pgp.txt\" title=\"PGP Key of Pax Romana\">Pax Romana PGP</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li id=\"ca-history\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 165
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/\" title=\"View the content page [c]\">Go Back to Market</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"portlet\" id=\"p-personal\">
\t\t\t\t\t<h3>Personal tools</h3>
\t\t\t\t\t<div class=\"pBody\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li id=\"pt-login\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 175
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/profile/fuckk\" title=\"Your account\">";
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"portlet\" id=\"p-tb\">
\t\t\t\t\t<h3>Tools</h3>
\t\t\t\t\t<div class=\"pBody\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<li><a href=\"";
        // line 184
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/help/mirrors\" title=\"Mirros Explanation\">Mirrors</a></li>
\t\t\t\t\t\t\t<li><a href=\"";
        // line 185
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/account/create/ticket?t=vendor\" title=\"Request FE rights\">Request FE rights</a></li>
\t\t\t\t\t\t\t<li><a href=\"";
        // line 186
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/account/apply_vendor\" title=\"Apply Vendor\">Apply Vendorship</a></li>
\t\t\t\t\t\t\t<li><a href=\"";
        // line 187
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/account/ticket/create\" title=\"Contact Support\">Contact Support</a></li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"visualClear\"></div>
\t\t\t<div id=\"footer\" role=\"contentinfo\">
\t\t\t\t<ul id=\"f-list\">
\t\t\t\t\t<li>Copyright © 2019-2020 Pax Romana Wiki</li>
\t\t\t\t</ul>
\t\t\t</div>
\t\t</div>
\t</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/page.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  348 => 187,  344 => 186,  340 => 185,  336 => 184,  322 => 175,  309 => 165,  303 => 162,  294 => 156,  288 => 153,  277 => 144,  270 => 142,  266 => 140,  256 => 136,  250 => 135,  246 => 134,  243 => 133,  239 => 132,  236 => 131,  234 => 130,  229 => 128,  225 => 127,  221 => 126,  218 => 125,  214 => 124,  201 => 114,  186 => 101,  170 => 93,  162 => 90,  154 => 85,  150 => 84,  146 => 83,  140 => 81,  136 => 80,  133 => 79,  130 => 78,  125 => 75,  122 => 74,  112 => 70,  106 => 69,  102 => 67,  97 => 66,  95 => 65,  81 => 55,  71 => 48,  44 => 23,  42 => 22,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/page.twig", "");
    }
}
