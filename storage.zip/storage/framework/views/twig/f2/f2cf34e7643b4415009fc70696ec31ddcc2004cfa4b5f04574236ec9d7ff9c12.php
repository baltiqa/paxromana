<?php

/* /var/www/html/html/resources/themes/default/auth/verify.twig */
class __TwigTemplate_9ef3de72f7a60ec9e2246222ffa747663b9cfe8843fac232068de1179b5000f0 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.frontpage", "/var/www/html/html/resources/themes/default/auth/verify.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'navbar' => array($this, 'block_navbar'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.frontpage";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('env')->getCallable(), array("WEBSITE_URL")), "html", null, true);
        echo "/web/css/index.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        // line 7
        echo "\t<header>
\t\t<div class=\"mp-Header-ribbonTop\"></div>
\t\t<div class=\"mp-Header-ribbonBottom\"></div>
\t</header>
";
    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        // line 13
        echo "<div id=\"page-wrapper\">
\t\t<div class=\"l-page pagelog\">
        <section class=\"l-main-right\">
           <a class=\"pagelogo\" href=\"/\" title=\"Pax Romana\"></a>
           \t";
        // line 17
        $this->loadTemplate("auth.flags.twig", "/var/www/html/html/resources/themes/default/auth/verify.twig", 17)->display($context);
        // line 18
        echo "               <div class=\"mp-Alert \" style=\"background-color:#D4EFFA;\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t<li style=\"color:black;\">";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.session_title")), "html", null, true);
        echo "</li>
\t\t\t\t\t</div>
\t\t\t\t</div>
          <div class=\"mp-Alert \" style=\"background-color:#D4EFFA;\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t<li style=\"color:black;\">";
        // line 27
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.verify_text_how"));
        echo " </li>
\t\t\t\t\t\t\t</div>
\t\t\t</div>
            <div class=\"mp-Card mp-Card--rounded login\">
                <div class=\"mp-Card-block\">
                    <div class=\"mp-Form mp-Form--aligned\">
                            <textarea style=\"word-wrap: break-word;background-color: #EDECED; white-space: pre-wrap; line-height: normal; height:500px;width:500px;\" readonly=\"readonly\">
";
        // line 34
        echo twig_escape_filter($this->env, ($context["message"] ?? null), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t\t\t</textarea>
                    </div>
                    <div class=\"mp-Form-controlGroup\">
                                              <a href=\"/\" class=\"mp-Button mp-Button--primary\">
                                                <span>";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.verify_return_back")), "html", null, true);
        echo "</span>
                                             </a>
                    </div>
                </div>
            </div>

        </section>
        <div class=\"index-log mp-FooterAlternative \">
\t\t\t\t\t\t<a  href=\"http://dreadditevelidot.onion/d/RomanRoad\">
\t\t\t\t\t\t\t<img width=\"30\" title=\"Pax Romana Forum\" src=\"/web/images/dread.png\"/>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<span class=\"footer-draw\"></span>
\t\t\t\t\t\t\t<a  href=\"http://raptortiabg7uyez.onion/\">
\t\t\t\t\t\t\t<img width=\"30\" title=\"Raptor Get your links safely\" src=\"/web/images/raptor.png\"/>
\t\t\t\t\t\t</a>
\t\t\t\t</div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/auth/verify.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 39,  86 => 34,  76 => 27,  67 => 21,  62 => 18,  60 => 17,  54 => 13,  51 => 12,  43 => 7,  40 => 6,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/auth/verify.twig", "");
    }
}
