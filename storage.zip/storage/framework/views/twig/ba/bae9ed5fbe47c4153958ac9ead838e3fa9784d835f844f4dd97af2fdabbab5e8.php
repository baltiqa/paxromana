<?php

/* /var/www/html/html/resources/themes/default/account/orders/show.twig */
class __TwigTemplate_47987eaddc2e93d4cb000913b53b9f838558242bd02e9e85d7bd9181de6f9fde extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/orders/show.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_ads.css\" rel=\"stylesheet\">
";
    }

    // line 5
    public function block_user_area($context, array $blocks = array())
    {
        // line 6
        echo "\t<div id=\"content\" class=\"l-page\">
\t\t";
        // line 7
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 8
            echo "\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t<div>
\t\t\t\t\t";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t";
        }
        // line 15
        echo "\t\t";
        $this->loadTemplate("account.head_vendor_bar.twig", "/var/www/html/html/resources/themes/default/account/orders/show.twig", 15)->display($context);
        // line 16
        echo "\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t<div class=\"content\">
\t\t\t\t\t<h2 class=\"pull-left\" style=\"margin: 0;\">
\t\t\t\t\t\t<strong>";
        // line 20
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order")), "html", null, true);
        echo " #";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "id", array()), "html", null, true);
        echo "</strong>
\t\t\t\t\t</h2>
\t\t\t\t\t<h2 class=\"pull-right\" style=\"margin: 0;\">
\t\t\t\t\t\t<a class=\"text-info\" href=\"/account/orders\">
\t\t\t\t\t\t\t<strong>← ";
        // line 24
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_back_to_overview")), "html", null, true);
        echo "</strong>
\t\t\t\t\t\t</a>
\t\t\t\t\t</h2><br>
\t\t\t\t\t<table class=\"table table-orders-meta\">
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t<i class=\"mp-Icon mp-svg-clock-grey\" style=\"margin-left: 0;\" title=\"Date\"></i>
\t\t\t\t\t\t\t\t\t";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "created_at", array()), "toFormattedDateString", array()), "html", null, true);
        echo "&nbsp;&nbsp;
\t\t\t\t\t\t\t\t\t<i class=\"mp-Button-icon mp-Button-icon--left mp-svg-handshake\" title=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "payment_type", array()), "payment_name", array()), "html", null, true);
        echo "\"></i>
\t\t\t\t\t\t\t\t\t";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "payment_type", array()), "payment_name", array()), "html", null, true);
        echo "&nbsp;&nbsp;
\t\t\t\t\t\t\t\t\t<i class=\"mp-Button-icon mp-Button-icon--left ";
        // line 35
        echo ((($this->getAttribute(($context["order"] ?? null), "is_digtal", array()) == 0)) ? ("mp-svg-postpackage") : ("mp-svg-digital"));
        echo " \" title=\"";
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["order"] ?? null), "is_digtal", array()) == "0")) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2")))), "html", null, true);
        echo "\"></i>
\t\t\t\t\t\t\t\t\t";
        // line 36
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["order"] ?? null), "is_digtal", array()) == "0")) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_1"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class_2")))), "html", null, true);
        echo "&nbsp;&nbsp;
\t\t\t\t\t\t\t\t\t<i class=\"mp-Icon mp-svg-profile style-scope mp-header\" title=\"";
        // line 37
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_buyer")), "html", null, true);
        echo "\"></i>
\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "</a>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        // line 40
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) {
            // line 41
            echo "\t\t\t\t\t\t\t\t\t<td class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 42
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status1")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 45
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "shipped")) {
            // line 46
            echo "\t\t\t\t\t\t\t\t\t<td class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 47
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status2")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 50
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "finalized")) {
            // line 51
            echo "\t\t\t\t\t\t\t\t\t<td style=\"background-color:green;\" class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 52
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status3")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 55
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "disputed")) {
            // line 56
            echo "\t\t\t\t\t\t\t\t\t<td style=\"background-color:red;\" class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 57
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status4")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 60
        echo "\t\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "cancelled")) {
            // line 61
            echo "\t\t\t\t\t\t\t\t\t<td style=\"background-color:red;\" class=\"status  status-info \">
\t\t\t\t\t\t\t\t\t\t";
            // line 62
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_order_status5")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t";
        }
        // line 65
        echo "\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>
\t\t\t\t\t<table style=\"width:100%\" class=\"table table-bordered\">
\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<th style=\"width: 100px;\" class=\"text-center\">";
        // line 71
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t<th>";
        // line 72
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_prod")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t\t<th style=\"width: 150px;\" class=\"text-right\">";
        // line 73
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_subtotal")), "html", null, true);
        echo "</th>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</thead>
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td style=\"width: 100px;\" rowspan=\"2\" class=\"text-center\">";
        // line 78
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "amount", array()), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t";
        // line 81
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "product_title", array()), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t<em></em>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t<td style=\"width: 150px;\" rowspan=\"2\" class=\"text-right\">
\t\t\t\t\t\t\t\t\t";
        // line 86
        if (($this->getAttribute(($context["order"] ?? null), "currency", array()) == "BTC")) {
            // line 87
            echo "\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "price", array()), "html", null, true);
            echo "BTC  (";
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute(($context["order"] ?? null), "price", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 88
($context["order"] ?? null), "currency", array()) == "LTC")) {
            // line 89
            echo "\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "price", array()), "html", null, true);
            echo "LTC  (";
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute(($context["order"] ?? null), "price", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 90
($context["order"] ?? null), "currency", array()) == "XMR")) {
            // line 91
            echo "\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "price", array()), "html", null, true);
            echo "XMR  (";
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute(($context["order"] ?? null), "price", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t";
        }
        // line 93
        echo "\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td class=\"text-muted\">";
        // line 96
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_dispatched_on")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 97
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "updated_at", array()), "toFormattedDateString", array()), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<p class=\"text-info\">
\t\t\t\t\t\t\t";
        // line 103
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "shipped")) {
            // line 104
            echo "\t\t\t\t\t\t\t\t<li>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_finalized")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 105
            echo twig_escape_filter($this->env, ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "days", array()) + ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "weeks", array()) * 7)), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 106
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 107
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 108
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 109
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 110
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 111
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\ts";
            // line 112
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t";
        }
        // line 115
        echo "\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "accepted")) {
            // line 116
            echo "\t\t\t\t\t\t\t\t<li>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_cancelled")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 117
            echo twig_escape_filter($this->env, ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "days", array()) + ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "weeks", array()) * 7)), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 118
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_days")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 119
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "hours", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 120
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_hou")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 121
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "minutes", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 122
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_min")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<i style=\"color:blue;\">";
            // line 123
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "elapsed", array(0 => "auto_final"), "method"), "seconds", array()), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t";
            // line 124
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_sec")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t";
        }
        // line 127
        echo "\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "finalized")) {
            // line 128
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_fin"));
            echo "
\t\t\t\t\t\t\t\t";
            // line 129
            if (($this->getAttribute(($context["order"] ?? null), "feedback", array()) != null)) {
                // line 130
                echo "\t\t\t\t\t\t\t\t\t<br>";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_left_feedback")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
                // line 132
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "username", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "username", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t\t(";
                // line 133
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "feedback", array()), "rate", array()), 2), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t";
                // line 134
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_rating")), "html", null, true);
                echo ")</b><br>
\t\t\t\t\t\t\t\t\t";
                // line 135
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute(($context["order"] ?? null), "feedback", array()), "comment", array()) == null)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_no_comment"))) : ($this->getAttribute($this->getAttribute(($context["order"] ?? null), "feedback", array()), "comment", array()))), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t";
            }
            // line 137
            echo "\t\t\t\t\t\t\t";
        }
        // line 138
        echo "\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "disputed")) {
            // line 139
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_disp"));
            echo "
\t\t\t\t\t\t\t";
        }
        // line 141
        echo "\t\t\t\t\t\t\t";
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "cancelled")) {
            // line 142
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_canc"));
            echo "
\t\t\t\t\t\t\t";
        }
        // line 144
        echo "
\t\t\t\t\t\t\t";
        // line 145
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) {
            // line 146
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_process"));
            echo "
\t\t\t\t\t\t\t";
        }
        // line 148
        echo "
\t\t\t\t\t\t\t";
        // line 149
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "shipped")) {
            // line 150
            echo "\t\t\t\t\t\t\t\t";
            echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_funds_ship"));
            echo "
\t\t\t\t\t\t\t";
        }
        // line 152
        echo "
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<table class=\"table\" style=\"float:right;width: 50%; margin: 0;\">
\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<th style=\"border-top: 0; padding-top: 0;\" class=\"text-right\">";
        // line 157
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "commission", array()), "html", null, true);
        echo "% ";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_commission")), "html", null, true);
        echo "
\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t<td style=\"width: 150px; border-top: none; padding-top: 0;\" class=\"text-right\">
\t\t\t\t\t\t\t\t\t\t";
        // line 160
        if (($this->getAttribute(($context["order"] ?? null), "currency", array()) == "BTC")) {
            // line 161
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute(($context["order"] ?? null), "service_fee", array()), 7), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 162
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "currency", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t(";
            // line 163
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute(($context["order"] ?? null), "service_fee", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 164
($context["order"] ?? null), "currency", array()) == "LTC")) {
            // line 165
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "service_fee", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 166
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "currency", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t(";
            // line 167
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute(($context["order"] ?? null), "service_fee", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 168
($context["order"] ?? null), "currency", array()) == "XMR")) {
            // line 169
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "service_fee", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 170
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "currency", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t(";
            // line 171
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute(($context["order"] ?? null), "service_fee", array()), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 173
        echo "\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t<th class=\"text-right lead\">
\t\t\t\t\t\t\t\t\t\t<strong>";
        // line 177
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_net_income")), "html", null, true);
        echo "</strong>
\t\t\t\t\t\t\t\t\t</th>
\t\t\t\t\t\t\t\t\t<td style=\"width: 150px;\" class=\"text-right lead\">
\t\t\t\t\t\t\t\t\t\t<strong>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 181
        if (($this->getAttribute(($context["order"] ?? null), "currency", array()) == "BTC")) {
            // line 182
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, ($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "service_fee", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "currency", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t(";
            // line 183
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice(($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "service_fee", array())), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 184
($context["order"] ?? null), "currency", array()) == "LTC")) {
            // line 185
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, ($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "service_fee", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "currency", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t(";
            // line 186
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice(($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "service_fee", array())), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 187
($context["order"] ?? null), "currency", array()) == "XMR")) {
            // line 188
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, ($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "service_fee", array())), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "currency", array()), "html", null, true);
            echo "\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t(";
            // line 189
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice(($this->getAttribute(($context["order"] ?? null), "price", array()) - $this->getAttribute(($context["order"] ?? null), "service_fee", array())), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo ")
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 191
        echo "\t\t\t\t\t\t\t\t\t\t</strong>
\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t</table>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t  <a name=\"info\"></a>
\t\t\t\t<ul class=\"nav nav-tabs\">
\t\t\t\t\t<li class=\"";
        // line 204
        echo ((( !$this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "show"), "method") == "pgp")) ? ("active") : (""));
        echo "\">
\t\t\t\t\t\t<a href=\"/account/orders/";
        // line 205
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "hash", array()), "html", null, true);
        echo "#info\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_buyer_info1")), "html", null, true);
        echo "</a>
\t\t\t\t\t</li>
\t\t\t\t\t<li class=\"";
        // line 207
        echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "show"), "method") == "pgp")) ? ("active") : (""));
        echo "\">
\t\t\t\t\t\t<a href=\"/account/orders/";
        // line 208
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "hash", array()), "html", null, true);
        echo "?show=pgp#info\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_buyer_info2")), "html", null, true);
        echo "</a>
\t\t\t\t\t</li>
\t\t\t\t</ul><br><br><br>
\t\t\t\t";
        // line 211
        if (( !$this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "show"), "method") == "pgp")) {
            // line 212
            echo "\t\t\t\t\t<table class=\"table\" style=\"margin: 0;width: 50%;float: left;\">
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<th style=\"border: 0;\">";
            // line 215
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_buyer_info3")), "html", null, true);
            echo "</th>
\t\t\t\t\t\t\t\t<td style=\"border: 0;\">";
            // line 216
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "normal_orders", array()), "count", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<th>";
            // line 219
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_sales_processed")), "html", null, true);
            echo " (%)</th>
\t\t\t\t\t\t\t\t<td>";
            // line 220
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "disputesBuyer", array()), "count", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t(";
            // line 221
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (($this->getAttribute($this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "disputesBuyer", array()), "count", array()) / $this->getAttribute($this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "normal_orders", array()), "count", array())) * 100), 2), "html", null, true);
            echo "% )</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>
\t\t\t\t\t";
            // line 225
            $context["totalSpending"] = (($this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "getBitcoinTotalSpends", array(), "method"), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())) + $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "getLitecoinTotalSpends", array(), "method"), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array()))) + $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "getMoneroTotalSpends", array(), "method"), $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())));
            // line 226
            echo "\t\t\t\t\t<table class=\"table\" style=\"margin: 0;width: 50%;float: left;\">
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<th style=\"border: 0;\">";
            // line 229
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_buyer_info4")), "html", null, true);
            echo "</th>
\t\t\t\t\t\t\t\t<td style=\"border: 0;\">";
            // line 230
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["totalSpending"] ?? null), 2), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<th>";
            // line 233
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_buyer_info5")), "html", null, true);
            echo "</th>
\t\t\t\t\t\t\t\t<td>";
            // line 234
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (($context["totalSpending"] ?? null) / $this->getAttribute($this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "normal_orders", array()), "count", array())), 2), "html", null, true);
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t</table>
\t\t\t\t";
        } else {
            // line 240
            echo "\t\t\t\t\t<textarea class=\"form-control\" readonly=\"readonly\" style=\"height:640px;\" cols=\"50\" rows=\"10\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["order"] ?? null), "user", array()), "pgp_key", array()), "html", null, true);
            echo "</textarea>
\t\t\t\t";
        }
        // line 242
        echo "
\t\t\t</div>
\t\t</div>
\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t<section class=\"l-body-content mp-Card-block\" style=\"margin: 50px 0; background-color: #EDECED;\">
\t\t\t\t\t<div class=\"section description\">
\t\t\t\t\t\t<div id=\"vip-description\" class=\"\">
\t\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 251
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_shippingornote")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t<textarea class=\"form-control\" readonly=\"readonly\" style=\"height:440px;\" cols=\"50\" rows=\"10\">";
        // line 253
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "shipping_address", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</section>

\t\t\t";
        // line 258
        if ($this->getAttribute(($context["order"] ?? null), "autodispatch", array())) {
            // line 259
            echo "\t\t\t\t<section class=\"l-body-content mp-Card-block\" style=\"margin: 50px 0; background-color: #EDECED;\">
\t\t\t\t\t<div class=\"section description\">
\t\t\t\t\t\t<div id=\"vip-description\" class=\"\">
\t\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
            // line 263
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_dispatch_notes")), "html", null, true);
            echo "</b>
\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t<textarea style=\"height:150px;background-color:#F5F7FA;\" readonly=\"readonly\" class=\"mp-Textarea \" disabled>";
            // line 265
            echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "autodispatch", array()), "html", null, true);
            echo "</textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</section>
\t\t\t";
        }
        // line 270
        echo "\t\t\t\t

\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t<b>";
        // line 273
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_seller_note")), "html", null, true);
        echo "</b>
\t\t\t\t</h2>

\t\t\t\t<form method=\"POST\" action=\"";
        // line 276
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.orders.update", ($context["order"] ?? null)));
        echo "\">
\t\t\t\t\t<div class=\"form-field form-textarea\">
\t\t\t\t\t\t<textarea style=\"height:150px;\" class=\"mp-Textarea ";
        // line 278
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "message"), "method")) ? (" invalid") : (""));
        echo "\" id=\"notes\" name=\"notes\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "notes", array()), "html", null, true);
        echo "</textarea>
\t\t\t\t\t</div>
\t\t\t\t\t";
        // line 280
        echo csrf_field();
        echo "
\t\t\t\t\t";
        // line 281
        if (($this->getAttribute(($context["order"] ?? null), "status", array()) == "processing")) {
            // line 282
            echo "\t\t\t\t\t\t<button type=\"submit\" name=\"status\" value=\"accept\" style=\"margin-bottom:3px;margin-left:5px;float:right;\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t<span>";
            // line 283
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_accept")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t</button>
\t\t\t\t\t\t<button type=\"submit\" name=\"status\" value=\"cancel\" style=\"margin-bottom:3px;margin-left:5px;float:right;background-color:red;\" class=\"mp-Button mp-Button--dangerous mp-Button--lg\">
\t\t\t\t\t\t\t<span>";
            // line 286
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_cancel")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t</button>
\t\t\t\t\t";
        } elseif (($this->getAttribute(        // line 288
($context["order"] ?? null), "status", array()) == "accepted")) {
            // line 289
            echo "\t\t\t\t\t\t<button type=\"submit\" name=\"status\" value=\"shipped\" style=\"margin-bottom:3px;margin-left:5px;float:right;\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t<span>";
            // line 290
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_mark_shipped")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t</button>
\t\t\t\t\t\t<button type=\"submit\" name=\"status\" value=\"cancel\" style=\"margin-bottom:3px;margin-left:5px;float:right;background-color:red;\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t<span>";
            // line 293
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_cancel")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t</button>
\t\t\t\t\t";
        }
        // line 296
        echo "
\t\t\t\t\t<button type=\"submit\" name=\"status\" value=\"sellernotes\" style=\"margin-bottom:3px;margin-left:5px;float:right;\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t<span>";
        // line 298
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_sale_update_seller_note")), "html", null, true);
        echo "</span>
\t\t\t\t\t</button>

\t\t\t\t</form>


\t\t\t\t<a href=\"/account/orders\" style=\"margin-bottom:3px;margin-left:5px;float:right;\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t<span>";
        // line 305
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_listings_go_back")), "html", null, true);
        echo "</span>
\t\t\t\t</a>
\t\t\t</div>
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/orders/show.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  778 => 305,  768 => 298,  764 => 296,  758 => 293,  752 => 290,  749 => 289,  747 => 288,  742 => 286,  736 => 283,  733 => 282,  731 => 281,  727 => 280,  720 => 278,  715 => 276,  709 => 273,  704 => 270,  696 => 265,  691 => 263,  685 => 259,  683 => 258,  675 => 253,  670 => 251,  659 => 242,  653 => 240,  643 => 234,  639 => 233,  632 => 230,  628 => 229,  623 => 226,  621 => 225,  614 => 221,  610 => 220,  606 => 219,  600 => 216,  596 => 215,  591 => 212,  589 => 211,  581 => 208,  577 => 207,  570 => 205,  566 => 204,  551 => 191,  545 => 189,  538 => 188,  536 => 187,  531 => 186,  524 => 185,  522 => 184,  517 => 183,  510 => 182,  508 => 181,  501 => 177,  495 => 173,  489 => 171,  485 => 170,  480 => 169,  478 => 168,  473 => 167,  469 => 166,  464 => 165,  462 => 164,  457 => 163,  453 => 162,  448 => 161,  446 => 160,  438 => 157,  431 => 152,  425 => 150,  423 => 149,  420 => 148,  414 => 146,  412 => 145,  409 => 144,  403 => 142,  400 => 141,  394 => 139,  391 => 138,  388 => 137,  383 => 135,  379 => 134,  375 => 133,  369 => 132,  363 => 130,  361 => 129,  356 => 128,  353 => 127,  347 => 124,  343 => 123,  339 => 122,  335 => 121,  331 => 120,  327 => 119,  323 => 118,  319 => 117,  314 => 116,  311 => 115,  305 => 112,  301 => 111,  297 => 110,  293 => 109,  289 => 108,  285 => 107,  281 => 106,  277 => 105,  272 => 104,  270 => 103,  261 => 97,  257 => 96,  252 => 93,  242 => 91,  240 => 90,  231 => 89,  229 => 88,  220 => 87,  218 => 86,  210 => 81,  204 => 78,  196 => 73,  192 => 72,  188 => 71,  180 => 65,  174 => 62,  171 => 61,  168 => 60,  162 => 57,  159 => 56,  156 => 55,  150 => 52,  147 => 51,  144 => 50,  138 => 47,  135 => 46,  132 => 45,  126 => 42,  123 => 41,  121 => 40,  114 => 38,  110 => 37,  106 => 36,  100 => 35,  96 => 34,  92 => 33,  88 => 32,  77 => 24,  68 => 20,  62 => 16,  59 => 15,  52 => 11,  47 => 8,  45 => 7,  42 => 6,  39 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/orders/show.twig", "");
    }
}
