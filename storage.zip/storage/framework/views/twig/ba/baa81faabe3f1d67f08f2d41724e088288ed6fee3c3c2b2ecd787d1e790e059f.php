<?php

/* /var/www/html/html/resources/themes/default/account/tickets/create.twig */
class __TwigTemplate_c482303c8f4ef97d6b329127aebc0dc1feefdc4dcdab80f170753feac2ec6e6a extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/tickets/create.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/account_support.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_user_area($context, array $blocks = array())
    {
        // line 7
        echo "\t<div id=\"content\">
\t\t";
        // line 8
        $this->loadTemplate("account.head_support.twig", "/var/www/html/html/resources/themes/default/account/tickets/create.twig", 8)->display($context);
        // line 9
        echo "\t\t<div style=\"margin-bottom: 50%;\" class=\"mp-Card mp-Card--rounded\">
\t\t\t<div class=\"mp-Card-block\">
            ";
        // line 11
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 12
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 15
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method");
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t";
        }
        // line 19
        echo "\t\t\t\t<form method=\"POST\" action=\"";
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.create.ticket"));
        echo "\" accept-charset=\"UTF-8\">
\t\t\t\t\t\t\t";
        // line 20
        echo csrf_field();
        echo "
\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t\t<b>If you request the 'Vendorship' it is mandatory to have a PGP key. The message must also be signed.</b>
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 25
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_username")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<input type=\"text\"  class=\"mp-Input \" value=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
        echo "\" disabled>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 32
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_subject")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 34
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_subject_text")), "html", null, true);
        echo " </span>
\t\t\t\t\t\t\t<input type=\"text\" name=\"title\" id=\"title\" class=\"mp-Input ";
        // line 35
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "title"), "method")) ? (" invalid") : (""));
        echo "\" value=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("title")), "html", null, true);
        echo "\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_categories")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
                        \t<div class=\"mp-Select category-select-l1 show\">
\t\t\t\t\t\t\t\t<select class=\"";
        // line 42
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "category"), "method")) ? (" invalid") : (""));
        echo "\" name=\"category\">
\t\t\t\t\t\t\t\t\t<option value=\"\"></option>
\t\t\t\t\t\t\t\t\t<option value=\"1\" ";
        // line 44
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == 1)) ? ("selected") : (""));
        echo ">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_cat_1")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"2\" ";
        // line 45
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == 2)) ? ("selected") : (""));
        echo ">>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_cat_2")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"3\" ";
        // line 46
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == 3)) ? ("selected") : (""));
        echo ">>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_cat_3")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"4\" ";
        // line 47
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == 4)) ? ("selected") : (""));
        echo ">>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_cat_4")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"6\" ";
        // line 48
        echo ((((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == 6) || ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", array()), "query", array(0 => "t"), "method") == "vendor"))) ? ("selected") : (""));
        echo ">>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_cat_5")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t\t<option value=\"5\" ";
        // line 49
        echo (((call_user_func_array($this->env->getFunction('old')->getCallable(), array("category")) == 5)) ? ("selected") : (""));
        echo ">>";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_cat_6")), "html", null, true);
        echo "</option>
\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t
                      <div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 56
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_message")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 58
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_ticket_message_text")), "html", null, true);
        echo " </span>
\t\t\t\t\t\t\t<textarea style=\"height:150px;\" class=\"mp-Textarea ";
        // line 59
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "text"), "method")) ? (" invalid") : (""));
        echo " \" id=\"text\" name=\"text\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('old')->getCallable(), array("text")), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>


\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>Captcha</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<img style=\"margin:5px;\" src=\"/captcha.html\">
\t\t\t\t\t\t\t<input type=\"text\" name=\"captcha\" id=\"captcha\" class=\"mp-Input ";
        // line 68
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
        echo " \" value=\"\">
\t\t\t\t\t\t</div>


\t\t\t\t\t\t<div style=\"margin-top:5px;\" class=\"form-field\">
\t\t\t\t\t\t\t<button id=\"confirm-profile\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t<span>";
        // line 74
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_submit")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<a id=\"cancel-profile\" href=\"/account/tickets\" class=\"secondary medium mp-Button mp-Button--secondary\">
\t\t\t\t\t\t\t\t<span>";
        // line 77
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_cancel")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/tickets/create.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  200 => 77,  194 => 74,  185 => 68,  171 => 59,  167 => 58,  162 => 56,  150 => 49,  144 => 48,  138 => 47,  132 => 46,  126 => 45,  120 => 44,  115 => 42,  109 => 39,  100 => 35,  96 => 34,  91 => 32,  83 => 27,  78 => 25,  70 => 20,  65 => 19,  58 => 15,  53 => 12,  51 => 11,  47 => 9,  45 => 8,  42 => 7,  39 => 6,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/tickets/create.twig", "");
    }
}
