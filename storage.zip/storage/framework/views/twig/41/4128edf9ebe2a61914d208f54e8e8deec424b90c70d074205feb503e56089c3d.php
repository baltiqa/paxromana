<?php

/* /var/www/html/html/resources/themes/default/account/resetwithdrawPIN.twig */
class __TwigTemplate_fe2fa6cbca63e05429b44098df595e0e89b107253948621d4ff81b42fb97cdf6 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/resetwithdrawPIN.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/extra.css\" rel=\"stylesheet\">
\t<style>
\t.form-field {
\t\tmargin-bottom: 20px;
\t}

\t</style>
";
    }

    // line 12
    public function block_user_area($context, array $blocks = array())
    {
        // line 13
        echo "\t<section id=\"content\">
\t\t";
        // line 14
        $this->loadTemplate("account.head_normal_bar.twig", "/var/www/html/html/resources/themes/default/account/resetwithdrawPIN.twig", 14)->display($context);
        // line 15
        echo "\t\t<div class=\"profile canvas\" id=\"edit-email-panel\">
\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t";
        // line 18
        if ($this->getAttribute(($context["errors"] ?? null), "any", array(), "method")) {
            // line 19
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["errors"] ?? null), "all", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 23
                echo "\t\t\t\t\t\t\t\t\t<li>";
                echo twig_escape_filter($this->env, $context["error"], "html", null, true);
                echo "</li>
\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 28
        echo "
\t\t\t\t\t";
        // line 29
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 30
            echo "\t\t\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 37
        echo "
\t\t\t\t\t";
        // line 38
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 39
            echo "\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 46
        echo "
\t\t\t\t\t";
        // line 47
        echo call_user_func_array($this->env->getFunction('form_model')->getCallable(), array("model", ($context["user"] ?? null), array("url" => call_user_func_array($this->env->getFunction('route')->getCallable(), array("account.reset.withdrawpin")), "files" => true)));
        echo "

\t\t\t\t\t<div class=\"edit-profile-block clear-fix\">
\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 52
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_username")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<input type=\"text\" class=\"mp-Input\" value=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "username", array()), "html", null, true);
        echo "\" disabled=\"disabled\">
\t\t\t\t\t\t</div>


\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 60
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.mnemonic_mnemonic")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 62
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_reset_withdraw")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input type=\"text\" name=\"mnemonic\" id=\"mnemonic\" class=\"mp-Input ";
        // line 63
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "mnemonic"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<hr>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 70
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_2")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 72
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_2_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input type=\"password\" name=\"pin\" id=\"pin\" class=\"mp-Input ";
        // line 73
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "pin"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\" maxlength=\"6\">
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>";
        // line 78
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_3")), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 80
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_pin_3_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<input type=\"password\" name=\"pin_confirmation\" id=\"pin_confirmation\" class=\"mp-Input ";
        // line 81
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "pin_confirmation"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\" maxlength=\"6\">
\t\t\t\t\t\t</div>
\t\t\t\t\t
\t\t\t\t\t\t<hr>

\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<h3 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t<b>Captcha</b>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<span class=\"help-block\">";
        // line 90
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.login_captcha_text")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<img style=\"margin:5px;\" src=\"/captcha.html\"/>
\t\t\t\t\t\t\t<input type=\"text\" name=\"captcha\" id=\"captcha\" class=\"mp-Input ";
        // line 92
        echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "captcha"), "method")) ? (" invalid") : (""));
        echo "\" value=\"\">
\t\t\t\t\t\t</div>


\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t<button id=\"confirm-profile\" class=\"primary medium mp-Button mp-Button--primary\">
\t\t\t\t\t\t\t\t<span>";
        // line 98
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_save")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t<a id=\"cancel-profile\" href=\"/account/edit_profile\" class=\"secondary medium mp-Button mp-Button--secondary\" _size=\"lg\">
\t\t\t\t\t\t\t\t<span>";
        // line 101
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_cancel")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t";
        // line 105
        echo call_user_func_array($this->env->getFunction('form_close')->getCallable(), array("close"));
        echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>


";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/resetwithdrawPIN.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 105,  219 => 101,  213 => 98,  204 => 92,  199 => 90,  187 => 81,  183 => 80,  178 => 78,  170 => 73,  166 => 72,  161 => 70,  151 => 63,  147 => 62,  142 => 60,  133 => 54,  128 => 52,  120 => 47,  117 => 46,  110 => 42,  105 => 39,  103 => 38,  100 => 37,  93 => 33,  88 => 30,  86 => 29,  83 => 28,  78 => 25,  69 => 23,  65 => 22,  60 => 19,  58 => 18,  53 => 15,  51 => 14,  48 => 13,  45 => 12,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/resetwithdrawPIN.twig", "");
    }
}
