<?php

/* /var/www/html/html/resources/themes/default/browse/index.twig */
class __TwigTemplate_fdeb7c616e1ab66a848c5411a046eeb98715d95ea980bcb12b5ff69c439b8a0a extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/browse/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/index.css\" rel=\"stylesheet\">
<style>
.mp-Listing-card-image {
    height:500px;
}
</style>

";
    }

    // line 13
    public function block_content($context, array $blocks = array())
    {
        // line 14
        echo "\t<div class=\"wide-layout\" id=\"page-wrapper\">
\t\t<div class=\"l-page indexpage\" id=\"content\">
\t\t\t<section class=\"l-side-left\" id=\"left-column\">
\t\t\t\t <div class=\"mp-Card\" id=\"navigation\">
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<div class=\"navigation-block\">
\t\t\t\t\t\t\t\t<h3 class=\"heading linetext\">
\t\t\t\t\t\t\t\t<span class=\"main-label\">";
        // line 21
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_category")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<ul class=\"list-menu\" id=\"navigation-categories\">
\t\t\t\t\t\t\t\t";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["categories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["parent_category"]) {
            // line 25
            echo "\t\t\t\t\t\t\t\t\t";
            if (($this->getAttribute($context["parent_category"], "parent_id", array()) == 0)) {
                // line 26
                echo "\t\t\t\t\t\t\t\t\t<li class=\"link\">
\t\t\t\t\t\t\t\t\t\t<a href=\"/category/";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($context["parent_category"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["parent_category"], "name", array()), "html", null, true);
                echo "<span style=\"color:black;\">(";
                echo twig_escape_filter($this->env, $this->getAttribute($context["parent_category"], "total_listings", array()), "html", null, true);
                echo ")</span></a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t ";
            }
            // line 31
            echo "\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['parent_category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t<div class=\"mp-Card side\" id=\"navigation\">
\t\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t\t<div class=\"navigation-block\">
\t\t\t\t\t\t\t\t<h3 class=\"heading linetext\">
\t\t\t\t\t\t\t\t<span class=\"main-label\">";
        // line 41
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_news")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</h3>
\t\t\t\t\t\t\t<ul class=\"list-menu\" id=\"navigation-categories\">
\t\t\t\t\t\t\t\t";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["news"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["featured_news"]) {
            // line 45
            echo "\t\t\t\t\t\t\t\t\t\t<li class=\"link\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/wiki#featured-";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["featured_news"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["featured_news"], "title", array()), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['featured_news'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"mp-Card side\" id=\"navigation\">
\t\t\t\t\t   <div class=\"mp-Card-block\">
\t\t\t\t\t\t\t<div class=\"handigeLinks\" id=\"highlights\">
\t\t\t\t\t\t\t\t<div class=\"navigation-block\">
\t\t\t\t\t\t\t\t<h3 class=\"heading linetext\">
\t\t\t\t\t\t\t\t\t\t";
        // line 58
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_rates")), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t\t\t";
        // line 59
        $this->loadTemplate("category.rate.twig", "/var/www/html/html/resources/themes/default/browse/index.twig", 59)->display($context);
        // line 60
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</section>
\t\t\t\t<section class=\"l-main-right\">
\t\t\t\t\t<div class=\"feed\">
\t\t\t\t\t\t<div class=\"feed-content\">
\t\t\t\t\t\t\t<div class=\"mp-Card mp-Card--rounded headproduct\">
\t\t\t\t\t\t\t\t<h3 class=\"feed-tab mp-Tab\">=";
        // line 69
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_featured")), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t\t<div class=\"mp-Card-trevor\">
\t\t\t\t\t\t\t\t\t";
        // line 71
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["listingAds"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 72
            echo "\t\t\t\t\t\t\t\t\t       ";
            if (($this->getAttribute($context["item"], "spotlight", array()) > twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                // line 73
                echo "\t\t\t\t\t\t\t\t\t\t\t<article style=\"height: 350px;\" class=\"mp-Listing-card feed-item\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-card-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"mp-Listing-card-clickable-container\" href=\"";
                // line 75
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["item"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["item"], "title", array()))))));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<figure class=\"mp-Listing-card-image\" style=\"height: 250px; background-image: url('";
                // line 76
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getPhoto", array(), "method"), "html", null, true);
                echo "')\"></figure>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-card-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"mp-Listing-card-title\">";
                // line 78
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                echo "</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-card-price\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"price-old\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 81
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["item"], "price", array()), $this->getAttribute($context["item"], "currency", array())), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"font-size: 12px;\"><span class=\"mp-Icon mp-svg-website-grey\"></span>";
                // line 82
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipped_from", array()), "html", null, true);
                echo "&#10230;
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 83
                echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["item"], "countryNames", array(), "method"), 0, 36), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-label\">";
                // line 86
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "(";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "user", array()), "orders", array()), "count", array()), "html", null, true);
                echo ") (";
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute($context["item"], "user", array()), "averageRate", array(), "method") == 0)) ? ("5.0") : (twig_number_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "averageRate", array(), "method"), 2))), "html", null, true);
                echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5 frontpage\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>)
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 90
                if (($this->getAttribute($context["item"], "payment_type_id", array()) == "1")) {
                    // line 91
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-escrow\">Escrow</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 92
$context["item"], "payment_type_id", array()) == 4)) {
                    // line 93
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-escrow\">Multisig 2/3</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 94
$context["item"], "payment_type_id", array()) == 2)) {
                    // line 95
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-fe\">";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_no_escrow")), "html", null, true);
                    echo "</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 97
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 102
            echo "\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"mp-Card mp-Card--rounded headproduct\">
\t\t\t\t\t\t\t\t<h3  class=\"heading feed-tab mp-Tab  \">=";
        // line 106
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_random")), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"mp-Card-trevor\">
\t\t\t\t\t\t\t\t\t";
        // line 109
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["listingsRandom"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 110
            echo "\t\t\t\t\t\t\t\t\t\t ";
            if (($this->getAttribute($context["item"], "spotlight", array()) < twig_date_format_filter($this->env, "now", "Y-m-d H:i:s"))) {
                // line 111
                echo "\t\t\t\t\t\t\t\t\t\t\t<article class=\"mp-Listing-card feed-item\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-card-body\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=\"mp-Listing-card-clickable-container\" href=\"";
                // line 113
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["item"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["item"], "title", array()))))));
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<figure class=\"mp-Listing-card-image\" style=\"background-image: url('";
                // line 114
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getPhoto", array(), "method"), "html", null, true);
                echo "')\"></figure>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Listing-card-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h4 class=\"mp-Listing-card-title\">";
                // line 116
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                echo "</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Listing-card-price\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"price-old\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 119
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["item"], "price", array()), $this->getAttribute($context["item"], "currency", array())), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                echo "</span><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span style=\"font-size: 12px;\"><span class=\"mp-Icon mp-svg-website-grey\"></span> ";
                // line 120
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "shipped_from", array()), "html", null, true);
                echo "&#10230;
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 121
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "countryNames", array(), "method"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-label\">";
                // line 125
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "username", array()), "html", null, true);
                echo "(";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "user", array()), "orders", array()), "count", array()), "html", null, true);
                echo ") (";
                echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute($context["item"], "user", array()), "averageRate", array(), "method") == 0)) ? ("5.0") : (twig_number_format_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "user", array()), "averageRate", array(), "method"), 2))), "html", null, true);
                echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5 frontpage\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>)
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</p>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 130
                if (($this->getAttribute($context["item"], "payment_type_id", array()) == "1")) {
                    // line 131
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-escrow\">Escrow</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 132
$context["item"], "payment_type_id", array()) == 4)) {
                    // line 133
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-escrow\">Multisig 2/3</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 134
$context["item"], "payment_type_id", array()) == 2)) {
                    // line 135
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p class=\"card-fe\">";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.browse_no_escrow")), "html", null, true);
                    echo "</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 137
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 142
            echo "\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 143
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</section>
\t\t\t</div>
\t\t</div>


\t";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/browse/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  339 => 143,  333 => 142,  326 => 137,  320 => 135,  318 => 134,  315 => 133,  313 => 132,  310 => 131,  308 => 130,  296 => 125,  289 => 121,  285 => 120,  279 => 119,  273 => 116,  268 => 114,  264 => 113,  260 => 111,  257 => 110,  253 => 109,  247 => 106,  242 => 103,  236 => 102,  229 => 97,  223 => 95,  221 => 94,  218 => 93,  216 => 92,  213 => 91,  211 => 90,  200 => 86,  194 => 83,  190 => 82,  184 => 81,  178 => 78,  173 => 76,  169 => 75,  165 => 73,  162 => 72,  158 => 71,  153 => 69,  142 => 60,  140 => 59,  136 => 58,  125 => 49,  114 => 46,  111 => 45,  107 => 44,  101 => 41,  90 => 32,  84 => 31,  73 => 27,  70 => 26,  67 => 25,  63 => 24,  57 => 21,  48 => 14,  45 => 13,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/browse/index.twig", "");
    }
}
