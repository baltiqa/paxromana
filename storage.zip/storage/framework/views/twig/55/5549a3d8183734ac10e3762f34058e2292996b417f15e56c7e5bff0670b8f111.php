<?php

/* /var/www/html/html/resources/themes/default/checkout/index.twig */
class __TwigTemplate_084aead9f6fc6aa4d55510b3aac3a57e18c3ab94f93959cf3e5ab9af6e7a789d extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/checkout/index.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_css($context, array $blocks = array())
    {
        // line 4
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/product_info.css\" rel=\"stylesheet\">
";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "\t<div id=\"page-wrapper\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t\t";
        // line 10
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 11
            echo "\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method"), "html", null, true);
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t";
        }
        // line 18
        echo "\t\t\t<h1 class=\"page-header\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_title")), "html", null, true);
        echo "</h1>
\t\t\t<div class=\"mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"mp-Card-block\">
\t\t\t\t\t";
        // line 21
        if (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing"), "method") != null)) {
            // line 22
            echo "\t\t\t\t\t\t<form action=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("placing.order"));
            echo "\" method=\"post\">
\t\t\t\t\t\t\t";
            // line 23
            echo csrf_field();
            echo "
\t\t\t\t\t\t\t<div class=\"content\">
\t\t\t\t\t\t\t\t<div class=\"mp-Alert \" style=\"background-color:#F1F1E8;\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-info\"></span>
\t\t\t\t\t\t\t\t\t";
            // line 27
            if (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.payment_type_id"), "method") == 1)) {
                // line 28
                echo "\t\t\t\t\t\t\t\t\t\t<li>";
                echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_type1"));
                echo "</li>
\t\t\t\t\t\t\t\t\t";
            } elseif (($this->getAttribute($this->getAttribute(            // line 29
($context["app"] ?? null), "session", array()), "get", array(0 => "listing.payment_type_id"), "method") == 2)) {
                // line 30
                echo "\t\t\t\t\t\t\t\t\t\t<li>";
                echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_type2"));
                echo "</li>
\t\t\t\t\t\t\t\t\t";
            } elseif (($this->getAttribute($this->getAttribute(            // line 31
($context["app"] ?? null), "session", array()), "get", array(0 => "listing.payment_type_id"), "method") == 4)) {
                // line 32
                echo "\t\t\t\t\t\t\t\t\t\t<li>";
                echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_type3"));
                echo "</li>
\t\t\t\t\t\t\t\t\t";
            }
            // line 34
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<table class=\"checkoutt\">
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 37
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 39
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing"), "method"), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.title"), "method"))))));
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.title"), "method"), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 43
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_seller")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/profile/";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.user.username"), "method"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.user.username"), "method"), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 49
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_shipping_options")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.days"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 51
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item4")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.name"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t<span class=\"";
            // line 53
            echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 1)) ? ("btc20") : (((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 3)) ? ("xmr20") : ("ltc20"))));
            echo "\"></span>(";
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method"), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 54
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "/
\t\t\t\t\t\t\t\t\t\t\t";
            // line 55
            if (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 1)) {
                // line 56
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method"), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tBTC
\t\t\t\t\t\t\t\t\t\t\t";
            } elseif (($this->getAttribute($this->getAttribute(            // line 58
($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 3)) {
                // line 59
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method"), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tXMR
\t\t\t\t\t\t\t\t\t\t\t";
            } elseif (($this->getAttribute($this->getAttribute(            // line 61
($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 2)) {
                // line 62
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method"), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tLTC
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 64
            echo ")</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 67
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item1")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 68
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method"), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 69
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "/
\t\t\t\t\t\t\t\t\t\t\t";
            // line 70
            if (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 1)) {
                // line 71
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method"), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tBTC
\t\t\t\t\t\t\t\t\t\t\t";
            } elseif (($this->getAttribute($this->getAttribute(            // line 73
($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 3)) {
                // line 74
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method"), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tXMR
\t\t\t\t\t\t\t\t\t\t\t";
            } elseif (($this->getAttribute($this->getAttribute(            // line 76
($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 2)) {
                // line 77
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method"), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tLTC
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 80
            echo "\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 83
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 84
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "quantity"), "method"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 87
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item2")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 88
            echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 1)) ? ("Bitcoin (BTC)") : (((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 3)) ? ("Monero (XMR)") : ("Litecoin (LTC)"))));
            echo "<span class=\"";
            echo ((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 1)) ? ("btc20") : (((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 3)) ? ("xmr20") : ("ltc20"))));
            echo "\"></span>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 92
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item3")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 93
            echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method") * $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "quantity"), "method")) + $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method")), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t";
            // line 94
            echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t/
\t\t\t\t\t\t\t\t\t\t\t";
            // line 96
            if (($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 1)) {
                // line 97
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method") * $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "quantity"), "method")) + $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method")), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tBTC
\t\t\t\t\t\t\t\t\t\t\t";
            } elseif (($this->getAttribute($this->getAttribute(            // line 99
($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 3)) {
                // line 100
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method") * $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "quantity"), "method")) + $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method")), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tXMR
\t\t\t\t\t\t\t\t\t\t\t";
            } elseif (($this->getAttribute($this->getAttribute(            // line 102
($context["app"] ?? null), "session", array()), "get", array(0 => "payment_method"), "method") == 2)) {
                // line 103
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method") * $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "quantity"), "method")) + $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method")), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method"), "yes"), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\tLTC
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 106
            echo "\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 109
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_from")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 110
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.shipped_from"), "method"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>Escrow</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 114
            echo twig_escape_filter($this->env, (((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.payment_type_id"), "method") == 1) || ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.payment_type_id"), "method") == 4))) ? ("Yes 100% Escrow") : ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.payment_type.payment_name"), "method"))), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 117
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_class")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 118
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.listing_class.name"), "method"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t</table>


\t\t\t\t\t\t\t\t";
            // line 123
            if ((twig_length_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "address"), "method")) > 1)) {
                // line 124
                echo "\t\t\t\t\t\t\t\t\t<meta http-equiv=\"refresh\" content=\"5; URL=/checkout\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t\t\t\t\t\t<div>
\t\t\t\t\t\t\t\t\t\t\t";
                // line 128
                echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_multisigreceived"));
                echo "
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<b>";
                // line 131
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_item5")), "html", null, true);
                echo " : ";
                echo ((($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "CheckMultisig", array(0 => $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "address_address"), "method")), "method") == "pending")) ? ("Pending") : ("Paid"));
                echo "</b>
\t\t\t\t\t\t\t\t\t<section class=\"l-body-content mp-Card-block\" style=\"margin: 50px 0; background-color: #EDECED;\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section description\">
\t\t\t\t\t\t\t\t\t\t\t<div id=\"vip-description-multisig\" class=\"multisig\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 135
                if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "CheckMultisig", array(0 => $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "address_address"), "method")), "method") == "pending")) {
                    // line 136
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<b>";
                    // line 137
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_sent_exact")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i style=\"color:#EDA566;\">";
                    // line 138
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "btc_price"), "method"), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tBTC</i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t(";
                    // line 140
                    echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency((($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.price"), "method") * $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "quantity"), "method")) + $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "shipping_method.price"), "method")), $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.currency"), "method")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 141
                    echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetCurrency(), "html", null, true);
                    echo ") ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_to_this")), "html", null, true);
                    echo ":</b></br>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 143
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_delays")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t\t\t\t\t\t<div id=\"vip-ad-description\" class=\"wrapped\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 146
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "address"), "method"), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 149
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t<p>";
                    echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_received"));
                    echo "</p>
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 151
                echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t\t\t";
            }
            // line 155
            echo "
\t\t\t\t\t\t\t\t<section class=\"l-body-content mp-Card-block\" style=\"margin: 50px 0; background-color: #EDECED;\">
\t\t\t\t\t\t\t\t\t<div class=\"section description\">
\t\t\t\t\t\t\t\t\t\t<div id=\"vip-description\" class=\"\">
\t\t\t\t\t\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t\t\t\t<b>";
            // line 160
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_toc")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t<i style=\"color:#EDA566;\">";
            // line 161
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.user.username"), "method"), "html", null, true);
            echo "</i>
\t\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t\t\t\t\t<div id=\"vip-ad-description\" class=\"wrapped\">
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 165
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.user.terms_conditions"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</section>

\t\t\t\t\t\t\t\t<section class=\"l-body-content mp-Card-block\" style=\"margin: 50px 0; background-color: #EDECED;\">
\t\t\t\t\t\t\t\t\t<div class=\"section description\">
\t\t\t\t\t\t\t\t\t\t<div id=\"vip-description\" class=\"\">
\t\t\t\t\t\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t\t\t\t<b>PGP Key</b>
\t\t\t\t\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t\t\t\t\t<div style=\"word-wrap: break-word; white-space: pre-wrap; line-height: normal\" id=\"vip-ad-description\" class=\"wrapped\">
";
            // line 178
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.user.pgp_key"), "method"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</section>

\t\t\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t\t\t<b>";
            // line 185
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_shippingornote")), "html", null, true);
            echo "</b>
\t\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t\t\t<div class=\"form-field form-textarea\">
\t\t\t\t\t\t\t\t\t<textarea style=\"height:150px;\" class=\"mp-Textarea ";
            // line 188
            echo (($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "shipping"), "method")) ? (" invalid") : (""));
            echo "\" id=\"shipping\" name=\"shipping\" maxlength=\"10000\" data-maxlength=\"10000\"></textarea>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            // line 190
            if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "shipping"), "method")) {
                // line 191
                echo "\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
\t\t\t\t\t\t\t\t\t\t";
                // line 192
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_errorshipping")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            }
            // line 195
            echo "

\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"1\" name=\"encryption\" checked=\"checked\" disabled><label for=\"encryption\">";
            // line 197
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_address_encrypted")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t<b>";
            // line 198
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "listing.user.username"), "method"), "html", null, true);
            echo "</b>.
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t<input type=\"checkbox\" value=\"agremeent\" name=\"agremeent\"><label for=\"agreemenent\">";
            // line 201
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_termsofvendor")), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t";
            // line 203
            if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "agremeent"), "method")) {
                // line 204
                echo "\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
\t\t\t\t\t\t\t\t\t\t";
                // line 205
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_termsofvendor_error")), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            }
            // line 208
            echo "\t\t\t\t\t\t\t\t<br>


\t\t\t\t\t\t\t\t<button type=\"submit\" style=\"margin-bottom:3px;float:right;\" class=\"mp-Button mp-Button--primary mp-Button--lg\">
\t\t\t\t\t\t\t\t\t<span>";
            // line 212
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_now")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</form>
\t\t\t\t\t";
        } else {
            // line 217
            echo "\t\t\t\t\t\t<p style=\"height:800px;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.order_empty")), "html", null, true);
            echo "</p>

\t\t\t\t\t";
        }
        // line 220
        echo "\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/checkout/index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  518 => 220,  511 => 217,  503 => 212,  497 => 208,  491 => 205,  488 => 204,  486 => 203,  481 => 201,  475 => 198,  471 => 197,  467 => 195,  461 => 192,  458 => 191,  456 => 190,  451 => 188,  445 => 185,  435 => 178,  419 => 165,  412 => 161,  408 => 160,  401 => 155,  395 => 151,  389 => 149,  383 => 146,  377 => 143,  370 => 141,  366 => 140,  361 => 138,  357 => 137,  354 => 136,  352 => 135,  343 => 131,  337 => 128,  331 => 124,  329 => 123,  321 => 118,  317 => 117,  311 => 114,  304 => 110,  300 => 109,  295 => 106,  288 => 103,  286 => 102,  280 => 100,  278 => 99,  272 => 97,  270 => 96,  265 => 94,  261 => 93,  257 => 92,  248 => 88,  244 => 87,  238 => 84,  234 => 83,  229 => 80,  222 => 77,  220 => 76,  214 => 74,  212 => 73,  206 => 71,  204 => 70,  200 => 69,  196 => 68,  192 => 67,  187 => 64,  180 => 62,  178 => 61,  172 => 59,  170 => 58,  164 => 56,  162 => 55,  158 => 54,  152 => 53,  148 => 52,  144 => 51,  140 => 50,  136 => 49,  127 => 45,  122 => 43,  113 => 39,  108 => 37,  103 => 34,  97 => 32,  95 => 31,  90 => 30,  88 => 29,  83 => 28,  81 => 27,  74 => 23,  69 => 22,  67 => 21,  60 => 18,  53 => 14,  48 => 11,  46 => 10,  42 => 8,  39 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/checkout/index.twig", "");
    }
}
