<?php

/* account.head_wallet.twig */
class __TwigTemplate_940c4ecac0b8dbf368ce1f662d9a740c6ed6f72bcd95a9d649df2b27b1485c1c extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t <div class=\"mp-Topbar\">
                <section class=\"mp-Topbar-inner-wrapper\">
                    <div class=\"mp-Tab-bar \">
                       <a href=\"/account/wallet/btc\" class=\"mp-Tab ";
        // line 4
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "wallet_id"), "method") == 1)) ? ("is-selected") : (""));
        echo " \">
                        Bitcoin ";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "
                        </a>
                        <a href=\"/account/wallet/ltc\" class=\"mp-Tab ";
        // line 7
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "wallet_id"), "method") == 2)) ? ("is-selected") : (""));
        echo " \">
                        Litecoin ";
        // line 8
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "
                        </a>
                        <a href=\"/account/wallet/xmr\" class=\"mp-Tab ";
        // line 10
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "wallet_id"), "method") == 3)) ? ("is-selected") : (""));
        echo " \">
                        Monero ";
        // line 11
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.wallet_title")), "html", null, true);
        echo "
                        </a>
                    </div>
                </section>
        </div>";
    }

    public function getTemplateName()
    {
        return "account.head_wallet.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 11,  42 => 10,  37 => 8,  33 => 7,  28 => 5,  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "account.head_wallet.twig", "");
    }
}
