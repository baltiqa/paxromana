<?php

/* /var/www/html/html/resources/themes/default/listing/show.twig */
class __TwigTemplate_76a8c770d60297661a335f9595c53a69f3998e14785d9f367091e85f669a75bf extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts.app", "/var/www/html/html/resources/themes/default/listing/show.twig", 1);
        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts.app";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_css($context, array $blocks = array())
    {
        // line 3
        echo "\t<link href=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('setting')->getCallable(), array("url")), "html", null, true);
        echo "/web/css/product_info.css\" rel=\"stylesheet\">
";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "\t<div id=\"page-wrapper\" class=\"with-right-container\">
\t\t<div id=\"content\" class=\"l-page\">
\t\t\t";
        // line 8
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method")) {
            // line 9
            echo "\t\t\t\t<div id=\"msg-saved-seller\" class=\"mp-Alert mp-Alert--success\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-checkmark-circled-white\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t";
            // line 12
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "message"), "method");
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t";
        }
        // line 16
        echo "\t\t\t";
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method")) {
            // line 17
            echo "\t\t\t\t<div class=\"mp-Alert mp-Alert--error\">
\t\t\t\t\t<span class=\"mp-Alert-icon mp-svg-alert--inverse\"></span>
\t\t\t\t\t<div>
\t\t\t\t\t\t";
            // line 20
            echo $this->getAttribute($this->getAttribute(($context["app"] ?? null), "session", array()), "get", array(0 => "error"), "method");
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t";
        }
        // line 24
        echo "\t\t\t<nav id=\"vip-breadcrumbs-pagination\" class=\"minified\">
\t\t\t\t<div id=\"search-breadcrumbs-content\" class=\"search-breadcrumbs-content\">
\t\t\t\t\t<div class=\"mp-Nav-breadcrumb large\">
\t\t\t\t\t\t<a href=\"/category/";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "category", array()), "id", array()), "html", null, true);
        echo "\" class=\"backlink mp-Nav-breadcrumb-button mp-Button mp-Button--secondary mp-Button--xs\">
\t\t\t\t\t\t\t<span>";
        // line 28
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.see_other_result")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<a href=\"";
        // line 30
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("browse"));
        echo "\" class=\"mp-Nav-breadcrumb-item crumb\">
\t\t\t\t\t\t\t<span>";
        // line 31
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_home")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["breadcrumbs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["breadcrumb"]) {
            // line 34
            echo "\t\t\t\t\t\t\t<h2 class=\"mp-Nav-breadcrumb-item crumb\">
\t\t\t\t\t\t\t\t<a href=\"/category/";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["breadcrumb"], "id", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t<span>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["breadcrumb"], "name", array()), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['breadcrumb'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "
\t\t\t\t\t\t<h2 class=\"mp-Nav-breadcrumb-item crumb\">
\t\t\t\t\t\t\t<a href=\"/category/";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "category", array()), "id", array()), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t<span>";
        // line 43
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "category", array()), "name", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</h2>

\t\t\t\t\t\t";
        // line 47
        if ((call_user_func_array($this->env->getFunction('auth_check')->getCallable(), array()) && (($this->getAttribute(($context["listing"] ?? null), "user_id", array()) == $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "id", array())) || $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "can", array(0 => "edit listing"), "method")))) {
            // line 48
            echo "\t\t\t\t\t\t\t<div class=\"mb-3\">
\t\t\t\t\t\t\t\t<a href=\"";
            // line 49
            echo ((($this->getAttribute(($context["listing"] ?? null), "is_published", array()) != 1)) ? (call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.enable", ($context["listing"] ?? null)))) : (call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.disable", ($context["listing"] ?? null)))));
            echo "\">";
            echo ((($this->getAttribute(($context["listing"] ?? null), "is_published", array()) != 1)) ? ("Enable Listing") : ("Disable Listing"));
            echo "</a>
\t\t\t\t\t\t\t\t<strong class=\"badge badge-info\">
\t\t\t\t\t\t\t\t\t";
            // line 51
            echo twig_escape_filter($this->env, (($this->getAttribute(($context["listing"] ?? null), "is_published", array())) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_1"))) : (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_visibility_2")))), "html", null, true);
            echo "</strong>
\t\t\t\t\t\t\t\t<a class=\"badge badge-secondary\" href=\"";
            // line 52
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.edit", ($context["listing"] ?? null)));
            echo "\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_edit_title")), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        // line 55
        echo "\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</nav>
\t\t\t<section class=\"l-main-left \">
\t\t\t\t<section class=\"listing mp-Card mp-Card--rounded\">
\t\t\t\t\t<section class=\"l-top-content mp-Card-block\">
\t\t\t\t\t\t<section class=\"header clear-fix mp-Card-block container-view-desktop\">
\t\t\t\t\t\t\t<h1 id=\"title\" style=\"margin: 0;\" class=\"title\" title=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "</h1>
\t\t\t\t\t\t\t<div class=\"stats\">
\t\t\t\t\t\t\t   
\t\t\t\t\t\t\t    <span class=\"stat\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-browse\"></span>
\t\t\t\t\t\t\t\t\t<span id=\"view-count\" class=\"mp-hidden\">";
        // line 67
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "orders", array()), "count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span>";
        // line 68
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "orders", array()), "count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"sentence\">
\t\t\t\t\t\t\t\t\t\tx ";
        // line 70
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t<span class=\"stat\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-eye-open-grey\"></span>
\t\t\t\t\t\t\t\t\t<span id=\"view-count\" class=\"mp-hidden\">";
        // line 74
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "views_count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span>";
        // line 75
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "views_count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"sentence\">
\t\t\t\t\t\t\t\t\t\tx ";
        // line 77
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_views")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t<span class=\"stat\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-heart-grey\"></span>
\t\t\t\t\t\t\t\t\t<span id=\"favorited-count\" class=\"mp-hidden\">";
        // line 81
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "favoritesCount", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span>";
        // line 82
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "favoritesCount", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"sentence\">
\t\t\t\t\t\t\t\t\t\tx ";
        // line 84
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_saved")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t <span class=\"stat\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-shoppingcart\"></span>
\t\t\t\t\t\t\t\t\t<span id=\"view-count\" class=\"mp-hidden\">";
        // line 88
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["listing"] ?? null), "quantity", array()) == "-1")) ? ("8") : ($this->getAttribute(($context["listing"] ?? null), "quantity", array()))), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span>";
        // line 89
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["listing"] ?? null), "quantity", array()) == "-1")) ? ("8") : ($this->getAttribute(($context["listing"] ?? null), "quantity", array()))), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"sentence\">
\t\t\t\t\t\t\t\t\t\t";
        // line 91
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_stock")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t<span id=\"displayed-since\" class=\"stat\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-clock-grey\"></span>
\t\t\t\t\t\t\t\t\t<span class=\"sentence\">";
        // line 95
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_since")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t     \t<span>";
        // line 96
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "created_at", array()), "format", array(0 => "d-m-Y"), "method"), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<section class=\"top-actions-below\">
\t\t\t\t\t\t\t\t<form id=\"fav-form-top\" action=\"";
        // line 100
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.star", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "\" style=\"margin-right:10px;\">
\t\t\t\t\t\t\t\t\t<button id=\"fav-btn-top\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon mp-Button-icon--left mp-svg-heart-white\"></span>
\t\t\t\t\t\t\t\t\t\t";
        // line 103
        if ($this->getAttribute(($context["listing"] ?? null), "isFavorited", array(), "method")) {
            // line 104
            echo "\t\t\t\t\t\t\t\t\t\t\t<span class=\"text-label\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_remove_favo")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 106
            echo "\t\t\t\t\t\t\t\t\t\t\t<span class=\"text-label\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_add_favo")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 108
        echo "\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t<button style=\"color:black;\" id=\"fav-btn-top\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\" disabled>
\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon mp-Button-icon--left mp-svg-handshake\"></span>
\t\t\t\t\t\t\t\t\t<span class=\"text-label\">";
        // line 112
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "payment_type", array()), "payment_name", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t<button style=\"color:black;\" id=\"fav-btn-top\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\" disabled>
\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon mp-Button-icon--left ";
        // line 115
        echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "listing_class", array()), "id", array()) == 1)) ? ("mp-svg-postpackage") : ("mp-svg-digital"));
        echo "\"></span>
\t\t\t\t\t\t\t\t\t<span class=\"text-label\">";
        // line 116
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "listing_class", array()), "name", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</button>

\t\t\t\t\t\t\t</section>
\t\t\t\t\t\t</section>
\t\t\t\t\t\t<section class=\"gallery-container\">
\t\t\t\t\t\t\t<div id=\"vip-gallery\" class=\"\">
\t\t\t\t\t\t\t\t<div class=\"image-viewer-wrapper \">
\t\t\t\t\t\t\t\t\t<div id=\"vip-image-viewer\" class=\"image-viewer\">
\t\t\t\t\t\t\t\t\t\t<div class=\"image\">
\t\t\t\t\t\t\t\t\t\t\t<input class=\"listing-input\" type=\"radio\" id=\"img-1\" name=\"gallery\" checked=\"\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"listing-image\" href=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "getPhoto", array(), "method"), "html", null, true);
        echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t\t\t\t\t<img class=\"listing__gallery-img\" src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "getPhoto", array(), "method"), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t";
        // line 130
        if ($this->getAttribute(($context["listing"] ?? null), "photo2", array())) {
            // line 131
            echo "\t\t\t\t\t\t\t\t\t\t\t<input class=\"listing-input\" type=\"radio\" id=\"img-2\" name=\"gallery\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"listing-image\" href=\"";
            // line 132
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo2", array()), "html", null, true);
            echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t\t\t\t\t<img class=\"listing__gallery-img\" src=\"";
            // line 133
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo2", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 136
        echo "\t\t\t\t\t\t\t\t\t\t\t";
        if ($this->getAttribute(($context["listing"] ?? null), "photo3", array())) {
            // line 137
            echo "\t\t\t\t\t\t\t\t\t\t\t<input class=\"listing-input\" type=\"radio\" id=\"img-3\" name=\"gallery\">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"listing-image\" href=\"";
            // line 138
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo3", array()), "html", null, true);
            echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t\t\t\t\t<img class=\"listing__gallery-img\" src=\"";
            // line 139
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo3", array()), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 142
        echo "\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div id=\"vip-gallery-thumbs\">
\t\t\t\t\t\t\t\t\t<div id=\"vip-carousel\" class=\"carousel horizontal\" style=\"visibility: visible;\">
\t\t\t\t\t\t\t\t\t\t<div class=\"carousel-viewport\">
\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 148
        if (($this->getAttribute(($context["listing"] ?? null), "photo2", array()) || $this->getAttribute(($context["listing"] ?? null), "photo3", array()))) {
            // line 149
            echo "\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"listing-single\" for=\"img-1\"><img class=\"thumb-placeholder\" src=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "getPhoto", array(), "method"), "html", null, true);
            echo "\"></a></label>
\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 151
        echo "\t\t\t\t\t\t\t\t\t\t\t";
        if ($this->getAttribute(($context["listing"] ?? null), "photo2", array())) {
            // line 152
            echo "\t\t\t\t\t\t\t\t\t\t\t<label class=\"listing-single\" for=\"img-2\"><img class=\"thumb-placeholder\" src=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo2", array()), "html", null, true);
            echo "\"></a></label>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 154
        echo "
\t\t\t\t\t\t\t\t\t\t\t";
        // line 155
        if ($this->getAttribute(($context["listing"] ?? null), "photo3", array())) {
            // line 156
            echo "\t\t\t\t\t\t\t\t\t\t\t<label class=\"listing-single\" for=\"img-3\"><img class=\"thumb-placeholder\" src=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "photo3", array()), "html", null, true);
            echo "\"></a></label>
\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 158
        echo "
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div id=\"vip-action-block\">
\t\t\t\t\t<div class=\"vip-ad-price-container\">
\t\t\t\t\t\t<h3>Price</h3>
\t\t\t\t\t\t<span class=\"price \">";
        // line 166
        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute(($context["listing"] ?? null), "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array())), "html", null, true);
        echo "
\t\t\t\t\t\t\t";
        // line 167
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
        echo "</span><br><br>
\t\t\t\t\t\t<span style=\"font-size: 16px;font-weight:bold;\"><span class=\"mp-Icon mp-svg-website-grey\"></span>";
        // line 168
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_origin_country")), "html", null, true);
        echo ":</span>
\t\t\t\t\t\t";
        // line 169
        echo twig_escape_filter($this->env, $this->getAttribute(($context["ships_from"] ?? null), "country_name", array()), "html", null, true);
        echo "<br>
\t\t\t\t\t\t<span style=\"font-size: 16px;font-weight:bold;\"><span class=\"mp-Icon mp-svg-website-grey\"></span>";
        // line 170
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ships_to")), "html", null, true);
        echo ":</span>
\t\t\t\t\t\t";
        // line 171
        echo twig_escape_filter($this->env, ($context["ships_to"] ?? null), "html", null, true);
        echo "
\t\t\t\t\t</div>

\t\t\t\t</section>

\t\t\t\t
\t\t\t\t
\t\t\t\t<section class=\"header header-container title container-view-mobile\">
\t\t\t\t\t<div style=\"margin: 0;\" class=\"header-inline-price\">
\t\t\t\t\t\t<h1 id=\"title\"  title=\"";
        // line 180
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "title", array()), "html", null, true);
        echo "</h1>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"stats\">
\t\t\t\t\t    <span class=\"stat\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-browse\"></span>
\t\t\t\t\t\t\t\t\t<span id=\"view-count\" class=\"mp-hidden\">";
        // line 185
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "orders", array()), "count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span>";
        // line 186
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "orders", array()), "count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"sentence\">
\t\t\t\t\t\t\t\t\t\tx ";
        // line 188
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_views")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t
\t\t\t\t\t\t<span class=\"stat\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-eye-open-grey\"></span>
\t\t\t\t\t\t\t<span id=\"view-count\" class=\"mp-hidden\">";
        // line 193
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "views_count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<span>";
        // line 194
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "views_count", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<span class=\"sentence\">
\t\t\t\t\t\t\t\tx ";
        // line 196
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_store_sold")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span class=\"stat\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-heart-grey\"></span>
\t\t\t\t\t\t\t<span id=\"favorited-count\" class=\"mp-hidden\">";
        // line 200
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "favoritesCount", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<span>";
        // line 201
        echo twig_escape_filter($this->env, $this->getAttribute(($context["listing"] ?? null), "favoritesCount", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<span class=\"sentence\">
\t\t\t\t\t\t\t\tx ";
        // line 203
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_saved")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t <span class=\"stat\">
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-shoppingcart\"></span>
\t\t\t\t\t\t\t\t\t<span id=\"view-count\" class=\"mp-hidden\">";
        // line 207
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["listing"] ?? null), "quantity", array()) == "-1")) ? ("8") : ($this->getAttribute(($context["listing"] ?? null), "quantity", array()))), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span>";
        // line 208
        echo twig_escape_filter($this->env, ((($this->getAttribute(($context["listing"] ?? null), "quantity", array()) == "-1")) ? ("8") : ($this->getAttribute(($context["listing"] ?? null), "quantity", array()))), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t\t\t<span class=\"sentence\">
\t\t\t\t\t\t\t\t\t\t";
        // line 210
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_stock")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span id=\"displayed-since\" class=\"stat\">
\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-clock-grey\"></span>
\t\t\t\t\t\t\t<span class=\"sentence\">";
        // line 214
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_since")), "html", null, true);
        echo "</span>
\t\t\t\t\t\t\t<span>";
        // line 215
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "created_at", array()), "format", array(0 => "d-m-Y"), "method"), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</span>
\t\t\t\t\t</div>
\t\t\t\t\t<section class=\"top-actions-below\">
\t\t\t\t\t\t<form id=\"fav-form-topMobile\" action=\"";
        // line 219
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.star", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "\">
\t\t\t\t\t\t\t<button id=\"fav-btn-top-mobile\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon mp-Button-icon--left mp-svg-heart-white\"></span>
\t\t\t\t\t\t\t\t";
        // line 222
        if ($this->getAttribute(($context["listing"] ?? null), "isFavorited", array(), "method")) {
            // line 223
            echo "\t\t\t\t\t\t\t\t\t<span class=\"text-label\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_remove_favo")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t";
        } else {
            // line 225
            echo "\t\t\t\t\t\t\t\t\t<span class=\"text-label\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_add_favo")), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t";
        }
        // line 227
        echo "\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t</form>
\t\t\t\t\t\t<span class=\"mp-Button-icon mp-Button-icon--left mp-svg-handshake\"></span>
\t\t\t\t\t\t<span class=\"text-label\">";
        // line 230
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "payment_type", array()), "payment_name", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t\t<span class=\"mp-Button-icon mp-Button-icon--left ";
        // line 231
        echo ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "listing_class", array()), "id", array()) == 1)) ? ("mp-svg-postpackage") : ("mp-svg-digital"));
        echo "\"></span>
\t\t\t\t\t\t<span class=\"text-label\">";
        // line 232
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "listing_class", array()), "name", array()), "html", null, true);
        echo "</span>
\t\t\t\t\t</section>
\t\t\t\t</section>
\t\t\t\t
\t\t\t</section>
\t\t\t

\t\t\t<section class=\"l-body-content mp-Card-block\">
\t\t\t\t<div class=\"banner-position-mid\">
\t\t\t\t\t<div id=\"banner-vipmid-dt\" class=\"banner-vipmid\" style=\"display: none;\"></div>
\t\t\t\t</div>
\t\t\t\t<div class=\"section attributes\">
\t\t\t\t\t<div id=\"vip-ad-attributes\">
\t\t\t\t\t\t<div class=\"attribute-tables\">
\t\t\t\t\t\t\t<table class=\"first-column attribute-table single-value-attributes\"></table>
\t\t\t\t\t\t\t<table class=\"attribute-table multi-value-attributes\">
\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td class=\"name\">";
        // line 250
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_tags")), "html", null, true);
        echo "</td>
\t\t\t\t\t\t\t\t\t\t<td class=\"seperator\">:</td>
\t\t\t\t\t\t\t\t\t\t<td class=\"value\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 253
        if ($this->getAttribute(($context["listing"] ?? null), "tags", array())) {
            // line 254
            echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["tags"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["tag"]) {
                // line 255
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"tag\">";
                echo twig_escape_filter($this->env, $context["tag"], "html", null, true);
                echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tag'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 257
            echo "\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 258
        echo "\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"section description\">
\t\t\t\t\t<div id=\"vip-description\" class=\"\">
\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t";
        // line 268
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_description")), "html", null, true);
        echo "
\t\t\t\t\t\t</h2>
\t\t\t\t\t\t<div id=\"vip-ad-description\" class=\"wrapped\">
\t\t\t\t\t\t\t";
        // line 271
        echo nl2br(strip_tags(call_user_func_array($this->env->getFilter('xss_clean')->getCallable(), array(call_user_func_array($this->env->getFilter('bbc2html')->getCallable(), array($this->getAttribute(($context["listing"] ?? null), "description", array()))))), "<b>,<i>,<u>,<ul>,<li>,<span>,<h1><h2><h3>"));
        echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</section>
\t\t\t<section class=\"l-body-content mp-Card-block\" style=\"background-color:#EDECED;\">
\t\t\t\t<div class=\"section description\">
\t\t\t\t\t<div id=\"vip-description\" class=\"\">
\t\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t\t";
        // line 280
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_toc")), "html", null, true);
        echo "
\t\t\t\t\t\t\t<b>";
        // line 281
        echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "display_name", array()) != null)) ? ($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "display_name", array())) : ($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()))), "html", null, true);
        echo "</b>
\t\t\t\t\t\t</h2>
\t\t\t\t\t\t<div id=\"vip-ad-description\" class=\"wrapped\">
\t\t\t\t\t\t\t";
        // line 284
        echo nl2br(strip_tags(call_user_func_array($this->env->getFilter('xss_clean')->getCallable(), array(call_user_func_array($this->env->getFilter('bbc2html')->getCallable(), array($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "terms_conditions", array()))))), "<b>,<i>,<u>,<ul>,<li>,<span>,<h1><h2><h3>"));
        echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</section>
\t\t</section>
\t\t";
        // line 290
        if (($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "childs", array()), "count", array()) != null)) {
            // line 291
            echo "\t\t\t<div class=\"vip-soi mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"vip-soi-head mp-Card-block mp-Card-block--highlight\">
\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t";
            // line 294
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_also_available_in")), "html", null, true);
            echo "
\t\t\t\t\t</h2>
\t\t\t\t</div>
\t\t\t\t<div style=\"padding:5px 5px;\" class=\"vip-soi-body mp-Card-block\">
\t\t\t\t\t<ul style=\"width:100%\">
\t\t\t\t\t\t";
            // line 299
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["listing"] ?? null), "childs", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["listing_child"]) {
                // line 300
                echo "\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 302
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["listing_child"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["listing_child"], "title", array()))))));
                echo "\" title=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["listing_child"], "title", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["listing_child"], "title", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t<b style=\"float:right;\">";
                // line 303
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["listing_child"], "price", array()), $this->getAttribute($context["listing_child"], "currency", array())), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t";
                // line 304
                echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['listing_child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 308
            echo "\t\t\t\t\t</ul>
\t\t\t\t</div>
\t\t\t</div>
\t\t";
        } elseif (($this->getAttribute(        // line 311
($context["listing"] ?? null), "parent_id", array()) != 0)) {
            // line 312
            echo "\t\t\t<div class=\"vip-soi mp-Card mp-Card--rounded\">
\t\t\t\t<div class=\"vip-soi-head mp-Card-block mp-Card-block--highlight\">
\t\t\t\t\t<h2 class=\"heading heading-3\">
\t\t\t\t\t\t";
            // line 315
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_also_available_in")), "html", null, true);
            echo "
\t\t\t\t\t</h2>
\t\t\t\t</div>
\t\t\t\t<div style=\"padding:5px 5px;\" class=\"vip-soi-body mp-Card-block\">
\t\t\t\t\t<ul style=\"width:100%\">
\t\t\t\t\t\t";
            // line 320
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "parent", array()), "childs", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["listing_child"]) {
                // line 321
                echo "\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 323
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => $context["listing_child"], "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute($context["listing_child"], "title", array()))))));
                echo "\" title=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["listing_child"], "title", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["listing_child"], "title", array()), "html", null, true);
                echo "</a>
\t\t\t\t\t\t\t\t\t<b style=\"float:right;\">";
                // line 324
                echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["listing_child"], "price", array()), $this->getAttribute($context["listing_child"], "currency", array())), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t";
                // line 325
                echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['listing_child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 329
            echo "\t\t\t\t\t</ul>
\t\t\t\t</div>
\t\t\t</div>

\t\t";
        }
        // line 334
        echo "
\t\t<div class=\"mp-Card\">
\t\t\t<div class=\"mp-Card-block mp-Card-block--heading\" style=\"padding:15px;\">
\t\t\t\t<h3>";
        // line 337
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab3")), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["comments"] ?? null), "count", array()), "html", null, true);
        echo ")</h3>
\t\t\t</div>
\t\t\t";
        // line 339
        if (($this->getAttribute(($context["comments"] ?? null), "count", array()) == 0)) {
            // line 340
            echo "\t\t\t\t<article class=\"user-review mp-Card-block\">
\t\t\t\t\t";
            // line 341
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_no_rating")), "html", null, true);
            echo "
\t\t\t\t</article>
\t\t\t";
        } else {
            // line 344
            echo "\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["comments"] ?? null));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
                // line 345
                echo "\t\t\t\t\t<article class=\"user-review mp-Card-block\">
\t\t\t\t\t\t<header class=\"user-review-header\">
\t\t\t\t\t\t\t";
                // line 347
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "created_at", array()), "diffForHumans", array(0 => null, 1 => true, 2 => true), "method"), "html", null, true);
                echo "
\t\t\t\t\t\t\t<span class=\"mp-StarRating mp-StarRating--5 \">
\t\t\t\t\t\t\t\t";
                // line 349
                echo twig_include($this->env, $context, "components.star_rating", array("rating" => $this->getAttribute($context["comment"], "rating", array())));
                echo "
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t";
                // line 351
                echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["comment"], "comment", array()), 0, 25), "html", null, true);
                echo "
\t\t\t\t\t\t\t<span style=\"float:right;\" class=\"mp-text-meta\">";
                // line 352
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('filter_username')->getCallable(), array($this->getAttribute($this->getAttribute($context["comment"], "commenter", array()), "username", array()))), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t~
\t\t\t\t\t\t\t\t";
                // line 354
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "order", array()), "price", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t";
                // line 355
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "order", array()), "currency", array()), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t";
                // line 356
                if ($this->getAttribute($this->getAttribute($context["comment"], "commenter", array()), "trusted", array(), "method")) {
                    // line 357
                    echo "\t\t\t\t\t\t\t\t(<i style=\"color:#00CF72;font-weight:bold;\">";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_trusted_buyer")), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t<img title=\"verified\" width=\"16\" src=\"/web/images/check2.png\">)
\t\t\t\t\t\t\t\t";
                } else {
                    // line 360
                    echo "\t\t\t\t\t\t\t\t(<i style=\"color:red;font-weight:bold;\">";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_new_buyer")), "html", null, true);
                    echo "</i>)
\t\t\t\t\t\t\t\t";
                }
                // line 362
                echo "\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</header>
\t\t\t\t\t</article>
\t\t\t\t";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 366
            echo "\t\t\t";
        }
        // line 367
        echo "\t\t</div>


\t</section>
\t<aside class=\"l-side-right\">
\t\t<section class=\"contact-info mp-Card mp-Card--rounded\">
\t\t\t<div id=\"vip-seller\">
\t\t\t\t<div class=\"mp-Card-block mp-Card-block--custom-highlight\">
\t\t\t\t\t<div class=\"top-info\">
\t\t\t\t\t\t<div class=\"save-seller-button\">
\t\t\t\t\t\t\t<div id=\"save-seller\">
\t\t\t\t\t\t\t\t<form id=\"save-seller-form\" action=\"";
        // line 378
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing.follow", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "\">
\t\t\t\t\t\t\t\t\t<button id=\"save-seller-button\" class=\"button mp-Button mp-Button--secondary mp-Button--sm\" title=\"";
        // line 379
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_follow")), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t\t";
        // line 380
        if ($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "getIsFollowed", array(0 => $this->getAttribute(($context["listing"] ?? null), "user", array())), "method")) {
            // line 381
            echo "\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon mp-svg-following\"></span>
\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 383
            echo "\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon mp-svg-follow\"></span>
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 385
        echo "\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<a href=\"/profile/";
        // line 389
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t<h2 class=\"name mp-text-header3\" title=\"";
        // line 390
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t";
        // line 391
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "on_vacation", array()) == 1)) ? (call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_vacation"))) : ("")), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "orders", array()), "count", array()), "html", null, true);
        echo ") (";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "avg_rating", array(), "method"), "html", null, true);
        echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t<i></i>
\t\t\t\t\t\t\t\t</span>)
\t\t\t\t\t\t\t</h2>
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t\t<ul class=\"seller-info\">
\t\t\t\t\t\t<li id=\"vip-active-since\">
\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t<b>";
        // line 400
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "created_at", array()), "diffForHumans", array(0 => null, 1 => true), "method"), "html", null, true);
        echo "</b>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t";
        // line 402
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_activelong")), "html", null, true);
        echo " Pax Romana
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li id=\"vip-seller-all-ads\">
\t\t\t\t\t\t\t<a class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\" href=\"/profile/";
        // line 405
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "username", array()), "html", null, true);
        echo "/store\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab2")), "html", null, true);
        echo "</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<br>
\t\t\t\t\t\t* ";
        // line 408
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_acceptrules")), "html", null, true);
        echo "
\t\t\t\t\t</ul>
\t\t\t\t\t<div class=\"trust-indicator-group\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t<h3>";
        // line 412
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_vendorinfo")), "html", null, true);
        echo "</h3>
\t\t\t\t\t\t\t";
        // line 413
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "markets", array()), "count", array()) != null)) {
            // line 414
            echo "
\t\t\t\t\t\t\t";
            // line 415
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "markets", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["markets"]) {
                // line 416
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["markets"], "market_title", array()) == "Silk")) {
                    // line 417
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Silk Road\" src=\"/web/images/si.png\"/> 
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 421
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 422
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo "</i>/<i class=\"normal\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                    echo "</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 425
$context["markets"], "market_title", array()) == "Berlus")) {
                    // line 426
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Berlusconi Market\" src=\"/web/images/ber.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 430
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 431
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo "</i>/<i class=\"normal\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                    echo "</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 435
$context["markets"], "market_title", array()) == "Dream")) {
                    // line 436
                    echo "
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Dream Market\" src=\"/web/images/d.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 441
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t\t(<i class=\"normal\">";
                    // line 442
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "rate", array()), "html", null, true);
                    echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"smstar\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t\t\t\t\t\t\t</b>)</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 450
$context["markets"], "market_title", array()) == "Samsara")) {
                    // line 451
                    echo "
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"SamSara Market\" src=\"/web/images/samsara.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 456
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 457
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo "</i>/<i class=\"normal\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                    echo "</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>


\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 463
$context["markets"], "market_title", array()) == "Empire")) {
                    // line 464
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Empire Market\" src=\"/web/images/eeim.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 468
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 469
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo "</i>/<i class=\"normal\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                    echo "</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 474
$context["markets"], "market_title", array()) == "Cryptonia")) {
                    // line 475
                    echo "
\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Cryptonia Market\" src=\"/web/images/cd.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 480
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 481
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "percentage", array()), "html", null, true);
                    echo "%</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 485
$context["markets"], "market_title", array()) == "Nightmare")) {
                    // line 486
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Nightmare Market\" src=\"/web/images/nih.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 490
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 491
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo "</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 496
$context["markets"], "market_title", array()) == "Apollon")) {
                    // line 497
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Apollon Market\" src=\"/web/images/apol.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 501
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 502
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo "</i>/<i class=\"normal\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                    echo "</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 507
$context["markets"], "market_title", array()) == "Tochka")) {
                    // line 508
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Tochka Market\" src=\"/web/images/tochka.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 512
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 513
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo "</i>/<i class=\"normal\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                    echo "</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 518
$context["markets"], "market_title", array()) == "Grey")) {
                    // line 519
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Grey Market\" src=\"/web/images/grey.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 523
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t\t(<i class=\"normal\">";
                    // line 524
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "rate", array()), "html", null, true);
                    echo "<span class=\"mp-StarRating mp-StarRating--xs mp-StarRating--5\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"smstar\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t\t\t\t\t\t\t</b>)</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 532
$context["markets"], "market_title", array()) == "Dark")) {
                    // line 533
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Dark Market\" src=\"/web/images/darkm.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 537
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 538
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo "</i>/<i class=\"normal\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                    echo "</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t";
                } elseif (($this->getAttribute(                // line 543
$context["markets"], "market_title", array()) == "Wallstreet")) {
                    // line 544
                    echo "\t\t\t\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t\t\t\t<div class=\"mp-CompoundIcon mp-CompoundIcon--lg\">
\t\t\t\t\t\t\t\t\t\t\t<img class=\"sizem\" title=\"Wallstreet Market\" src=\"/web/images/walls.png\"/>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<span><b>";
                    // line 548
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "sales", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales")), "html", null, true);
                    echo "</b> |
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"green\">";
                    // line 549
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "positive", array()), "html", null, true);
                    echo " positive</i>/<i class=\"normal\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "neutral", array()), "html", null, true);
                    echo " neutral</i>/<i class=\"red\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["markets"], "negatives", array()), "html", null, true);
                    echo "</i>
\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t";
                }
                // line 555
                echo "\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['markets'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 556
            echo "\t\t\t\t\t\t\t";
        } else {
            // line 557
            echo "\t\t\t\t\t\t\t\t<p>";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_own_sales_nothing")), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t";
        }
        // line 559
        echo "\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t\t<div>
\t\t\t\t\t\t<div class=\"seller-info-shipping-options\">
\t\t\t\t\t\t\t";
        // line 563
        if ( !$this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "isBlocked", array(0 => call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array())), "method")) {
            // line 564
            echo "\t\t\t\t\t\t\t\t";
            if ($this->getAttribute(($context["listing"] ?? null), "is_published", array())) {
                // line 565
                echo "\t\t\t\t\t\t\t\t\t<h3>";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_shipping_options")), "html", null, true);
                echo "</h3>
\t\t\t\t\t\t\t\t\t<form action=\"";
                // line 566
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("checkout.store", array("id" => ($context["listing"] ?? null))));
                echo "\" method=\"post\">
\t\t\t\t\t\t\t\t\t\t";
                // line 567
                echo csrf_field();
                echo "
\t\t\t\t\t\t\t\t\t\t";
                // line 568
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["listing"] ?? null), "shipping_options", array()));
                foreach ($context['_seq'] as $context["k"] => $context["shipping_option"]) {
                    // line 569
                    echo "\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"shipping_option\" value=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["shipping_option"], "id", array()), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["shipping_option"], "name", array()), "html", null, true);
                    echo "/
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 570
                    echo twig_escape_filter($this->env, $this->getAttribute($context["shipping_option"], "days", array()), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\tdays/ +";
                    // line 571
                    echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->ToUserCurrency($this->getAttribute($context["shipping_option"], "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array())), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t";
                    // line 572
                    echo twig_escape_filter($this->env, twig_upper_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "currency", array())), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['k'], $context['shipping_option'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 575
                echo "
\t\t\t\t\t\t\t\t\t\t";
                // line 576
                if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "shipping_option"), "method")) {
                    // line 577
                    echo "\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 578
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_shipping_error")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 581
                echo "
\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\t<label>
\t\t\t\t\t\t\t\t\t\t\t<small>
\t\t\t\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                // line 586
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_quantity")), "html", null, true);
                echo " :
\t\t\t\t\t\t\t\t\t\t\t\t</b>
\t\t\t\t\t\t\t\t\t\t\t</small>
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t\t<input name=\"quantity\" value=\"1\" class=\"form-control input-sm\" size=\"15px\">
\t\t\t\t\t\t\t\t\t\t";
                // line 591
                if ($this->getAttribute(($context["errors"] ?? null), "has", array(0 => "quantity"), "method")) {
                    // line 592
                    echo "\t\t\t\t\t\t\t\t\t\t\t<div class=\"mp-Form-controlGroup-validationMessage mp-Form-controlGroup-validationMessage--error\">
\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 593
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["errors"] ?? null), "first", array(0 => "quantity"), "method"), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 596
                echo "\t\t\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "payment_type", array()), "id", array()) != 4)) {
                    // line 597
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (((($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "support_bitcoin", array()) == 0) && ($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "support_monero", array()) == 0)) && ($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "support_litecoin", array()) == 0))) {
                        // line 598
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<a style=\"color:black;\" href=\"#\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\" disabled>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 599
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_no_payment_method")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 602
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if ($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "support_bitcoin", array())) {
                        // line 603
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<button name=\"paymentmethod\" title=\"Buy with BTC\" type=\"submit\" value=\"1\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon--vertical mp-Button-icon--left btc20\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 605
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 606
                        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute(($context["listing"] ?? null), "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array()), "yes"), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tBTC
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 610
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if ($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "support_monero", array())) {
                        // line 611
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<button name=\"paymentmethod\" title=\"Buy with XMR\" type=\"submit\" value=\"3\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon--vertical mp-Button-icon--left xmr20\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 613
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 614
                        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetXMRPrice($this->getAttribute(($context["listing"] ?? null), "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array()), "yes"), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tXMR
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 618
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if ($this->getAttribute($this->getAttribute(($context["listing"] ?? null), "user", array()), "support_litecoin", array())) {
                        // line 619
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<button name=\"paymentmethod\" title=\"Buy with LTC\" type=\"submit\" value=\"2\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon--vertical mp-Button-icon--left ltc20\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 621
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 622
                        echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetLTCPrice($this->getAttribute(($context["listing"] ?? null), "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array()), "yes"), "html", null, true);
                        echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tLTC
\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 626
                    echo "
\t\t\t\t\t\t\t\t\t\t";
                } else {
                    // line 628
                    echo "\t\t\t\t\t\t\t\t\t\t\t<button name=\"paymentmethod\" title=\"Buy with BTC\" type=\"submit\" value=\"1\" class=\"button mp-Button mp-Button--primary mp-Button--xs fav-btn\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"mp-Button-icon--vertical mp-Button-icon--left btc20\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t<small>";
                    // line 630
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_purschase_with")), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    // line 631
                    echo twig_escape_filter($this->env, $this->env->getExtension('TwigBridge\Extension\Laravel\Auth')->GetBTCPrice($this->getAttribute(($context["listing"] ?? null), "price", array()), $this->getAttribute(($context["listing"] ?? null), "currency", array()), "yes"), "html", null, true);
                    echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tBTC ";
                    // line 632
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_using")), "html", null, true);
                    echo " Multisig 2/3</small>
\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t";
                }
                // line 635
                echo "\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t";
            } else {
                // line 637
                echo "\t\t\t\t\t\t\t\t\t<p style=\"color:red;\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_disabled")), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t\t";
            }
            // line 639
            echo "\t\t\t\t\t\t\t";
        } else {
            // line 640
            echo "\t\t\t\t\t\t\t\t<p style=\"color:red;\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_blocked")), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t";
        }
        // line 642
        echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<section class=\"contact-options-mobile mp-Card-block mp-Card-block--padded-no mp-Card-block--buttons\">
\t\t\t\t<a href=\"";
        // line 648
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), array("listing", array("id" => ($context["listing"] ?? null), "slug" => call_user_func_array($this->env->getFunction('str_slug')->getCallable(), array("slug", $this->getAttribute(($context["listing"] ?? null), "title", array()))))));
        echo "/message\" title=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ask_question")), "html", null, true);
        echo "\" class=\"mp-Button mp-Button--primary\">
\t\t\t\t\t<span class=\"mp-Button-icon mp-Button-icon--vertical mp-svg-messages-white\"></span>
\t\t\t\t\t";
        // line 650
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_ask_question")), "html", null, true);
        echo "
\t\t\t\t</a>
\t\t\t</section>
\t\t</section>

\t\t\t<div class=\"mp-Card\">
\t\t\t<div class=\"user-review-summary mp-Card-block\">
\t\t\t\t<h2>";
        // line 657
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_product_ratings")), "html", null, true);
        echo "</h2>
\t\t\t</span>
\t\t</div>
\t\t<div class=\"user-review-score-summary mp-Card-block\">
\t\t\t";
        // line 661
        if (($this->getAttribute(($context["comments"] ?? null), "count", array()) == 0)) {
            // line 662
            echo "\t\t\t\t";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.listing_no_rating")), "html", null, true);
            echo "
\t\t\t";
        } else {
            // line 664
            echo "\t\t\t\t<table>
\t\t\t\t\t<tbody>
\t\t\t\t\t\t<tr>

\t\t\t\t\t\t\t";
            // line 668
            $context["firstcount"] = 0;
            // line 669
            echo "\t\t\t\t\t\t\t";
            $context["secondcount"] = 0;
            // line 670
            echo "\t\t\t\t\t\t\t";
            $context["thirdcount"] = 0;
            // line 671
            echo "\t\t\t\t\t\t\t";
            $context["fourthcount"] = 0;
            // line 672
            echo "\t\t\t\t\t\t\t";
            $context["fithcount"] = 0;
            // line 673
            echo "
\t\t\t\t\t\t\t";
            // line 674
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["comments"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
                // line 675
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["comment"], "rating", array()) == 5)) {
                    // line 676
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["fithcount"] = (($context["fithcount"] ?? null) + 1);
                    // line 677
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 678
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["comment"], "rating", array()) == 4)) {
                    // line 679
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["fourthcount"] = (($context["fourthcount"] ?? null) + 1);
                    // line 680
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 681
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["comment"], "rating", array()) == 3)) {
                    // line 682
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["thirdcount"] = (($context["thirdcount"] ?? null) + 1);
                    // line 683
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 684
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["comment"], "rating", array()) == 2)) {
                    // line 685
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["secondcount"] = (($context["secondcount"] ?? null) + 1);
                    // line 686
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 687
                echo "\t\t\t\t\t\t\t\t";
                if (($this->getAttribute($context["comment"], "rating", array()) == 1)) {
                    // line 688
                    echo "\t\t\t\t\t\t\t\t\t";
                    $context["firstcount"] = (($context["firstcount"] ?? null) + 1);
                    // line 689
                    echo "\t\t\t\t\t\t\t\t";
                }
                // line 690
                echo "\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 691
            echo "\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<span class=\"mp-Chip mp-Chip--success\">5
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-saved-white\"></span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<div class=\"mp-Progress mp-Progress--success mp-Progress--lg mp-Progress--rounded\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Progress-bar mp-Progress-bar--determinate\" style=\"width:";
            // line 698
            echo twig_escape_filter($this->env, ((($context["fithcount"] ?? null) / $this->getAttribute(($context["comments"] ?? null), "count", array())) * 100), "html", null, true);
            echo "% \"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>";
            // line 701
            echo twig_escape_filter($this->env, ($context["fithcount"] ?? null), "html", null, true);
            echo "</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<span class=\"mp-Chip mp-Chip--success\">4
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-saved-white\"></span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<div class=\"mp-Progress mp-Progress--success mp-Progress--lg mp-Progress--rounded\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Progress-bar mp-Progress-bar--determinate\" style=\"width:";
            // line 711
            echo twig_escape_filter($this->env, ((($context["fourthcount"] ?? null) / $this->getAttribute(($context["comments"] ?? null), "count", array())) * 100), "html", null, true);
            echo "%\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>";
            // line 714
            echo twig_escape_filter($this->env, ($context["fourthcount"] ?? null), "html", null, true);
            echo "</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<span class=\"mp-Chip mp-Chip--success\">3
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-saved-white\"></span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<div class=\"mp-Progress mp-Progress--success mp-Progress--lg mp-Progress--rounded\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Progress-bar mp-Progress-bar--determinate\" style=\"width:";
            // line 724
            echo twig_escape_filter($this->env, ((($context["thirdcount"] ?? null) / $this->getAttribute(($context["comments"] ?? null), "count", array())) * 100), "html", null, true);
            echo "%\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>";
            // line 727
            echo twig_escape_filter($this->env, ($context["thirdcount"] ?? null), "html", null, true);
            echo "</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<span class=\"mp-Chip mp-Chip--success\">2
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-saved-white\"></span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<div class=\"mp-Progress mp-Progress--success mp-Progress--lg mp-Progress--rounded\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Progress-bar mp-Progress-bar--determinate\" style=\"width:";
            // line 737
            echo twig_escape_filter($this->env, ((($context["secondcount"] ?? null) / $this->getAttribute(($context["comments"] ?? null), "count", array())) * 100), "html", null, true);
            echo "%\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>";
            // line 740
            echo twig_escape_filter($this->env, ($context["secondcount"] ?? null), "html", null, true);
            echo "</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<span class=\"mp-Chip mp-Chip--success\">1
\t\t\t\t\t\t\t\t\t<span class=\"mp-Icon mp-svg-saved-white\"></span>
\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<div class=\"mp-Progress mp-Progress--success mp-Progress--lg mp-Progress--rounded\">
\t\t\t\t\t\t\t\t\t<div class=\"mp-Progress-bar mp-Progress-bar--determinate\" style=\"width:";
            // line 750
            echo twig_escape_filter($this->env, ((($context["firstcount"] ?? null) / $this->getAttribute(($context["comments"] ?? null), "count", array())) * 100), "html", null, true);
            echo "%\"></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>";
            // line 753
            echo twig_escape_filter($this->env, ($context["firstcount"] ?? null), "html", null, true);
            echo "</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</tbody>
\t\t\t\t</table>
\t\t\t";
        }
        // line 758
        echo "\t\t</div>
\t</div>
</div>
</aside>
</div>
</div>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/listing/show.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1684 => 758,  1676 => 753,  1670 => 750,  1657 => 740,  1651 => 737,  1638 => 727,  1632 => 724,  1619 => 714,  1613 => 711,  1600 => 701,  1594 => 698,  1585 => 691,  1579 => 690,  1576 => 689,  1573 => 688,  1570 => 687,  1567 => 686,  1564 => 685,  1561 => 684,  1558 => 683,  1555 => 682,  1552 => 681,  1549 => 680,  1546 => 679,  1543 => 678,  1540 => 677,  1537 => 676,  1534 => 675,  1530 => 674,  1527 => 673,  1524 => 672,  1521 => 671,  1518 => 670,  1515 => 669,  1513 => 668,  1507 => 664,  1501 => 662,  1499 => 661,  1492 => 657,  1482 => 650,  1475 => 648,  1467 => 642,  1461 => 640,  1458 => 639,  1452 => 637,  1448 => 635,  1442 => 632,  1438 => 631,  1434 => 630,  1430 => 628,  1426 => 626,  1419 => 622,  1415 => 621,  1411 => 619,  1408 => 618,  1401 => 614,  1397 => 613,  1393 => 611,  1390 => 610,  1383 => 606,  1379 => 605,  1375 => 603,  1372 => 602,  1366 => 599,  1363 => 598,  1360 => 597,  1357 => 596,  1351 => 593,  1348 => 592,  1346 => 591,  1338 => 586,  1331 => 581,  1325 => 578,  1322 => 577,  1320 => 576,  1317 => 575,  1308 => 572,  1304 => 571,  1300 => 570,  1293 => 569,  1289 => 568,  1285 => 567,  1281 => 566,  1276 => 565,  1273 => 564,  1271 => 563,  1265 => 559,  1259 => 557,  1256 => 556,  1250 => 555,  1237 => 549,  1231 => 548,  1225 => 544,  1223 => 543,  1211 => 538,  1205 => 537,  1199 => 533,  1197 => 532,  1186 => 524,  1180 => 523,  1174 => 519,  1172 => 518,  1160 => 513,  1154 => 512,  1148 => 508,  1146 => 507,  1134 => 502,  1128 => 501,  1122 => 497,  1120 => 496,  1110 => 491,  1104 => 490,  1098 => 486,  1096 => 485,  1089 => 481,  1083 => 480,  1076 => 475,  1074 => 474,  1062 => 469,  1056 => 468,  1050 => 464,  1048 => 463,  1035 => 457,  1029 => 456,  1022 => 451,  1020 => 450,  1009 => 442,  1003 => 441,  996 => 436,  994 => 435,  983 => 431,  977 => 430,  971 => 426,  969 => 425,  959 => 422,  953 => 421,  947 => 417,  944 => 416,  940 => 415,  937 => 414,  935 => 413,  931 => 412,  924 => 408,  916 => 405,  910 => 402,  905 => 400,  888 => 391,  884 => 390,  880 => 389,  874 => 385,  870 => 383,  866 => 381,  864 => 380,  860 => 379,  856 => 378,  843 => 367,  840 => 366,  823 => 362,  817 => 360,  810 => 357,  808 => 356,  804 => 355,  800 => 354,  795 => 352,  791 => 351,  786 => 349,  781 => 347,  777 => 345,  759 => 344,  753 => 341,  750 => 340,  748 => 339,  741 => 337,  736 => 334,  729 => 329,  719 => 325,  715 => 324,  707 => 323,  703 => 321,  699 => 320,  691 => 315,  686 => 312,  684 => 311,  679 => 308,  669 => 304,  665 => 303,  657 => 302,  653 => 300,  649 => 299,  641 => 294,  636 => 291,  634 => 290,  625 => 284,  619 => 281,  615 => 280,  603 => 271,  597 => 268,  585 => 258,  582 => 257,  573 => 255,  568 => 254,  566 => 253,  560 => 250,  539 => 232,  535 => 231,  531 => 230,  526 => 227,  520 => 225,  514 => 223,  512 => 222,  506 => 219,  499 => 215,  495 => 214,  488 => 210,  483 => 208,  479 => 207,  472 => 203,  467 => 201,  463 => 200,  456 => 196,  451 => 194,  447 => 193,  439 => 188,  434 => 186,  430 => 185,  420 => 180,  408 => 171,  404 => 170,  400 => 169,  396 => 168,  392 => 167,  388 => 166,  378 => 158,  372 => 156,  370 => 155,  367 => 154,  361 => 152,  358 => 151,  352 => 149,  350 => 148,  342 => 142,  336 => 139,  332 => 138,  329 => 137,  326 => 136,  320 => 133,  316 => 132,  313 => 131,  311 => 130,  306 => 128,  302 => 127,  288 => 116,  284 => 115,  278 => 112,  272 => 108,  266 => 106,  260 => 104,  258 => 103,  252 => 100,  245 => 96,  241 => 95,  234 => 91,  229 => 89,  225 => 88,  218 => 84,  213 => 82,  209 => 81,  202 => 77,  197 => 75,  193 => 74,  186 => 70,  181 => 68,  177 => 67,  167 => 62,  158 => 55,  150 => 52,  146 => 51,  139 => 49,  136 => 48,  134 => 47,  127 => 43,  123 => 42,  119 => 40,  109 => 36,  105 => 35,  102 => 34,  98 => 33,  93 => 31,  89 => 30,  84 => 28,  80 => 27,  75 => 24,  68 => 20,  63 => 17,  60 => 16,  53 => 12,  48 => 9,  46 => 8,  42 => 6,  39 => 5,  32 => 3,  29 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/listing/show.twig", "");
    }
}
