<?php

/* account.head_vendor_bar.twig */
class __TwigTemplate_978c4cd2d680e6db25ecb22fbf9875dd3408eb87f78da30dfd197b2f511b2ded extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "\t <div class=\"mp-Topbar\">
                <section class=\"mp-Topbar-inner-wrapper\">
                    <div class=\"mp-Tab-bar \">
                    
                       <a href=\"/account/vendor_settings\" class=\"mp-Tab ";
        // line 5
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 1)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 6
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_1")), "html", null, true);
        echo "
                        </a>
                        <a href=\"/account/listings\" class=\"mp-Tab ";
        // line 8
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 2)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 9
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_2")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "listings", array()), "count", array(), "method"), "html", null, true);
        echo ")
                        </a>
                        <a href=\"/account/orders\" class=\"mp-Tab ";
        // line 11
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 5)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 12
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_3")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "orders", array()), "count", array(), "method"), "html", null, true);
        echo ")

                        </a>
                        <a href=\"/account/disputes#chat\" class=\"mp-Tab ";
        // line 15
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 15)) ? ("is-selected") : (""));
        echo " \">
                         ";
        // line 16
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_4")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "disputesSeller", array()), "count", array(), "method"), "html", null, true);
        echo ")
                        </a>
                        <a href=\"/account/feedbacks\" class=\"mp-Tab ";
        // line 18
        echo ((($this->getAttribute(($context["MetaTag"] ?? null), "get", array(0 => "vendor_id"), "method") == 3)) ? ("is-selected") : (""));
        echo " \">
                        ";
        // line 19
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.account_head_vendor_5")), "html", null, true);
        echo "(";
        echo twig_escape_filter($this->env, $this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "count_reviews", array(), "method"), "html", null, true);
        echo ")
                        </a>
                    </div>
                </section>
        </div>

        \t\t\t\t";
    }

    public function getTemplateName()
    {
        return "account.head_vendor_bar.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 19,  68 => 18,  61 => 16,  57 => 15,  49 => 12,  45 => 11,  38 => 9,  34 => 8,  29 => 6,  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "account.head_vendor_bar.twig", "");
    }
}
