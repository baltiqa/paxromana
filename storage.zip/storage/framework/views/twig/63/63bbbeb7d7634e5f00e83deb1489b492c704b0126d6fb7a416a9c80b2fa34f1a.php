<?php

/* /var/www/html/html/resources/themes/default/account/profile.twig */
class __TwigTemplate_0c0ea50da75200cd5bc88df37edccecdfcbe00abc0e81ce9fb8be6f8ecc00c54 extends TwigBridge\Twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("account.master", "/var/www/html/html/resources/themes/default/account/profile.twig", 1);
        $this->blocks = array(
            'user_area' => array($this, 'block_user_area'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "account.master";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_user_area($context, array $blocks = array())
    {
        // line 4
        echo "   <section style=\"padding-bottom: 350px;\" id=\"content\">
                    <h2>";
        // line 5
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_profile")), "html", null, true);
        echo "</h2>

                    <div class=\"profile canvas\">
                        <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
        // line 12
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_1")), "html", null, true);
        echo "</div>
                                        <div class=\"profile-block-content\">
                                            ";
        // line 14
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_1")), "html", null, true);
        echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/edit_profile/me\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
        // line 18
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_tab5")), "html", null, true);
        echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
        // line 27
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_2")), "html", null, true);
        echo "</div>
                                        <div class=\"ellipsis profile-block-content\">
                                            ";
        // line 29
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_2"));
        echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/change_settings\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
        // line 33
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_edit")), "html", null, true);
        echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
        // line 42
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_disputes")), "html", null, true);
        echo "</div>
                                        <div class=\"profile-block-content\">
                                         ";
        // line 44
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_3")), "html", null, true);
        echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/disputes\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
        // line 48
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_disputes")), "html", null, true);
        echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
        // line 57
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.tips_5")), "html", null, true);
        echo "</div>
                                        <div class=\"ellipsis profile-block-content\">
                                           ";
        // line 59
        echo call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_4"));
        echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/change_pgp\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
        // line 63
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_edit")), "html", null, true);
        echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                         <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">Bitcoin Multisig 2/3</div>
                                        <div class=\"ellipsis profile-block-content\">
                                           ";
        // line 74
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_5")), "html", null, true);
        echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/multisig\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
        // line 78
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_edit")), "html", null, true);
        echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                      ";
        // line 83
        if (($this->getAttribute(call_user_func_array($this->env->getFunction('auth_user')->getCallable(), array()), "otp", array()) == 0)) {
            // line 84
            echo "                        <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
            // line 88
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_3")), "html", null, true);
            echo "</div>
                                        <div class=\"profile-block-content\">
                                            ";
            // line 90
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_6")), "html", null, true);
            echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/change_settings#2fa\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
            // line 94
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_3")), "html", null, true);
            echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        ";
        } else {
            // line 100
            echo "                         <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
            // line 104
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_4")), "html", null, true);
            echo "</div>
                                        <div class=\"profile-block-content\">
                                            ";
            // line 106
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_7")), "html", null, true);
            echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/change_settings#2fa\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
            // line 110
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_4")), "html", null, true);
            echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        ";
        }
        // line 116
        echo "                        <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
        // line 120
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_orders")), "html", null, true);
        echo "</div>
                                        <div class=\"profile-block-content\">
                                        ";
        // line 122
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_8")), "html", null, true);
        echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/purchase-history \" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
        // line 126
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_view")), "html", null, true);
        echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
        // line 135
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_wallet")), "html", null, true);
        echo "</div>
                                        <div class=\"profile-block-content\">
                                         ";
        // line 137
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_9")), "html", null, true);
        echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/wallet\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
        // line 141
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_view")), "html", null, true);
        echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class=\"profile-block\">
                            <div class=\"mp-Card mp-Card--rounded\">
                                <div class=\"mp-Card-block\">
                                    <div class=\"profile-content-wrapper\">
                                        <div class=\"ellipsis profile-block-title\">";
        // line 150
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.header_my_tickets")), "html", null, true);
        echo "</div>
                                        <div class=\"profile-block-content\">
                                            ";
        // line 152
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_block_text_10")), "html", null, true);
        echo "
                                        </div>
                                    </div>
                                    <a href=\"/account/tickets\" class=\"secondary sm mp-Button mp-Button--secondary mp-Button--sm\">
                                    <span>";
        // line 156
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("messages.profile_view")), "html", null, true);
        echo "</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
";
    }

    public function getTemplateName()
    {
        return "/var/www/html/html/resources/themes/default/account/profile.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 156,  272 => 152,  267 => 150,  255 => 141,  248 => 137,  243 => 135,  231 => 126,  224 => 122,  219 => 120,  213 => 116,  204 => 110,  197 => 106,  192 => 104,  186 => 100,  177 => 94,  170 => 90,  165 => 88,  159 => 84,  157 => 83,  149 => 78,  142 => 74,  128 => 63,  121 => 59,  116 => 57,  104 => 48,  97 => 44,  92 => 42,  80 => 33,  73 => 29,  68 => 27,  56 => 18,  49 => 14,  44 => 12,  34 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/var/www/html/html/resources/themes/default/account/profile.twig", "");
    }
}
