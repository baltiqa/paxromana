<?php $__env->startSection('content'); ?>

<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Orders</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/orders" class="breadcrumb-link">Orders</a>
                            <li class="breadcrumb-item"><a href="/panel/orders/<?php echo e($order->hash); ?>" class="breadcrumb-link">Order #<?php echo e($order->id); ?></a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header">Orders</h5>
                <div class="card-body">
                    <a href="<?php echo e(route('panel.orders.index')); ?>" class="mb-1"><i class="fa fa-angle-left"></i> back</a>
                    <h2 class="mt-xxs">Viewing order #<?php echo e($order->id); ?></h2>
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <th scope="row">Listing</th>
                                <td><?php echo e($order->product_title); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Status</th>
                                <td><span class="badge badge-warning"><?php echo e($order->status); ?></span></td>
                            </tr>
                            <tr>
                                <th scope="row">Amount</th>
                                <td><?php echo e($order->amount); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Price</th>
                                <td><?php echo e($order->price); ?> <?php echo e($order->currency); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Service fee</th>
                                <td><?php echo e(number_format($order->service_fee,9)); ?> <?php echo e($order->currency); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Buyer</th>
                                <td><?php echo e($order->user->name); ?> (<?php echo e($order->user->username); ?>)
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Seller</th>
                                <td><?php echo e($order->seller->name); ?> (<?php echo e($order->seller->username); ?>)
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Date&nbsp;Placed</th>
                                <td><?php echo e($order->created_at->toDayDateTimeString()); ?></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>