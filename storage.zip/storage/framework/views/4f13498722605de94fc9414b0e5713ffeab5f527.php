<?php $__env->startSection('content'); ?>
<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Ticket</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/tickets" class="breadcrumb-link">Ticket</a>
                            </li>
                            <li class="breadcrumb-item"><a href="/panel/tickets/<?php echo e($ticket->id); ?>/edit"
                                    class="breadcrumb-link">Ticket #<?php echo e($ticket->id); ?></a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header">Ticket <span style="float:right;" class="badge badge-info"><a style="color:white;" href="/profile/<?php echo e($ticket->user->username); ?>" target="_blank"><?php echo e($ticket->user->username); ?> Profile ?</a></span></h5>

                <div class="card-body">
                            <?php if($ticket->status != "Closed"): ?>
                            <a href="<?php echo e(route('panel.ticket.close',$ticket->id)); ?>" class="btn btn-primary" type="submit">Close Ticket</a>
                            <?php endif; ?>
                    <small>Ticket Created by: <span
                            class="badge badge-pill badge-info"><a style="color:white;" href="<?php echo e(route('panel.users.edit', $ticket->user->username)); ?>" target="_blank">[Edit]<?php echo e($ticket->user->username); ?></a></span></small>
                    <small style="float:right;"><span
                            class="<?php echo e($ticket->status == 'Closed' ? 'badge badge-success' : 'badge badge-danger'); ?>"><?php echo e($ticket->status); ?></span>Created
                        At: <span class="badge badge-primary"><?php echo e($ticket->created_at); ?></span></small>
                        <?php if(Session::has('message')): ?>
                    <div class="p-3 mb-2 bg-success text-white"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    <?php echo form_start($form); ?>

                    <?php echo form_until($form, 'text'); ?>


                    <?php if($ticket->category == 'Free Vendor Request'): ?>
                    <label for="username" class="control-label">PGP Key of <?php echo e($ticket->user->username); ?></label>
                    <textarea class="form-control" disabled="disabled" name="text" cols="50" rows="10" id="text">
<?php echo e($ticket->user->pgp_key); ?>

                    </textarea>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="conversation" class="control-label">Conversation</label><br>
                          <?php if(count($ticket->replies)>0): ?>
                          <div style="overflow-y: scroll;height:400px;" class="chat-module-body">
                            <?php $__currentLoopData = $ticket->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media chat-item">
                                <div class="media-body">
                                    <div class="chat-item-title">
                                        <span
                                            style="<?php if($message->user_id == 0): ?> color:blue; <?php elseif($message->user->id == $ticket->user->id): ?> color:red; <?php else: ?> color:green; <?php endif; ?>"
                                            class="chat-item-author"><?php echo e($message->user_id == null ? $message->moderator->username : $message->user->username); ?></span>
                                        <span><?php echo e($message->created_at->diffForHumans()); ?></span>
                                    </div>
                                    <div class="chat-item-body">
                                        <p><?php echo nl2br(e($message->text)); ?></p>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                        The conversation is currently empty.
                        <?php endif; ?>
                    </div>
                    <?php echo form_rest($form); ?>

                    <?php echo form_end($form); ?>

                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>