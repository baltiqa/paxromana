<?php $__env->startSection('content'); ?>
<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Wiki News</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/wiki" class="breadcrumb-link">Wiki News</a>
                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link"><?php if(!$form->getModel()): ?> New Wiki News <?php else: ?> Edit Wiki News <?php endif; ?></a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header"><?php if(!$form->getModel()): ?> New Wiki News <?php else: ?> Edit Wiki News <?php endif; ?></h5>
                <div class="card-body">
                <?php if(Session::has('message')): ?>
                    <div class="p-3 mb-2 bg-success text-white"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    
                <a href="<?php echo e(route('panel.wiki.index')); ?>" class="mb-1"><i class="fa fa-angle-left" aria-hidden="true"></i> back</a>
                
                <?php echo form_start($form); ?>

                  <?php echo form_rest($form); ?>

                  <?php echo form_end($form, false); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>