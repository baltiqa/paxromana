<?php $__env->startSection('content'); ?>

<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Orders</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/orders" class="breadcrumb-link">Orders</a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header">Orders</h5>
                <div class="card-body">


                    <?php echo Form::open(['url' => url()->current(), 'method' => 'GET']); ?>

                    <div class="input-group mb-3">
                        <?php echo e(Form::text('q', request('q'), ['class' => 'form-control', 'placeholder' => "Search..."])); ?>

                        <div class="input-group-append">
                            <button class="btn btn-secondary" type="submit">Search</button>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>


                    <table class="table table-sm table-striped">
                        <thead class="thead- border-0">
                            <tr>
                                <th scope="col" class="border-0">#</th>
                                <th scope="col" class="border-0">Listing</th>
                                <th scope="col" class="border-0">Status</th>
                                <th scope="col" class="border-0">Seller</th>
                                <th scope="col" class="border-0">Buyer</th>
                                <th scope="col" class="border-0">Total Price</th>
                                <th scope="col" class="border-0">Commission</th>
                                <th scope="col" class="border-0">Purchase Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('panel.orders.show', $item)); ?>"
                                        title="<?php echo e($item->id); ?>"><?php echo e($item->id); ?></a></td>   
                                <td><?php echo e(str_limit($item->product_title, 40)); ?></td>
                                <td><span class="badge badge-<?php echo e($item->status == 'finalized' ? 'success' : 'warning'); ?>"><?php echo e($item->status); ?></span></td>
                                <td><?php echo e($item->seller->username); ?></td>
                                <td><?php echo e($item->user->username); ?></td>
                                <td><?php echo e(number_format($item->price,5)); ?> <?php echo e($item->currency); ?></td>
                                <td><?php echo e(number_format($item->service_fee,5)); ?> <?php echo e($item->currency); ?></td>
                                <td><?php echo e($item->created_at->toFormattedDateString()); ?></td>
                                <td>
                                    <a href="<?php echo e(route('panel.orders.show', $item)); ?>" class="text-muted float-right">Check</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($orders->appends(app('request')->except('page'))->links('panel::pagination.default')); ?>


                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>