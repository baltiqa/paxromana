<?php if($paginator->hasPages()): ?>
<nav style="margin-top:15px;" class="mp-PaginationControls-pagination">
        
        <?php if($paginator->onFirstPage()): ?>
            <button disabled="" class="mp-Button mp-Button--round mp-Button--md">
						<span class="mp-Button-icon mp-Button-icon--center mp-svg-arrow-left-white"></span>
			</button>
        <?php else: ?>
        <button class="mp-Button mp-Button--round mp-Button--md">
          <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><span class="mp-Button-icon mp-Button-icon--center mp-svg-arrow-left-white"></span></a>
		</button>
        <?php endif; ?>
        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <li class="page-item disabled"><span class="page-link"><?php echo e($element); ?></span></li>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="mp-PaginationControls-pagination-pageList"><span><?php echo e($page); ?></span></span>
                    <?php else: ?>
                        <span class="mp-PaginationControls-pagination-pageList"><span><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></span></span>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php if($paginator->hasMorePages()): ?>
        <button class="mp-Button mp-Button--round mp-Button--md">    
            <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><span  class="mp-Button-icon mp-Button-icon--center mp-svg-arrow-right-white"></span></a>
         </button>
        <?php else: ?>
        <button disabled="" class="mp-Button mp-Button--round mp-Button--md">    
            <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><span  class="mp-Button-icon mp-Button-icon--center mp-svg-arrow-right-white"></span></a>
         </button>

        <?php endif; ?>
</nav>
<?php endif; ?>

					
