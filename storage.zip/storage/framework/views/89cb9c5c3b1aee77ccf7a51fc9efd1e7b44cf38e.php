<?php $__env->startSection('content'); ?>

<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Tickets</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/tickets"
                                    class="breadcrumb-link">Tickets</a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header">Tickets</h5>
                <div class="card-body">
                <?php if(Session::has('message')): ?>
                    <div class="p-3 mb-2 bg-success text-white"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    <table class="table table-sm  ">
                        <thead class="thead- border-0">
                            <tr>
                                <th>#</th>
                                <th>Date Created</th>
                                <th>Latest Response By</th>
                                <th>Subject</th>
                                <th>User</th>
                                <th>Category</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Closed By</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ticket->id); ?></td>
                                <td><?php echo e($ticket->created_at); ?></td>
                                <td><?php echo e($ticket->usernameResponse() == null ? 'Nobody' : $ticket->usernameResponse()); ?></td>
                                <td><?php echo str_limit($ticket->title,10); ?></td>
                                <td><?php echo e($ticket->user->username); ?></td>
                                <td><?php echo e($ticket->category); ?></td>
                                <td><?php echo str_limit($ticket->text,8); ?></td>
                                <td><span class="<?php echo e($ticket->status == 'Closed' ? 'badge badge-success' : 'badge badge-danger'); ?>"><?php echo e($ticket->status); ?></span></td>
                                <td><?php echo e($ticket->lastMod != null ? $ticket->lastMod->username :  'Nobody'); ?></td>
                                <td>
                                    <?php if($ticket->status != "Closed"): ?>
                                    <a href="<?php echo e(route('panel.tickets.edit', $ticket->id)); ?>"
                                        class="badge badge-danger float-right">Review</a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('panel.tickets.edit', $ticket->id)); ?>"
                                        class="badge badge-pill badge-success float-right">Solved</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php echo e($tickets->links('panel::pagination.default')); ?>


                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>