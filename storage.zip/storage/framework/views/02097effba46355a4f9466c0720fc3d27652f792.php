<?php $__env->startSection('content'); ?>
<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Listings</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/listings" class="breadcrumb-link">Listings</a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header">Listings</h5>
                <div class="card-body">
                    <?php if(Session::has('message')): ?>
                    <div class="p-3 mb-2 bg-success text-white"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>

                    <?php echo Form::open(['url' => url()->current(), 'method' => 'GET']); ?>

                    <div class="input-group mb-3">
                        <?php echo e(Form::text('q', request('q'), ['class' => 'form-control', 'placeholder' => "Search..."])); ?>

                        <div class="input-group-append">
                            <button class="btn btn-secondary" type="submit">Search</button>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>


                    <table class="table table-sm table-striped">
                        <thead class="thead- border-0">
                            <tr>
                                <th scope="col" class="w- border-0"></th>
                                <th scope="col" class="w-50 border-0">Title</th>
                                <th scope="col" class="w-25 border-0">User</th>
                                <th scope="col" class="w-25 border-0"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($item->id); ?></th>
                                <td><a
                                        href="<?php echo e(route('panel.listings.edit', $item)); ?>"><?php echo e(str_limit($item->title, 40)); ?> <?php if($item->deleted_at != null): ?> (deleted) <?php endif; ?></a>
                                    <?php if($item->is_draft): ?><small class="badge badge-secondary">draft</small><?php endif; ?>
                                    <br /><?php if($item->expires_at): ?><small class="text-muted">Expires
                                        <?php echo e($item->expires_at); ?></small><?php endif; ?> <?php if($item->ends_at): ?><small
                                        class="text-muted">Ends <?php echo e($item->ends_at); ?></small><?php endif; ?></td>
                                <td><?php echo e(@$item->user->username); ?></td>
                                <td>
                                    <a href="<?php echo e(route('panel.listings.edit', $item)); ?>" class="text-muted float-right">Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>


                    <?php echo e($listings->appends(app('request')->except('page'))->links('panel::pagination.default')); ?>



                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>