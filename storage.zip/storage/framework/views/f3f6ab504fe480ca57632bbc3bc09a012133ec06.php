<?php $__env->startSection('content'); ?>

<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Buy Logs</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/buyerlogs" class="breadcrumb-link">Buy Logs</a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header">Buy logs</h5>
                <div class="card-body">
                    <a href="<?php echo e(route('panel.withdraw.xmr',['amount'=>$xmr_amount,'state'=>1])); ?>" class="btn btn-primary" type="submit">XMR Cashout <?php echo e($xmr_amount); ?></a>
                    <a href="<?php echo e(route('panel.withdraw.btc',['amount'=>$btc_amount,'state'=>1])); ?>"  class="btn btn-primary" type="submit">BTC Cashout <?php echo e($btc_amount); ?></a>
                    <a href="<?php echo e(route('panel.withdraw.ltc',['amount'=>$ltc_amount,'state'=>1])); ?>" class="btn btn-primary" type="submit">LTC Cashout <?php echo e($ltc_amount); ?></a>
                    <?php if(Session::has('message')): ?>
                    <div class="p-3 mb-2 bg-success text-white"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    <table class="table table-sm table-striped">
                        <thead class="thead- border-0">
                            <tr>
                                <th class="border-0">Created At</th>
                                <th class="border-0">Type</th>
                                <th class="border-0">Username</th>
                                <th class="border-0">Amount</th>
                                <th class="border-0">Cashed</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->created_at); ?></td>
                                <td><?php echo e($item->type); ?></td>
                                <td><?php echo e($item->username); ?></td>
                                <td><?php echo e($item->amount); ?> <?php echo e($item->currency); ?></td>
                                <td><?php echo e($item->paid == 1 ? 'Paid out' : 'Not paid out'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>