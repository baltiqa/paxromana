<?php $__env->startSection('content'); ?>

<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Users</h2>
                <div class="page-breadcrumb">
                    <nav>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/users" class="breadcrumb-link">Users</a>
                            <li class="breadcrumb-item"><a href="/panel/user/<?php echo e($user->id); ?>/edit"
                                    class="breadcrumb-link">Edit <?php echo e($user->username); ?></a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header">Edit User                  <span style="float:right;" class="badge badge-info"><a style="color:white;" href="/profile/<?php echo e($user->username); ?>" target="_blank"><?php echo e($user->username); ?> Profile ?</a></span></h5> 
                <div class="card-body">
                <?php if(Session::has('message')): ?>
                    <div class="p-3 mb-2 bg-success text-white"><?php echo e(Session::get('message')); ?></div>
                <?php endif; ?>
                <span style="float:right;" class="badge badge-primary">Last Activity: <?php echo e($user->last_login_at->diffForHumans()); ?></span>

                    <?php echo form_start($form); ?>

                    <?php echo form_until($form,'username'); ?>

                    <div class="form-group">
                    <label for="display_name" class="control-label">Display name</label>
                   <input class="form-control" placeholder="This display Name will be showed in the profile of the user instead of the username" name="display_name" type="text" value="<?php echo e($user->display_name); ?>" id="display_name">
                     </div>
                     <div class="form-group">
                    <label for="display_name" class="control-label">Registered At</label>
                     <input class="form-control" name="created_at" type="text" value="<?php echo e($user->created_at); ?>" id="created_at">
                     </div>

                     <div class="form-group"> 
                     <label for="pgp_key" class="control-label">PGP Key</label>                
    <textarea class="form-control" rows="8" readonly="readonly" style="width: 100%; cursor: default">
<?php echo e($user->pgp_key); ?>

</textarea>
                     </div>

                    <hr>

                    <?php if($user->is_headmod == 1 || $user->is_mod == 1): ?>
                    <div class="form-group">
                        <label for="rank" class="control-label">Rank</label>
                        <input class="form-control" type="text" disabled="disabled" value="<?php if($user->is_mod == 1 and $user->is_headmod == 1): ?>Head Moderator <?php elseif($user->is_mod == 1): ?> Moderator <?php endif; ?>">
                    </div>
                    <hr>
                    <?php endif; ?>


                    <div class="form-group">
                        <label for="rank" class="control-label">Trader Type</label>
                        <input class="form-control" type="text" disabled="disabled" value="<?php echo e($user->trader_type == 'individual' ? 'Vendor' : 'Buyer'); ?>">
                    </div>

                   
                    <hr>
                    <?php if(auth()->user()->is_headmod == 1 or auth()->user()->is_admin == 1 ): ?>
                    <h3>Head Moderator Options</h3>

                    <div class="form-group form-check-inline">
                        <input class="form-check-input" id="mod_enable" name="mod_enable" type="checkbox" value="1"  <?php if($user->is_mod == 1): ?> checked <?php endif; ?>>
                        <label class="form-check-label" for="mod_enable">Moderator</label>
                    </div></br>

                    <?php if($user->is_mod == 1): ?>
                    <div class="form-group form-check-inline">
                        <input class="form-check-input" id="dispute_allowed" name="dispute_allowed" type="checkbox" value="yes" <?php if($user->permiss()[0]['dispute'] != null): ?> <?php if($user->permiss()[0]['dispute'] == "yes"): ?> checked <?php endif; ?> <?php endif; ?>>
                        <label class="form-check-label" for="dispute_allowed">Dispute Allowed</label>
                    </div>
                    <div class="form-group form-check-inline">
                        <input class="form-check-input" id="reports_allowed" name="reports_allowed" type="checkbox" value="yes" <?php if($user->permiss()[0]['report'] != null): ?> <?php if($user->permiss()[0]['report'] == "yes"): ?> checked <?php endif; ?> <?php endif; ?>>
                        <label class="form-check-label" for="reports_allowed">Reports Allowed</label>
                    </div>                  
                    <?php endif; ?>
                   

                    <div class="form-group">
                    <label for="commission" class="control-label">Transaction fee</label>
                     <input class="form-control" name="commission" type="text" value="<?php echo e($user->commission); ?>" id="commission">
                     </div>
                     <br>
                  

                     <h3>Moderator Options</h3>
                    <?php if($user->trader_type == 'individual'): ?>
                    <div class="form-group form-check-inline">
                     <?php if($user->has_fe == 1): ?>
                    <input class="form-check-input" id="fe_enabled" name="fe_enabled" type="checkbox" value="disable">
                    <label for="fe_enabled" class="control-label">Disable FE Rights</label>      
                     <?php else: ?>
                     <input class="form-check-input" id="fe_enabled" name="fe_enabled" type="checkbox" value="enable">
                    <label for="fe_enabled" class="control-label">Enable FE Rights</label>    
                     <?php endif; ?>
                     </div>
                    <hr>
                    <?php endif; ?>
                <?php endif; ?>



                    <?php if($user->trader_type == 'buyer'): ?>
                    <label class="control-label">Buyer Stats</label>
                    <div class="form-group">
                            <table class="table" style="margin: 0;width: 50%;float: left;">
                                <tbody>
                                    <tr>
                                        <th style="border: 0;">Total Orders</th>
                                        <td style="border: 0;"><?php echo e($user->normal_orders->count()); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Disputes (%)</th>
                                        <td><?php echo e($user->disputesBuyer->count()); ?> (<?php if($user->disputesBuyer->count()): ?><?php echo e(number_format(($user->disputesBuyer->count()/$user->normal_orders->count())*100,2)); ?>% <?php else: ?> 0.00% <?php endif; ?>)</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table" style="margin: 0;width: 50%;float: left;">
                                <tbody>
                                    <tr>
                                        <th style="border: 0;">Total Spendings</th>
                                        <td style="border: 0;"><?php echo e(number_format($sale_total_buyer,2)); ?> <?php echo e(strtoupper(auth()->user()->currency)); ?> </td>
                                    </tr>
                                    <tr>
                                        <th>Average</th>
                                        <td style="border: 0;"><?php if($sale_total_buyer > 1): ?><?php echo e(number_format($sale_total_buyer/$user->normal_orders->count(),2)); ?> <?php else: ?> 0.00 <?php endif; ?> <?php echo e(strtoupper(auth()->user()->currency)); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                    </div>
                    <?php else: ?>
                    <label class="control-label">Vendor Stats</label>
                    <div class="form-group">
                            <table class="table" style="margin: 0;width: 50%;float: left;">
                                <tbody>
                                    <tr>
                                        <th style="border: 0;">Total Sales</th>
                                        <td style="border: 0;"><?php echo e($user->orders->count()); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Total Disputes (%)</th>
                                        <td><?php echo e($user->disputesSeller->count()); ?> (<?php if($user->disputesSeller->count()): ?><?php echo e(number_format(($user->disputesSeller->count()/$user->orders->count())*100,2)); ?>% <?php else: ?> 0% <?php endif; ?>)</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table" style="margin: 0;width: 50%;float: left;">
                                <tbody>
                                    <tr>
                                        <th style="border: 0;">Sales Worth</th>
                                        <td style="border: 0;"><?php echo e(number_format($sale_total_seller,2)); ?> <?php echo e(strtoupper(auth()->user()->currency)); ?> </td>
                                    </tr>
                                    <tr>
                                        <th>Average</th>
                                        <td style="border: 0;"><?php if($sale_total_seller > 1): ?><?php echo e(number_format($sale_total_seller/$user->orders->count(),2)); ?> <?php else: ?> 0.00 <?php endif; ?> <?php echo e(strtoupper(auth()->user()->currency)); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <a href="<?php echo e(route('panel.usermarkets.edit', $user->username)); ?>" class="btn btn-primary">Import Feedbacks</a><br><br>

                



                        
                    <?php endif; ?>

                    <?php if($user->trader_type == 'buyer'): ?>
                    <div class="form-group form-check-inline">
                    <input class="form-check-input" id="vendor_enabled" name="vendor_enabled" type="checkbox" value="yes">
                    <label for="vendor_enabled" class="control-label">Enable Vendor</label>    
                    </div>
                    <?php else: ?>
                    <div class="form-group form-check-inline">
                    <input class="form-check-input" id="vendor_enabled" name="vendor_enabled" type="checkbox" value="no">
                    <label for="vendor_enabled" class="control-label">Disable Vendor</label>    
                    </div>
                    
                    <?php endif; ?>

                    <hr>
                    <?php echo form_rest($form); ?>

                    <?php echo form_end($form, false); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>