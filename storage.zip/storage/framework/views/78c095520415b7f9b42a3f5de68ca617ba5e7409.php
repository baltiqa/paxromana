<?php $__env->startSection('content'); ?>
<div class="container-fluid  dashboard-content">
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title">Reviews</h2>
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/panel" class="breadcrumb-link">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="/panel/reviews" class="breadcrumb-link">Reviews</a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <h5 class="card-header">Reviews</h5>
                <div class="card-body">
                    <?php if(Session::has('message')): ?>
                    <div class="p-3 mb-2 bg-success text-white"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>

                    <?php echo Form::open(['url' => url()->current(), 'method' => 'GET']); ?>

                    <div class="input-group mb-3">
                        <?php echo e(Form::text('q', request('q'), ['class' => 'form-control', 'placeholder' => "Search..."])); ?>

                        <div class="input-group-append">
                            <button class="btn btn-secondary" type="submit">Search</button>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>


                    <table class="table table-sm table-striped">
                        <thead class="thead- border-0">
                            <tr>
                                <th>#</th>
                                <th>Commenter</th>
                                <th>Comment</th>
                                <th>Rate</th>
                                <th>Order ID</th>
                                <th>Seller</th>
                                <th>Created On</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($comment->id); ?></th>
                                <td><?php echo e($comment->commenter->username); ?></td>
                                <td><?php echo e($comment->comment); ?></td>
                                <td><?php echo e(number_format($comment->rate,2)); ?></td>
                                <td><?php echo e($comment->order_id); ?></td>
                                <td><?php echo e($comment->seller->username); ?></td>

                                <td><?php echo e($comment->created_at); ?></td>
                                <td><a href="<?php echo e(route('panel.reviews.edit', $comment->id)); ?>" class="text-muted float-right">Edit</a></td>
                                <td>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($comments->appends(app('request')->except('page'))->links('panel::pagination.default')); ?>


                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>