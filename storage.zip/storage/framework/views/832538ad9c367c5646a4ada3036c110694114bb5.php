\

<?php $__env->startSection('content'); ?>
<div class="dashboard-ecommerce">
    <div class="container-fluid dashboard-content ">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Dashboard Administrator </h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="ecommerce-widget">

            <div class="row">
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="text-muted">Users Registered Today</h5>
                            <div class="metric-value d-inline-block">
                                <h1 class="mb-1"><?php echo e($users_today); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="text-muted">Total Users Active</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e($users_total); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Vendor Active</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e($vendors_total); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Orders Today</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e($orders_today); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Total Orders</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e($total_orders); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Total Listings</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e($total_listings); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="text-muted">Bitcoin Total Balance</h5>
                            <div class="metric-value d-inline-block">
				<?php echo e($btc_balance->result); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="text-muted">Litecoin Total Balance</h5>
                            <div class="metric-value d-inline-block">
                            <?php echo e($ltc_balance->result); ?>

				</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="text-muted">Monero Total Balance</h5>
                            <div class="metric-value d-inline-block">
                         	<?php echo e($xmr_balance->result['balance']); ?>   
			 </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Monero in Escrow</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($monero_escrow->total,4)); ?>XMR</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Monero last 24h orders</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($monero_escrow_lastday->total,4)); ?>XMR</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Monero released Escrow</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($monero_released_escrow_lastday->total,4)); ?>XMR</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Monero Revenue</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($monero_fee_received,4)); ?>XMR</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Bitcoin in Escrow</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($bitcoin_escrow->total,5)); ?>BTC</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Bitcoin last 24h orders</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($bitcoin_escrow_lastday->total,5)); ?>BTC</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Bitcoin released Escrow</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($bitcoin_released_escrow_lastday->total,5)); ?>BTC</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Bitcoin Revenue</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($bitcoin_fee_received,5)); ?>BTC</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Litecoin in Escrow</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($litecoin_escrow->total,5)); ?>LTC</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Litecoin last 24h orders</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($litecoin_escrow_lastday->total,5)); ?>LTC</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Litecoin released Escrow</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($litecoin_released_escrow_lastday->total,5)); ?>LTC</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                        <h5 class="text-muted">Litecoin Revenue</h5>
                            <div class="metric-value d-inline-block">
                            <h1 class="mb-1"><?php echo e(number_format($litecoin_fee_received,5)); ?>LTC</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>     


            <div class="row">
                <div class="col-lg-9">
                    <div class="card">
                        <h5 class="card-header">Recent Multisig 2/3 Transactions</h5>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="bg-light">
                                        <tr class="border-0">
                                            <th class="border-0">#</th>
                                            <th class="border-0">Order</th>
                                            <th class="border-0">Multisig Address</th>
                                            <th class="border-0">Amount</th>
                                            <th class="border-0">Created At</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $multisigtransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multisig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($multisig->id); ?></td>
                                        <td>#<?php echo e($multisig->order_id); ?></td>
                                        <td><?php echo e($multisig->multisig_address); ?></td>
                                        <td><?php echo e(number_format($multisig->multisig_amount,8)); ?>BTC</td>
                                        <td><?php echo e($multisig->created_at); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3">
                <?php if(auth()->user()->username == "Augustus"): ?>
                    <div class="card">
                        <h5 class="card-header">Error Logs</h5>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="bg-light">
                                        <tr class="border-0">
                                            <th class="border-0">Error Code</th>
                                            <th class="border-0">Error Log</th>
                                            <th class="border-0">Created At</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $errorlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($log->code); ?></td>
                                        <td><?php echo e($log->message); ?></td>
                                        <td><?php echo e($log->created_at); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="card">
                        <h5 class="card-header">Buy Logs</h5>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="bg-light">
                                        <tr class="border-0">
                                            <th class="border-0">Type</th>
                                            <th class="border-0">Username</th>
                                            <th class="border-0">Amount</th>
                                            <th class="border-0">Cashed</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $buylogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($buy->type); ?></td>
                                        <td><?php echo e($buy->username); ?></td>
                                        <td><?php echo e($buy->amount); ?> <?php echo e($buy->currency); ?></td>
                                        <td><?php echo e($buy->paid == 1 ? 'Paid out' : 'Not paid out'); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <h5 class="card-header">Recent Deposits</h5>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="bg-light">
                                        <tr class="border-0">
                                            <th class="border-0">#</th>
                                            <th class="border-0">TX ID</th>
                                            <th class="border-0">User</th>
                                            <th class="border-0">Address</th>
                                            <th class="border-0">Currency</th>
                                            <th class="border-0">Amount</th>
                                            <th class="border-0">Status</th>
                                            <th class="border-0">Created At</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($deposit->type == "Deposit"): ?>
                                    <tr>
                                        <td><?php echo e($deposit->id); ?></td>
                                        <td><?php echo e($deposit->tx_id); ?></td>
                                        <td><?php echo e($deposit->user->username); ?></td>
                                        <td><?php echo e($deposit->address); ?></td>
                                        <td><?php echo e($deposit->amount); ?></td>
                                        <td><?php if($deposit->currency == 1): ?> BTC <?php elseif($deposit->currency == 2): ?> LTC <?php else: ?> XMR <?php endif; ?></td>
                                        <td><?php echo e($deposit->status); ?></td>
                                        <td><?php echo e($deposit->created_at); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card">
                        <h5 class="card-header">Recent Withdraws</h5>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table">
                                 <thead class="bg-light">
                                        <tr class="border-0">
                                            <th class="border-0">#</th>
                                            <th class="border-0">TX ID</th>
                                            <th class="border-0">User</th>
                                            <th class="border-0">Address</th>
                                            <th class="border-0">Currency</th>
                                            <th class="border-0">Amount</th>
                                            <th class="border-0">Status</th>
                                            <th class="border-0">Created At</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($withdraw->type == "Withdraw"): ?>
                                    <tr>
                                        <td><?php echo e($withdraw->id); ?></td>
                                        <td><?php echo e($withdraw->tx_id); ?></td>
                                        <td><?php echo e($withdraw->user->username); ?></td>
                                        <td><?php echo e($withdraw->address); ?></td>
                                        <td><?php echo e($withdraw->amount); ?></td>
                                        <td><?php if($withdraw->currency == 1): ?> BTC <?php elseif($withdraw->currency == 2): ?> LTC <?php else: ?> XMR <?php endif; ?></td>
                                        <td><?php echo e($withdraw->status); ?></td>
                                        <td><?php echo e($withdraw->created_at); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('panel::layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>